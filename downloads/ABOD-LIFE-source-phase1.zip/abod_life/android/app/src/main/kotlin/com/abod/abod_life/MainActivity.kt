package com.abod.abod_life

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
