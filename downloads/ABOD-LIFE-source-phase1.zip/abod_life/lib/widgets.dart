import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'l10n.dart';

String money(double v, String cur) => '${NumberFormat('#,##0.##').format(v)} $cur';
String dfmt(BuildContext c, DateTime d) => DateFormat.yMMMd(Localizations.localeOf(c).languageCode).format(d);
String dtfmt(BuildContext c, DateTime d) => DateFormat.yMMMd(Localizations.localeOf(c).languageCode).add_jm().format(d);

List<String> cats(BuildContext c, String type) => tr(c, type == 'income' ? 'incomeCats' : 'expenseCats').split(',');

class Empty extends StatelessWidget {
  final String text; final IconData icon;
  const Empty(this.text, {super.key, this.icon = Icons.inbox_outlined});
  @override
  Widget build(BuildContext c) => Center(child: Padding(padding: const EdgeInsets.all(32),
      child: Column(mainAxisSize: MainAxisSize.min, children: [Icon(icon, size: 56, color: Colors.grey), const SizedBox(height: 12), Text(text, textAlign: TextAlign.center, style: const TextStyle(color: Colors.grey))])));
}

Future<bool> confirmDelete(BuildContext c) async =>
    (await showDialog<bool>(context: c, builder: (_) => AlertDialog(content: Text(tr(c, 'confirmDel')), actions: [
      TextButton(onPressed: () => Navigator.pop(c, false), child: Text(tr(c, 'cancel'))),
      TextButton(onPressed: () => Navigator.pop(c, true), child: Text(tr(c, 'delete'))),
    ]))) ?? false;

Future<DateTime?> pickDateTime(BuildContext c, {DateTime? initial, bool withTime = true}) async {
  final now = DateTime.now();
  final d = await showDatePicker(context: c, initialDate: initial ?? now, firstDate: DateTime(2000), lastDate: DateTime(2100));
  if (d == null || !withTime || !c.mounted) return d;
  final t = await showTimePicker(context: c, initialTime: TimeOfDay.fromDateTime(initial ?? now));
  return t == null ? d : DateTime(d.year, d.month, d.day, t.hour, t.minute);
}

double? parseAmount(String s) {
  const ar = '٠١٢٣٤٥٦٧٨٩';
  var r = s.trim().replaceAll(',', '.').replaceAll('٫', '.');
  for (var i = 0; i < 10; i++) { r = r.replaceAll(ar[i], '$i'); }
  final v = double.tryParse(r);
  return (v == null || v <= 0) ? null : v;
}
