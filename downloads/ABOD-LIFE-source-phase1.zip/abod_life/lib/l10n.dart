import 'package:flutter/material.dart';

const Map<String, Map<String, String>> _s = {
  'ar': {
    'app': 'ABOD LIFE', 'dashboard': 'الرئيسية', 'finance': 'المالية', 'tasks': 'المهام', 'settings': 'الإعدادات',
    'balance': 'الرصيد', 'income': 'الدخل', 'expense': 'المصروف', 'thisMonth': 'هذا الشهر',
    'add': 'إضافة', 'save': 'حفظ', 'cancel': 'إلغاء', 'delete': 'حذف', 'edit': 'تعديل',
    'amount': 'المبلغ', 'category': 'التصنيف', 'note': 'ملاحظة', 'date': 'التاريخ',
    'transactions': 'المعاملات', 'debts': 'الديون', 'budget': 'الميزانية', 'charts': 'الرسوم',
    'noTx': 'لا توجد معاملات بعد. اضغط + لإضافة أول معاملة.',
    'noDebts': 'لا توجد ديون مسجلة.', 'noBudgets': 'لم تحدد ميزانية بعد. اضغط + لتحديد حد لتصنيف.',
    'noTasks': 'لا توجد مهام. اضغط + لإضافة مهمة.', 'noChart': 'أضف مصروفات لعرض الرسوم.',
    'owedToMe': 'لي عند الغير', 'iOwe': 'علي للغير', 'person': 'الشخص', 'due': 'الاستحقاق', 'paid': 'تم السداد',
    'markPaid': 'تسجيل كمسدد', 'limit': 'الحد الشهري', 'spent': 'المصروف', 'remaining': 'المتبقي',
    'over': 'تجاوزت الحد', 'expByCat': 'المصروفات حسب التصنيف', 'last6': 'آخر 6 أشهر',
    'exportPdf': 'تصدير PDF', 'exportXlsx': 'تصدير Excel', 'savedTo': 'تم الحفظ في',
    'title': 'العنوان', 'priority': 'الأولوية', 'high': 'عالية', 'medium': 'متوسطة', 'low': 'منخفضة',
    'progress': 'التقدم', 'remind': 'تذكير عند الاستحقاق', 'list': 'قائمة', 'calendar': 'تقويم',
    'open': 'مفتوحة', 'done': 'منجزة', 'all': 'الكل', 'noDue': 'بدون موعد', 'pickDate': 'اختر التاريخ والوقت',
    'language': 'اللغة', 'theme': 'المظهر', 'dark': 'داكن', 'light': 'فاتح', 'system': 'النظام',
    'currency': 'رمز العملة', 'arabic': 'العربية', 'english': 'English', 'required': 'مطلوب', 'invalid': 'قيمة غير صحيحة',
    'todayTasks': 'مهام اليوم', 'upcoming': 'قادمة', 'overdue': 'متأخرة', 'recent': 'آخر المعاملات', 'activeDebts': 'ديون غير مسددة',
    'taskDone': 'نسبة الإنجاز', 'about': 'عن التطبيق', 'phase1': 'المرحلة 1: الأساسيات والمالية والمهام',
    'incomeCats': 'راتب,عمل حر,هدية,استثمار,أخرى', 'expenseCats': 'طعام,مواصلات,فواتير,تسوق,صحة,ترفيه,تعليم,أخرى',
    'confirmDel': 'هل تريد الحذف؟', 'permNote': 'سيطلب النظام إذن الإشعارات عند أول تذكير.',
  },
  'en': {
    'app': 'ABOD LIFE', 'dashboard': 'Dashboard', 'finance': 'Finance', 'tasks': 'Tasks', 'settings': 'Settings',
    'balance': 'Balance', 'income': 'Income', 'expense': 'Expense', 'thisMonth': 'This month',
    'add': 'Add', 'save': 'Save', 'cancel': 'Cancel', 'delete': 'Delete', 'edit': 'Edit',
    'amount': 'Amount', 'category': 'Category', 'note': 'Note', 'date': 'Date',
    'transactions': 'Transactions', 'debts': 'Debts', 'budget': 'Budget', 'charts': 'Charts',
    'noTx': 'No transactions yet. Tap + to add your first one.',
    'noDebts': 'No debts recorded.', 'noBudgets': 'No budget yet. Tap + to set a category limit.',
    'noTasks': 'No tasks. Tap + to add one.', 'noChart': 'Add expenses to see charts.',
    'owedToMe': 'Owed to me', 'iOwe': 'I owe', 'person': 'Person', 'due': 'Due', 'paid': 'Paid',
    'markPaid': 'Mark as paid', 'limit': 'Monthly limit', 'spent': 'Spent', 'remaining': 'Remaining',
    'over': 'Over budget', 'expByCat': 'Expenses by category', 'last6': 'Last 6 months',
    'exportPdf': 'Export PDF', 'exportXlsx': 'Export Excel', 'savedTo': 'Saved to',
    'title': 'Title', 'priority': 'Priority', 'high': 'High', 'medium': 'Medium', 'low': 'Low',
    'progress': 'Progress', 'remind': 'Remind at due time', 'list': 'List', 'calendar': 'Calendar',
    'open': 'Open', 'done': 'Done', 'all': 'All', 'noDue': 'No due date', 'pickDate': 'Pick date & time',
    'language': 'Language', 'theme': 'Theme', 'dark': 'Dark', 'light': 'Light', 'system': 'System',
    'currency': 'Currency symbol', 'arabic': 'العربية', 'english': 'English', 'required': 'Required', 'invalid': 'Invalid value',
    'todayTasks': "Today's tasks", 'upcoming': 'Upcoming', 'overdue': 'Overdue', 'recent': 'Recent transactions', 'activeDebts': 'Unpaid debts',
    'taskDone': 'Completion', 'about': 'About', 'phase1': 'Phase 1: foundation, finance, tasks',
    'incomeCats': 'Salary,Freelance,Gift,Investment,Other', 'expenseCats': 'Food,Transport,Bills,Shopping,Health,Fun,Education,Other',
    'confirmDel': 'Delete this item?', 'permNote': 'The system will ask for notification permission on first reminder.',
  },
};

String tr(BuildContext c, String k) {
  final l = Localizations.localeOf(c).languageCode;
  return _s[l]?[k] ?? _s['en']![k] ?? k;
}

String trL(String lang, String k) => _s[lang]?[k] ?? _s['en']![k] ?? k;
