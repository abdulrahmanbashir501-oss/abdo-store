import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:provider/provider.dart';
import 'dashboard.dart';
import 'finance.dart';
import 'l10n.dart';
import 'notifications.dart';
import 'settings.dart';
import 'state.dart';
import 'tasks.dart';
import 'theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Notifs.init();
  final st = AppState();
  await st.load();
  runApp(ChangeNotifierProvider.value(value: st, child: const AbodApp()));
}

class AbodApp extends StatelessWidget {
  const AbodApp({super.key});
  @override
  Widget build(BuildContext context) {
    final st = context.watch<AppState>();
    return MaterialApp(
      title: 'ABOD LIFE', debugShowCheckedModeBanner: false, locale: st.locale, themeMode: st.themeMode,
      theme: buildTheme(Brightness.light), darkTheme: buildTheme(Brightness.dark),
      supportedLocales: const [Locale('ar'), Locale('en')],
      localizationsDelegates: const [GlobalMaterialLocalizations.delegate, GlobalWidgetsLocalizations.delegate, GlobalCupertinoLocalizations.delegate],
      home: const Home(),
    );
  }
}

class Home extends StatefulWidget { const Home({super.key}); @override State<Home> createState() => _HomeState(); }

class _HomeState extends State<Home> {
  int i = 0;
  @override
  Widget build(BuildContext c) {
    final pages = [DashboardScreen((n) => setState(() => i = n)), const FinanceScreen(), const TasksScreen(), const SettingsScreen()];
    return Scaffold(
      body: IndexedStack(index: i, children: pages),
      bottomNavigationBar: NavigationBar(selectedIndex: i, onDestinationSelected: (n) => setState(() => i = n), destinations: [
        NavigationDestination(icon: const Icon(Icons.dashboard_outlined), selectedIcon: const Icon(Icons.dashboard, color: kRed), label: tr(c, 'dashboard')),
        NavigationDestination(icon: const Icon(Icons.account_balance_wallet_outlined), selectedIcon: const Icon(Icons.account_balance_wallet, color: kRed), label: tr(c, 'finance')),
        NavigationDestination(icon: const Icon(Icons.checklist), selectedIcon: const Icon(Icons.checklist, color: kRed), label: tr(c, 'tasks')),
        NavigationDestination(icon: const Icon(Icons.settings_outlined), selectedIcon: const Icon(Icons.settings, color: kRed), label: tr(c, 'settings')),
      ]),
    );
  }
}
