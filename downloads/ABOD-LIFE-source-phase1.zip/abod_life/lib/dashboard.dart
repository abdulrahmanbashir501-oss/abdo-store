import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'l10n.dart';
import 'state.dart';
import 'theme.dart';
import 'widgets.dart';

class DashboardScreen extends StatelessWidget {
  final void Function(int) go;
  const DashboardScreen(this.go, {super.key});
  @override
  Widget build(BuildContext c) {
    final st = c.watch<AppState>(); final now = DateTime.now();
    final inc = st.sum('income', month: now); final exp = st.sum('expense', month: now);
    final open = st.tasks.where((t) => !t.done).toList();
    final overdue = open.where((t) => t.due != null && t.due!.isBefore(now)).toList();
    final today = open.where((t) => t.due != null && DateUtils.isSameDay(t.due, now) && !t.due!.isBefore(now)).toList();
    final upcoming = open.where((t) => t.due != null && t.due!.isAfter(now) && !DateUtils.isSameDay(t.due, now)).take(3).toList();
    final doneCount = st.tasks.where((t) => t.done).length;
    final unpaid = st.debts.where((d) => !d.paid).toList();
    return Scaffold(
      appBar: AppBar(title: Text(tr(c, 'app'), style: const TextStyle(fontWeight: FontWeight.w900, letterSpacing: 2, color: kRed))),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Card(color: kRed, child: Padding(padding: const EdgeInsets.all(20), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(tr(c, 'balance'), style: const TextStyle(color: Colors.white70)),
          Text(money(st.balance, st.currency), style: const TextStyle(color: Colors.white, fontSize: 32, fontWeight: FontWeight.w900)),
          const SizedBox(height: 10),
          Text(tr(c, 'thisMonth'), style: const TextStyle(color: Colors.white70)),
          Text('${tr(c, 'income')}: ${money(inc, st.currency)}', style: const TextStyle(color: Colors.white)),
          Text('${tr(c, 'expense')}: ${money(exp, st.currency)}', style: const TextStyle(color: Colors.white)),
        ]))),
        const SizedBox(height: 8),
        Card(child: InkWell(onTap: () => go(2), child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [const Icon(Icons.checklist, color: kRed), const SizedBox(width: 8), Text(tr(c, 'tasks'), style: const TextStyle(fontWeight: FontWeight.bold)), const Spacer(),
            Text('${tr(c, 'open')}: ${open.length}   ${tr(c, 'done')}: $doneCount')]),
          if (st.tasks.isNotEmpty) ...[const SizedBox(height: 10), LinearProgressIndicator(value: doneCount / st.tasks.length, color: kRed, minHeight: 6, borderRadius: BorderRadius.circular(6)),
            const SizedBox(height: 4), Text('${tr(c, 'taskDone')}: ${(doneCount * 100 / st.tasks.length).round()}%', style: const TextStyle(color: Colors.grey, fontSize: 12))],
          if (overdue.isNotEmpty) ...[const SizedBox(height: 10), Text('${tr(c, 'overdue')} (${overdue.length})', style: const TextStyle(color: kRed, fontWeight: FontWeight.bold)), for (final t in overdue.take(3)) Text('- ${t.title}')],
          if (today.isNotEmpty) ...[const SizedBox(height: 10), Text(tr(c, 'todayTasks'), style: const TextStyle(fontWeight: FontWeight.bold)), for (final t in today.take(3)) Text('- ${t.title}')],
          if (upcoming.isNotEmpty) ...[const SizedBox(height: 10), Text(tr(c, 'upcoming'), style: const TextStyle(fontWeight: FontWeight.bold)), for (final t in upcoming) Text('- ${t.title}  (${dfmt(c, t.due!)})')],
          if (st.tasks.isEmpty) Padding(padding: const EdgeInsets.only(top: 8), child: Text(tr(c, 'noTasks'), style: const TextStyle(color: Colors.grey))),
        ])))),
        if (unpaid.isNotEmpty) Card(child: InkWell(onTap: () => go(1), child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(tr(c, 'activeDebts'), style: const TextStyle(fontWeight: FontWeight.bold)), const SizedBox(height: 6),
          for (final d in unpaid.take(3)) Text('${d.dir == 'owed_to_me' ? '↙' : '↗'} ${d.person}: ${money(d.amount, st.currency)}')])))),
        Card(child: InkWell(onTap: () => go(1), child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(tr(c, 'recent'), style: const TextStyle(fontWeight: FontWeight.bold)), const SizedBox(height: 6),
          if (st.txs.isEmpty) Text(tr(c, 'noTx'), style: const TextStyle(color: Colors.grey)),
          for (final t in st.txs.take(5)) Padding(padding: const EdgeInsets.symmetric(vertical: 3), child: Row(children: [Expanded(child: Text(t.category)),
            Text('${t.type == 'income' ? '+' : '-'}${money(t.amount, st.currency)}', style: TextStyle(color: t.type == 'income' ? kGreen : kRed, fontWeight: FontWeight.bold))])),
        ])))),
      ]),
    );
  }
}
