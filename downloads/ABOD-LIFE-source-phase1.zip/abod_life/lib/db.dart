import 'dart:io';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

class Db {
  static Database? _db;
  static Future<Database> get() async {
    if (_db != null) return _db!;
    final isDesktop = Platform.isWindows || Platform.isLinux || Platform.isMacOS;
    String path;
    if (isDesktop) {
      sqfliteFfiInit();
      databaseFactory = databaseFactoryFfi;
      final dir = await getApplicationSupportDirectory();
      path = p.join(dir.path, 'abod_life.db');
    } else {
      path = p.join(await getDatabasesPath(), 'abod_life.db');
    }
    _db = await openDatabase(path, version: 1, onCreate: (d, v) async {
      await d.execute('CREATE TABLE tx(id INTEGER PRIMARY KEY AUTOINCREMENT, type TEXT NOT NULL, amount REAL NOT NULL, category TEXT NOT NULL, note TEXT, date INTEGER NOT NULL)');
      await d.execute('CREATE TABLE debts(id INTEGER PRIMARY KEY AUTOINCREMENT, person TEXT NOT NULL, amount REAL NOT NULL, dir TEXT NOT NULL, due INTEGER, paid INTEGER NOT NULL DEFAULT 0, note TEXT)');
      await d.execute('CREATE TABLE budgets(id INTEGER PRIMARY KEY AUTOINCREMENT, category TEXT NOT NULL UNIQUE, lim REAL NOT NULL)');
      await d.execute('CREATE TABLE tasks(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, notes TEXT, priority INTEGER NOT NULL DEFAULT 1, due INTEGER, done INTEGER NOT NULL DEFAULT 0, progress INTEGER NOT NULL DEFAULT 0, remind INTEGER NOT NULL DEFAULT 0)');
    });
    return _db!;
  }
}
