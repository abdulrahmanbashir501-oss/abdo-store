import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'export.dart';
import 'l10n.dart';
import 'state.dart';
import 'theme.dart';
import 'widgets.dart';

class FinanceScreen extends StatefulWidget { const FinanceScreen({super.key}); @override State<FinanceScreen> createState() => _FS(); }

class _FS extends State<FinanceScreen> with SingleTickerProviderStateMixin {
  late final TabController tc = TabController(length: 4, vsync: this)..addListener(() => setState(() {}));
  @override
  void dispose() { tc.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext c) {
    return Scaffold(
      appBar: AppBar(title: Text(tr(c, 'finance')), actions: [
        PopupMenuButton<String>(icon: const Icon(Icons.ios_share), onSelected: (v) async {
          final st = c.read<AppState>();
          final msg = ScaffoldMessenger.of(c); final lbl = tr(c, 'savedTo');
          try {
            final path = v == 'pdf' ? await Export.pdf(st, Localizations.localeOf(c).languageCode) : await Export.xlsx(st, Localizations.localeOf(c).languageCode);
            msg.showSnackBar(SnackBar(content: Text('$lbl $path')));
          } catch (e) { msg.showSnackBar(SnackBar(content: Text('$e'))); }
        }, itemBuilder: (_) => [PopupMenuItem(value: 'pdf', child: Text(tr(c, 'exportPdf'))), PopupMenuItem(value: 'xlsx', child: Text(tr(c, 'exportXlsx')))]),
      ], bottom: TabBar(controller: tc, isScrollable: true, indicatorColor: kRed, tabs: [
        Tab(text: tr(c, 'transactions')), Tab(text: tr(c, 'debts')), Tab(text: tr(c, 'budget')), Tab(text: tr(c, 'charts'))])),
      body: TabBarView(controller: tc, children: const [_TxList(), _DebtList(), _BudgetList(), _Charts()]),
      floatingActionButton: tc.index == 3 ? null : FloatingActionButton(onPressed: () {
        switch (tc.index) { case 0: txDialog(c); break; case 1: debtDialog(c); break; case 2: budgetDialog(c); break; }
      }, child: const Icon(Icons.add)),
    );
  }
}

Future<void> txDialog(BuildContext c, {Tx? edit}) async {
  final st = c.read<AppState>();
  var type = edit?.type ?? 'expense'; var date = edit?.date ?? DateTime.now();
  final amt = TextEditingController(text: edit == null ? '' : edit.amount.toString()); final note = TextEditingController(text: edit?.note ?? '');
  String? cat = edit?.category; final key = GlobalKey<FormState>();
  await showDialog(context: c, builder: (dc) => StatefulBuilder(builder: (dc, set) {
    final cl = cats(c, type); if (cat == null || !cl.contains(cat)) cat = cl.first;
    return AlertDialog(title: Text(tr(c, edit == null ? 'add' : 'edit')), content: SingleChildScrollView(child: Form(key: key, child: Column(mainAxisSize: MainAxisSize.min, children: [
      SegmentedButton<String>(segments: [ButtonSegment(value: 'expense', label: Text(tr(c, 'expense'))), ButtonSegment(value: 'income', label: Text(tr(c, 'income')))],
          selected: {type}, onSelectionChanged: (s) => set(() { type = s.first; cat = null; })),
      const SizedBox(height: 12),
      TextFormField(controller: amt, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: InputDecoration(labelText: tr(c, 'amount')),
          validator: (v) => parseAmount(v ?? '') == null ? tr(c, 'invalid') : null),
      const SizedBox(height: 12),
      DropdownButtonFormField<String>(value: cat, items: cl.map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(), onChanged: (v) => cat = v, decoration: InputDecoration(labelText: tr(c, 'category'))),
      const SizedBox(height: 12),
      TextField(controller: note, decoration: InputDecoration(labelText: tr(c, 'note'))),
      const SizedBox(height: 8),
      OutlinedButton.icon(icon: const Icon(Icons.event), label: Text(dfmt(c, date)), onPressed: () async { final d = await pickDateTime(c, initial: date, withTime: false); if (d != null) set(() => date = d); }),
    ]))), actions: [
      TextButton(onPressed: () => Navigator.pop(dc), child: Text(tr(c, 'cancel'))),
      FilledButton(onPressed: () async {
        if (!key.currentState!.validate()) return;
        await st.saveTx(Tx(id: edit?.id, type: type, amount: parseAmount(amt.text)!, category: cat!, note: note.text.trim(), date: date));
        if (dc.mounted) Navigator.pop(dc);
      }, child: Text(tr(c, 'save'))),
    ]);
  }));
}

class _TxList extends StatelessWidget {
  const _TxList();
  @override
  Widget build(BuildContext c) {
    final st = c.watch<AppState>();
    if (st.txs.isEmpty) return Empty(tr(c, 'noTx'), icon: Icons.receipt_long_outlined);
    return ListView(padding: const EdgeInsets.all(12), children: [
      Row(children: [
        Expanded(child: _Mini(tr(c, 'income'), money(st.sum('income'), st.currency), kGreen)),
        const SizedBox(width: 8),
        Expanded(child: _Mini(tr(c, 'expense'), money(st.sum('expense'), st.currency), kRed)),
      ]),
      const SizedBox(height: 8),
      for (final t in st.txs) Dismissible(
        key: ValueKey('tx${t.id}'), confirmDismiss: (_) => confirmDelete(c), onDismissed: (_) => st.deleteTx(t.id!),
        background: Container(color: kRed, alignment: AlignmentDirectional.centerStart, padding: const EdgeInsets.all(16), child: const Icon(Icons.delete)),
        child: Card(child: ListTile(onTap: () => txDialog(c, edit: t),
          leading: CircleAvatar(backgroundColor: (t.type == 'income' ? kGreen : kRed).withOpacity(.2), child: Icon(t.type == 'income' ? Icons.arrow_downward : Icons.arrow_upward, color: t.type == 'income' ? kGreen : kRed)),
          title: Text(t.category), subtitle: Text('${dfmt(c, t.date)}${t.note.isEmpty ? '' : ' - ${t.note}'}'),
          trailing: Text('${t.type == 'income' ? '+' : '-'}${money(t.amount, st.currency)}', style: TextStyle(fontWeight: FontWeight.bold, color: t.type == 'income' ? kGreen : kRed))))),
    ]);
  }
}

class _Mini extends StatelessWidget {
  final String l, v; final Color col;
  const _Mini(this.l, this.v, this.col);
  @override
  Widget build(BuildContext c) => Card(child: Padding(padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Text(l, style: const TextStyle(color: Colors.grey)), const SizedBox(height: 4), Text(v, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: col))])));
}

Future<void> debtDialog(BuildContext c, {Debt? edit}) async {
  final st = c.read<AppState>();
  var dir = edit?.dir ?? 'owed_to_me'; DateTime? due = edit?.due;
  final person = TextEditingController(text: edit?.person ?? ''); final amt = TextEditingController(text: edit == null ? '' : edit.amount.toString()); final note = TextEditingController(text: edit?.note ?? '');
  final key = GlobalKey<FormState>();
  await showDialog(context: c, builder: (dc) => StatefulBuilder(builder: (dc, set) => AlertDialog(title: Text(tr(c, edit == null ? 'add' : 'edit')),
    content: SingleChildScrollView(child: Form(key: key, child: Column(mainAxisSize: MainAxisSize.min, children: [
      SegmentedButton<String>(segments: [ButtonSegment(value: 'owed_to_me', label: Text(tr(c, 'owedToMe'))), ButtonSegment(value: 'i_owe', label: Text(tr(c, 'iOwe')))],
          selected: {dir}, onSelectionChanged: (s) => set(() => dir = s.first)),
      const SizedBox(height: 12),
      TextFormField(controller: person, decoration: InputDecoration(labelText: tr(c, 'person')), validator: (v) => (v ?? '').trim().isEmpty ? tr(c, 'required') : null),
      const SizedBox(height: 12),
      TextFormField(controller: amt, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: InputDecoration(labelText: tr(c, 'amount')), validator: (v) => parseAmount(v ?? '') == null ? tr(c, 'invalid') : null),
      const SizedBox(height: 12),
      TextField(controller: note, decoration: InputDecoration(labelText: tr(c, 'note'))),
      const SizedBox(height: 8),
      OutlinedButton.icon(icon: const Icon(Icons.event), label: Text(due == null ? '${tr(c, 'due')}: ${tr(c, 'noDue')}' : dfmt(c, due!)),
          onPressed: () async { final d = await pickDateTime(c, initial: due, withTime: false); if (d != null) set(() => due = d); }),
    ]))), actions: [
      TextButton(onPressed: () => Navigator.pop(dc), child: Text(tr(c, 'cancel'))),
      FilledButton(onPressed: () async {
        if (!key.currentState!.validate()) return;
        await st.saveDebt(Debt(id: edit?.id, person: person.text.trim(), amount: parseAmount(amt.text)!, dir: dir, due: due, paid: edit?.paid ?? false, note: note.text.trim()));
        if (dc.mounted) Navigator.pop(dc);
      }, child: Text(tr(c, 'save'))),
    ])));
}

class _DebtList extends StatelessWidget {
  const _DebtList();
  @override
  Widget build(BuildContext c) {
    final st = c.watch<AppState>();
    if (st.debts.isEmpty) return Empty(tr(c, 'noDebts'), icon: Icons.handshake_outlined);
    final toMe = st.debts.where((d) => !d.paid && d.dir == 'owed_to_me').fold(0.0, (a, d) => a + d.amount);
    final iOwe = st.debts.where((d) => !d.paid && d.dir == 'i_owe').fold(0.0, (a, d) => a + d.amount);
    return ListView(padding: const EdgeInsets.all(12), children: [
      Row(children: [Expanded(child: _Mini(tr(c, 'owedToMe'), money(toMe, st.currency), kGreen)), const SizedBox(width: 8), Expanded(child: _Mini(tr(c, 'iOwe'), money(iOwe, st.currency), kRed))]),
      const SizedBox(height: 8),
      for (final d in st.debts) Dismissible(key: ValueKey('d${d.id}'), confirmDismiss: (_) => confirmDelete(c), onDismissed: (_) => st.deleteDebt(d.id!),
        background: Container(color: kRed, alignment: AlignmentDirectional.centerStart, padding: const EdgeInsets.all(16), child: const Icon(Icons.delete)),
        child: Card(child: ListTile(onTap: () => debtDialog(c, edit: d),
          leading: Icon(d.dir == 'owed_to_me' ? Icons.call_received : Icons.call_made, color: d.dir == 'owed_to_me' ? kGreen : kRed),
          title: Text(d.person, style: TextStyle(decoration: d.paid ? TextDecoration.lineThrough : null)),
          subtitle: Text([tr(c, d.dir == 'owed_to_me' ? 'owedToMe' : 'iOwe'), if (d.due != null) '${tr(c, 'due')}: ${dfmt(c, d.due!)}', if (d.paid) tr(c, 'paid'), if (d.note.isNotEmpty) d.note].join(' | ')),
          trailing: Row(mainAxisSize: MainAxisSize.min, children: [Text(money(d.amount, st.currency), style: const TextStyle(fontWeight: FontWeight.bold)),
            IconButton(tooltip: tr(c, 'markPaid'), icon: Icon(d.paid ? Icons.check_circle : Icons.check_circle_outline, color: d.paid ? kGreen : null), onPressed: () { d.paid = !d.paid; st.saveDebt(d); })])))),
    ]);
  }
}

Future<void> budgetDialog(BuildContext c) async {
  final st = c.read<AppState>(); final cl = cats(c, 'expense'); String cat = cl.first;
  final lim = TextEditingController(); final key = GlobalKey<FormState>();
  await showDialog(context: c, builder: (dc) => AlertDialog(title: Text(tr(c, 'budget')), content: Form(key: key, child: Column(mainAxisSize: MainAxisSize.min, children: [
    DropdownButtonFormField<String>(value: cat, items: cl.map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(), onChanged: (v) => cat = v!, decoration: InputDecoration(labelText: tr(c, 'category'))),
    const SizedBox(height: 12),
    TextFormField(controller: lim, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: InputDecoration(labelText: tr(c, 'limit')), validator: (v) => parseAmount(v ?? '') == null ? tr(c, 'invalid') : null),
  ])), actions: [
    TextButton(onPressed: () => Navigator.pop(dc), child: Text(tr(c, 'cancel'))),
    FilledButton(onPressed: () async { if (!key.currentState!.validate()) return; await st.saveBudget(cat, parseAmount(lim.text)!); if (dc.mounted) Navigator.pop(dc); }, child: Text(tr(c, 'save'))),
  ]));
}

class _BudgetList extends StatelessWidget {
  const _BudgetList();
  @override
  Widget build(BuildContext c) {
    final st = c.watch<AppState>(); final now = DateTime.now();
    if (st.budgets.isEmpty) return Empty(tr(c, 'noBudgets'), icon: Icons.pie_chart_outline);
    return ListView(padding: const EdgeInsets.all(12), children: [
      for (final b in st.budgets) Dismissible(key: ValueKey('b${b.id}'), confirmDismiss: (_) => confirmDelete(c), onDismissed: (_) => st.deleteBudget(b.id!),
        background: Container(color: kRed, alignment: AlignmentDirectional.centerStart, padding: const EdgeInsets.all(16), child: const Icon(Icons.delete)),
        child: Builder(builder: (c) {
          final spent = st.spentIn(b.category, now); final r = (spent / b.limit); final over = spent > b.limit;
          return Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [Text(b.category, style: const TextStyle(fontWeight: FontWeight.bold)), const Spacer(), Text('${money(spent, st.currency)} / ${money(b.limit, st.currency)}')]),
            const SizedBox(height: 8),
            LinearProgressIndicator(value: r.clamp(0, 1).toDouble(), minHeight: 8, borderRadius: BorderRadius.circular(8), color: over ? kRed : (r > .8 ? Colors.orange : kGreen)),
            const SizedBox(height: 6),
            Text(over ? '${tr(c, 'over')}: ${money(spent - b.limit, st.currency)}' : '${tr(c, 'remaining')}: ${money(b.limit - spent, st.currency)}', style: TextStyle(color: over ? kRed : Colors.grey)),
          ])));
        })),
    ]);
  }
}

class _Charts extends StatelessWidget {
  const _Charts();
  @override
  Widget build(BuildContext c) {
    final st = c.watch<AppState>(); final now = DateTime.now();
    final by = st.expenseByCategory(now);
    if (st.txs.isEmpty) return Empty(tr(c, 'noChart'), icon: Icons.bar_chart);
    final cols = [kRed, Colors.white70, Colors.orange, Colors.blueAccent, kGreen, Colors.purpleAccent, Colors.teal, Colors.grey];
    final months = [for (var i = 5; i >= 0; i--) DateTime(now.year, now.month - i, 1)];
    final inc = months.map((m) => st.sum('income', month: m)).toList(); final exp = months.map((m) => st.sum('expense', month: m)).toList();
    final mx = [...inc, ...exp].fold(1.0, (a, b) => b > a ? b : a);
    return ListView(padding: const EdgeInsets.all(16), children: [
      Text('${tr(c, 'expByCat')} (${tr(c, 'thisMonth')})', style: const TextStyle(fontWeight: FontWeight.bold)),
      const SizedBox(height: 12),
      if (by.isEmpty) Padding(padding: const EdgeInsets.all(20), child: Text(tr(c, 'noChart'), textAlign: TextAlign.center, style: const TextStyle(color: Colors.grey)))
      else ...[
        SizedBox(height: 200, child: PieChart(PieChartData(sectionsSpace: 2, centerSpaceRadius: 40, sections: [
          for (var i = 0; i < by.length; i++) PieChartSectionData(value: by.values.elementAt(i), color: cols[i % cols.length], radius: 60, showTitle: false)]))),
        const SizedBox(height: 8),
        Wrap(spacing: 12, runSpacing: 4, children: [for (var i = 0; i < by.length; i++) Row(mainAxisSize: MainAxisSize.min, children: [
          Container(width: 12, height: 12, color: cols[i % cols.length]), const SizedBox(width: 4), Text('${by.keys.elementAt(i)}: ${money(by.values.elementAt(i), st.currency)}')])]),
      ],
      const SizedBox(height: 28),
      Text(tr(c, 'last6'), style: const TextStyle(fontWeight: FontWeight.bold)),
      Row(children: [Container(width: 12, height: 12, color: kGreen), Text(' ${tr(c, 'income')}   '), Container(width: 12, height: 12, color: kRed), Text(' ${tr(c, 'expense')}')]),
      const SizedBox(height: 12),
      SizedBox(height: 220, child: Directionality(textDirection: TextDirection.ltr, child: BarChart(BarChartData(maxY: mx * 1.2, gridData: const FlGridData(show: false), borderData: FlBorderData(show: false),
        titlesData: FlTitlesData(topTitles: const AxisTitles(), rightTitles: const AxisTitles(), leftTitles: const AxisTitles(),
          bottomTitles: AxisTitles(sideTitles: SideTitles(showTitles: true, getTitlesWidget: (v, m) => Text('${months[v.toInt()].month}', style: const TextStyle(fontSize: 12))))),
        barGroups: [for (var i = 0; i < 6; i++) BarChartGroupData(x: i, barRods: [BarChartRodData(toY: inc[i], color: kGreen, width: 10), BarChartRodData(toY: exp[i], color: kRed, width: 10)])])))),
    ]);
  }
}
