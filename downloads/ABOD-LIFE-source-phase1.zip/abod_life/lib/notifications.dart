import 'dart:io';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_timezone/flutter_timezone.dart';
import 'package:timezone/data/latest_all.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;

class Notifs {
  static final _p = FlutterLocalNotificationsPlugin();
  static bool _ok = false;
  static Future<void> init() async {
    if (!Platform.isAndroid) return;
    try {
      tzdata.initializeTimeZones();
      final name = await FlutterTimezone.getLocalTimezone();
      tz.setLocalLocation(tz.getLocation(name.toString().contains('TimezoneInfo') ? 'UTC' : name.toString()));
    } catch (_) {}
    try {
      await _p.initialize(settings: const InitializationSettings(android: AndroidInitializationSettings('@mipmap/ic_launcher')));
      _ok = true;
    } catch (_) {}
  }

  static Future<void> schedule(int id, String title, DateTime when) async {
    if (!_ok || when.isBefore(DateTime.now())) return;
    try {
      await _p.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()?.requestNotificationsPermission();
      await _p.zonedSchedule(id: id, title: 'ABOD LIFE', body: title, scheduledDate: tz.TZDateTime.from(when, tz.local),
          notificationDetails: const NotificationDetails(android: AndroidNotificationDetails('tasks', 'Task reminders', importance: Importance.high, priority: Priority.high)),
          androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle);
    } catch (_) {}
  }

  static Future<void> cancel(int id) async {
    if (!_ok) return;
    try { await _p.cancel(id: id); } catch (_) {}
  }
}
