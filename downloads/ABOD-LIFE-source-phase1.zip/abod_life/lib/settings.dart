import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'l10n.dart';
import 'state.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});
  @override
  Widget build(BuildContext c) {
    final st = c.watch<AppState>();
    return Scaffold(appBar: AppBar(title: Text(tr(c, 'settings'))), body: ListView(padding: const EdgeInsets.all(16), children: [
      Text(tr(c, 'language'), style: const TextStyle(fontWeight: FontWeight.bold)), const SizedBox(height: 8),
      SegmentedButton<String>(segments: [ButtonSegment(value: 'ar', label: Text(tr(c, 'arabic'))), ButtonSegment(value: 'en', label: Text(tr(c, 'english')))], selected: {st.locale.languageCode}, onSelectionChanged: (s) => st.setLang(s.first)),
      const SizedBox(height: 24),
      Text(tr(c, 'theme'), style: const TextStyle(fontWeight: FontWeight.bold)), const SizedBox(height: 8),
      SegmentedButton<ThemeMode>(segments: [ButtonSegment(value: ThemeMode.dark, label: Text(tr(c, 'dark'))), ButtonSegment(value: ThemeMode.light, label: Text(tr(c, 'light'))), ButtonSegment(value: ThemeMode.system, label: Text(tr(c, 'system')))],
        selected: {st.themeMode}, onSelectionChanged: (s) => st.setTheme(s.first)),
      const SizedBox(height: 24),
      TextFormField(initialValue: st.currency, decoration: InputDecoration(labelText: tr(c, 'currency')), onChanged: (v) { if (v.trim().isNotEmpty) st.setCurrency(v.trim()); }),
      const SizedBox(height: 32),
      ListTile(leading: const Icon(Icons.info_outline), title: Text(tr(c, 'about')), subtitle: Text('ABOD LIFE v0.1.0\n${tr(c, 'phase1')}')),
    ]));
  }
}
