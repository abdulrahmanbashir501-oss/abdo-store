import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart' show ConflictAlgorithm;
import 'package:shared_preferences/shared_preferences.dart';
import 'db.dart';
import 'notifications.dart';

class Tx {
  int? id; String type; double amount; String category; String note; DateTime date;
  Tx({this.id, required this.type, required this.amount, required this.category, this.note = '', required this.date});
  factory Tx.fromMap(Map<String, Object?> m) => Tx(id: m['id'] as int, type: m['type'] as String, amount: (m['amount'] as num).toDouble(),
      category: m['category'] as String, note: (m['note'] as String?) ?? '', date: DateTime.fromMillisecondsSinceEpoch(m['date'] as int));
  Map<String, Object?> toMap() => {'type': type, 'amount': amount, 'category': category, 'note': note, 'date': date.millisecondsSinceEpoch};
}

class Debt {
  int? id; String person; double amount; String dir; DateTime? due; bool paid; String note;
  Debt({this.id, required this.person, required this.amount, required this.dir, this.due, this.paid = false, this.note = ''});
  factory Debt.fromMap(Map<String, Object?> m) => Debt(id: m['id'] as int, person: m['person'] as String, amount: (m['amount'] as num).toDouble(),
      dir: m['dir'] as String, due: m['due'] == null ? null : DateTime.fromMillisecondsSinceEpoch(m['due'] as int), paid: m['paid'] == 1, note: (m['note'] as String?) ?? '');
  Map<String, Object?> toMap() => {'person': person, 'amount': amount, 'dir': dir, 'due': due?.millisecondsSinceEpoch, 'paid': paid ? 1 : 0, 'note': note};
}

class Budget { int? id; String category; double limit; Budget({this.id, required this.category, required this.limit}); }

class Task {
  int? id; String title; String notes; int priority; DateTime? due; bool done; int progress; bool remind;
  Task({this.id, required this.title, this.notes = '', this.priority = 1, this.due, this.done = false, this.progress = 0, this.remind = false});
  factory Task.fromMap(Map<String, Object?> m) => Task(id: m['id'] as int, title: m['title'] as String, notes: (m['notes'] as String?) ?? '',
      priority: m['priority'] as int, due: m['due'] == null ? null : DateTime.fromMillisecondsSinceEpoch(m['due'] as int),
      done: m['done'] == 1, progress: m['progress'] as int, remind: m['remind'] == 1);
  Map<String, Object?> toMap() => {'title': title, 'notes': notes, 'priority': priority, 'due': due?.millisecondsSinceEpoch,
      'done': done ? 1 : 0, 'progress': progress, 'remind': remind ? 1 : 0};
}

class AppState extends ChangeNotifier {
  Locale locale = const Locale('ar');
  ThemeMode themeMode = ThemeMode.dark;
  String currency = 'EGP';
  List<Tx> txs = []; List<Debt> debts = []; List<Budget> budgets = []; List<Task> tasks = [];
  bool loaded = false;

  Future<void> load() async {
    final sp = await SharedPreferences.getInstance();
    locale = Locale(sp.getString('lang') ?? 'ar');
    themeMode = ThemeMode.values[sp.getInt('theme') ?? 2];
    currency = sp.getString('cur') ?? 'EGP';
    await _reload();
    loaded = true;
    notifyListeners();
  }

  Future<void> _reload() async {
    final d = await Db.get();
    txs = (await d.query('tx', orderBy: 'date DESC, id DESC')).map(Tx.fromMap).toList();
    debts = (await d.query('debts', orderBy: 'paid ASC, id DESC')).map(Debt.fromMap).toList();
    budgets = (await d.query('budgets', orderBy: 'category')).map((m) => Budget(id: m['id'] as int, category: m['category'] as String, limit: (m['lim'] as num).toDouble())).toList();
    tasks = (await d.query('tasks', orderBy: 'done ASC, due IS NULL, due ASC, priority DESC')).map(Task.fromMap).toList();
  }

  Future<void> setLang(String l) async { locale = Locale(l); (await SharedPreferences.getInstance()).setString('lang', l); notifyListeners(); }
  Future<void> setTheme(ThemeMode m) async { themeMode = m; (await SharedPreferences.getInstance()).setInt('theme', m.index); notifyListeners(); }
  Future<void> setCurrency(String c) async { currency = c; (await SharedPreferences.getInstance()).setString('cur', c); notifyListeners(); }

  // Finance
  Future<void> saveTx(Tx t) async {
    final d = await Db.get();
    if (t.id == null) { await d.insert('tx', t.toMap()); } else { await d.update('tx', t.toMap(), where: 'id=?', whereArgs: [t.id]); }
    await _reload(); notifyListeners();
  }
  Future<void> deleteTx(int id) async { (await Db.get()).delete('tx', where: 'id=?', whereArgs: [id]); await _reload(); notifyListeners(); }
  Future<void> saveDebt(Debt t) async {
    final d = await Db.get();
    if (t.id == null) { await d.insert('debts', t.toMap()); } else { await d.update('debts', t.toMap(), where: 'id=?', whereArgs: [t.id]); }
    await _reload(); notifyListeners();
  }
  Future<void> deleteDebt(int id) async { await (await Db.get()).delete('debts', where: 'id=?', whereArgs: [id]); await _reload(); notifyListeners(); }
  Future<void> saveBudget(String cat, double lim) async {
    final d = await Db.get();
    await d.insert('budgets', {'category': cat, 'lim': lim}, conflictAlgorithm: ConflictAlgorithm.replace);
    await _reload(); notifyListeners();
  }
  Future<void> deleteBudget(int id) async { await (await Db.get()).delete('budgets', where: 'id=?', whereArgs: [id]); await _reload(); notifyListeners(); }

  // Tasks
  Future<void> saveTask(Task t) async {
    final d = await Db.get();
    int id;
    if (t.id == null) { id = await d.insert('tasks', t.toMap()); } else { id = t.id!; await d.update('tasks', t.toMap(), where: 'id=?', whereArgs: [id]); }
    await Notifs.cancel(id);
    if (t.remind && !t.done && t.due != null) await Notifs.schedule(id, t.title, t.due!);
    await _reload(); notifyListeners();
  }
  Future<void> deleteTask(int id) async { await Notifs.cancel(id); await (await Db.get()).delete('tasks', where: 'id=?', whereArgs: [id]); await _reload(); notifyListeners(); }

  // Derived
  bool _sameMonth(DateTime a, DateTime b) => a.year == b.year && a.month == b.month;
  double sum(String type, {DateTime? month}) => txs.where((t) => t.type == type && (month == null || _sameMonth(t.date, month))).fold(0.0, (a, t) => a + t.amount);
  double get balance => sum('income') - sum('expense');
  Map<String, double> expenseByCategory(DateTime month) {
    final m = <String, double>{};
    for (final t in txs.where((t) => t.type == 'expense' && _sameMonth(t.date, month))) { m[t.category] = (m[t.category] ?? 0) + t.amount; }
    return m;
  }
  double spentIn(String cat, DateTime month) => expenseByCategory(month)[cat] ?? 0;
}
