import 'package:flutter/material.dart';

const kRed = Color(0xFFE5173F);
const kBlack = Color(0xFF0A0A0C);
const kCard = Color(0xFF16161A);
const kGreen = Color(0xFF22C55E);

ThemeData buildTheme(Brightness b) {
  final dark = b == Brightness.dark;
  final bg = dark ? kBlack : const Color(0xFFF6F6F8);
  final card = dark ? kCard : Colors.white;
  final fg = dark ? Colors.white : const Color(0xFF111114);
  final scheme = ColorScheme(
    brightness: b, primary: kRed, onPrimary: Colors.white, secondary: kRed, onSecondary: Colors.white,
    error: const Color(0xFFFF5470), onError: Colors.white, surface: card, onSurface: fg,
  );
  return ThemeData(
    useMaterial3: true, fontFamily: 'Cairo', colorScheme: scheme, scaffoldBackgroundColor: bg,
    cardTheme: CardThemeData(color: card, elevation: 0, margin: const EdgeInsets.symmetric(vertical: 5),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16), side: BorderSide(color: dark ? const Color(0xFF2A2A30) : const Color(0xFFE4E4E8)))),
    appBarTheme: AppBarTheme(backgroundColor: bg, foregroundColor: fg, elevation: 0, centerTitle: false),
    navigationBarTheme: NavigationBarThemeData(backgroundColor: card, indicatorColor: kRed.withOpacity(.25)),
    floatingActionButtonTheme: const FloatingActionButtonThemeData(backgroundColor: kRed, foregroundColor: Colors.white),
    inputDecorationTheme: InputDecorationTheme(border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)), filled: true,
        fillColor: dark ? const Color(0xFF1E1E24) : const Color(0xFFF0F0F3)),
    dialogTheme: DialogThemeData(backgroundColor: card),
  );
}
