import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'l10n.dart';
import 'state.dart';
import 'theme.dart';
import 'widgets.dart';

Color prioColor(int p) => p == 2 ? kRed : (p == 1 ? Colors.orange : Colors.blueGrey);

Future<void> taskDialog(BuildContext c, {Task? edit, DateTime? presetDue}) async {
  final st = c.read<AppState>();
  final title = TextEditingController(text: edit?.title ?? ''); final notes = TextEditingController(text: edit?.notes ?? '');
  var prio = edit?.priority ?? 1; DateTime? due = edit?.due ?? presetDue; var prog = (edit?.progress ?? 0).toDouble(); var remind = edit?.remind ?? false;
  final key = GlobalKey<FormState>();
  await showDialog(context: c, builder: (dc) => StatefulBuilder(builder: (dc, set) => AlertDialog(title: Text(tr(c, edit == null ? 'add' : 'edit')),
    content: SingleChildScrollView(child: Form(key: key, child: Column(mainAxisSize: MainAxisSize.min, children: [
      TextFormField(controller: title, decoration: InputDecoration(labelText: tr(c, 'title')), validator: (v) => (v ?? '').trim().isEmpty ? tr(c, 'required') : null),
      const SizedBox(height: 12),
      TextField(controller: notes, decoration: InputDecoration(labelText: tr(c, 'note')), maxLines: 2),
      const SizedBox(height: 12),
      SegmentedButton<int>(segments: [ButtonSegment(value: 0, label: Text(tr(c, 'low'))), ButtonSegment(value: 1, label: Text(tr(c, 'medium'))), ButtonSegment(value: 2, label: Text(tr(c, 'high')))],
          selected: {prio}, onSelectionChanged: (s) => set(() => prio = s.first)),
      const SizedBox(height: 8),
      OutlinedButton.icon(icon: const Icon(Icons.event), label: Text(due == null ? tr(c, 'pickDate') : dtfmt(c, due!)), onPressed: () async { final d = await pickDateTime(c, initial: due); if (d != null) set(() => due = d); }),
      if (due != null) TextButton(onPressed: () => set(() { due = null; remind = false; }), child: Text(tr(c, 'noDue'))),
      Row(children: [Text('${tr(c, 'progress')}: ${prog.round()}%'), Expanded(child: Slider(value: prog, min: 0, max: 100, divisions: 20, onChanged: (v) => set(() => prog = v)))]),
      SwitchListTile(contentPadding: EdgeInsets.zero, title: Text(tr(c, 'remind')), subtitle: Text(tr(c, 'permNote'), style: const TextStyle(fontSize: 11)), value: remind && due != null,
          onChanged: due == null ? null : (v) => set(() => remind = v)),
    ]))), actions: [
      TextButton(onPressed: () => Navigator.pop(dc), child: Text(tr(c, 'cancel'))),
      FilledButton(onPressed: () async {
        if (!key.currentState!.validate()) return;
        await st.saveTask(Task(id: edit?.id, title: title.text.trim(), notes: notes.text.trim(), priority: prio, due: due, progress: prog.round(), done: prog.round() >= 100 ? true : (edit?.done ?? false), remind: remind && due != null));
        if (dc.mounted) Navigator.pop(dc);
      }, child: Text(tr(c, 'save'))),
    ])));
}

class TasksScreen extends StatefulWidget { const TasksScreen({super.key}); @override State<TasksScreen> createState() => _TS(); }

class _TS extends State<TasksScreen> {
  bool cal = false; String filter = 'open'; DateTime month = DateTime(DateTime.now().year, DateTime.now().month); DateTime sel = DateTime.now();

  @override
  Widget build(BuildContext c) {
    final st = c.watch<AppState>();
    return Scaffold(
      appBar: AppBar(title: Text(tr(c, 'tasks')), actions: [
        IconButton(icon: Icon(cal ? Icons.view_list : Icons.calendar_month), tooltip: tr(c, cal ? 'list' : 'calendar'), onPressed: () => setState(() => cal = !cal))]),
      body: cal ? _calendar(c, st) : _list(c, st),
      floatingActionButton: FloatingActionButton(onPressed: () => taskDialog(c, presetDue: cal ? DateTime(sel.year, sel.month, sel.day, 9) : null), child: const Icon(Icons.add)),
    );
  }

  Widget _tile(BuildContext c, AppState st, Task t) => Dismissible(key: ValueKey('t${t.id}'), confirmDismiss: (_) => confirmDelete(c), onDismissed: (_) => st.deleteTask(t.id!),
    background: Container(color: kRed, alignment: AlignmentDirectional.centerStart, padding: const EdgeInsets.all(16), child: const Icon(Icons.delete)),
    child: Card(child: ListTile(onTap: () => taskDialog(c, edit: t),
      leading: Checkbox(value: t.done, activeColor: kRed, onChanged: (v) { t.done = v ?? false; t.progress = t.done ? 100 : (t.progress == 100 ? 0 : t.progress); st.saveTask(t); }),
      title: Text(t.title, style: TextStyle(decoration: t.done ? TextDecoration.lineThrough : null)),
      subtitle: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        if (t.due != null) Text(dtfmt(c, t.due!), style: TextStyle(color: !t.done && t.due!.isBefore(DateTime.now()) ? kRed : Colors.grey, fontSize: 12)),
        if (t.progress > 0) Padding(padding: const EdgeInsets.only(top: 4), child: LinearProgressIndicator(value: t.progress / 100, color: kRed, minHeight: 4)),
      ]),
      trailing: Row(mainAxisSize: MainAxisSize.min, children: [if (t.remind) const Icon(Icons.alarm, size: 16), const SizedBox(width: 6), Icon(Icons.flag, color: prioColor(t.priority))]))));

  Widget _list(BuildContext c, AppState st) {
    final l = st.tasks.where((t) => filter == 'all' || (filter == 'open' ? !t.done : t.done)).toList();
    return Column(children: [
      Padding(padding: const EdgeInsets.all(12), child: SegmentedButton<String>(segments: [for (final k in ['open', 'done', 'all']) ButtonSegment(value: k, label: Text(tr(c, k)))], selected: {filter}, onSelectionChanged: (s) => setState(() => filter = s.first))),
      Expanded(child: l.isEmpty ? Empty(tr(c, 'noTasks'), icon: Icons.checklist) : ListView(padding: const EdgeInsets.symmetric(horizontal: 12), children: [for (final t in l) _tile(c, st, t)])),
    ]);
  }

  Widget _calendar(BuildContext c, AppState st) {
    final lang = Localizations.localeOf(c).languageCode;
    final first = DateTime(month.year, month.month, 1); final days = DateUtils.getDaysInMonth(month.year, month.month);
    final lead = (first.weekday + 1) % 7; // Saturday first
    final names = [for (var i = 0; i < 7; i++) DateFormat.E(lang).format(DateTime(2024, 1, 6 + i))];
    bool has(int d) => st.tasks.any((t) => t.due != null && DateUtils.isSameDay(t.due, DateTime(month.year, month.month, d)));
    final dayTasks = st.tasks.where((t) => t.due != null && DateUtils.isSameDay(t.due, sel)).toList();
    return Column(children: [
      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        IconButton(icon: const Icon(Icons.chevron_left), onPressed: () => setState(() => month = DateTime(month.year, month.month - 1))),
        Text(DateFormat.yMMMM(lang).format(month), style: const TextStyle(fontWeight: FontWeight.bold)),
        IconButton(icon: const Icon(Icons.chevron_right), onPressed: () => setState(() => month = DateTime(month.year, month.month + 1)))]),
      Padding(padding: const EdgeInsets.symmetric(horizontal: 8), child: Row(children: [for (final n in names) Expanded(child: Center(child: Text(n, style: const TextStyle(color: Colors.grey, fontSize: 11))))])),
      Padding(padding: const EdgeInsets.all(8), child: GridView.count(crossAxisCount: 7, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), children: [
        for (var i = 0; i < lead; i++) const SizedBox(),
        for (var d = 1; d <= days; d++) InkWell(onTap: () => setState(() => sel = DateTime(month.year, month.month, d)), child: Container(margin: const EdgeInsets.all(2),
          decoration: BoxDecoration(color: DateUtils.isSameDay(sel, DateTime(month.year, month.month, d)) ? kRed : null, borderRadius: BorderRadius.circular(10),
            border: DateUtils.isSameDay(DateTime.now(), DateTime(month.year, month.month, d)) ? Border.all(color: kRed) : null),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Text('$d'), if (has(d)) Container(width: 5, height: 5, decoration: const BoxDecoration(color: Colors.orange, shape: BoxShape.circle))]))),
      ])),
      Expanded(child: dayTasks.isEmpty ? Empty(tr(c, 'noTasks'), icon: Icons.event_available) : ListView(padding: const EdgeInsets.symmetric(horizontal: 12), children: [for (final t in dayTasks) _tile(c, st, t)])),
    ]);
  }
}
