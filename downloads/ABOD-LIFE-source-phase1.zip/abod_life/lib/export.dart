import 'dart:io';
import 'package:excel/excel.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:share_plus/share_plus.dart';
import 'l10n.dart';
import 'state.dart';

class Export {
  static Future<Directory> _dir() async {
    try { final d = await getDownloadsDirectory(); if (d != null) return d; } catch (_) {}
    if (Platform.isAndroid) { try { final d = await getExternalStorageDirectory(); if (d != null) return d; } catch (_) {} }
    return getApplicationDocumentsDirectory();
  }

  static Future<void> _share(String path) async {
    try { await Share.shareXFiles([XFile(path)]); } catch (_) {}
  }

  static Future<String> pdf(AppState st, String lang) async {
    final font = pw.Font.ttf(await rootBundle.load('assets/fonts/Cairo.ttf'));
    final rtl = lang == 'ar'; final td = rtl ? pw.TextDirection.rtl : pw.TextDirection.ltr;
    final df = DateFormat('yyyy-MM-dd');
    String L(String k) => trL(lang, k);
    final doc = pw.Document(theme: pw.ThemeData.withFont(base: font, bold: font));
    final rows = [for (final t in st.txs) [df.format(t.date), L(t.type), t.category, t.amount.toStringAsFixed(2), t.note]];
    doc.addPage(pw.MultiPage(pageFormat: PdfPageFormat.a4, textDirection: td, build: (_) => [
      pw.Text('ABOD LIFE - ${L('finance')}', style: pw.TextStyle(fontSize: 20, font: font)),
      pw.SizedBox(height: 8),
      pw.Text('${L('income')}: ${st.sum('income').toStringAsFixed(2)} ${st.currency}   ${L('expense')}: ${st.sum('expense').toStringAsFixed(2)} ${st.currency}   ${L('balance')}: ${st.balance.toStringAsFixed(2)} ${st.currency}'),
      pw.SizedBox(height: 12),
      pw.TableHelper.fromTextArray(headers: [L('date'), L('income') + '/' + L('expense'), L('category'), L('amount'), L('note')], data: rows, cellAlignment: rtl ? pw.Alignment.centerRight : pw.Alignment.centerLeft,
          headerStyle: pw.TextStyle(font: font, color: PdfColors.white), headerDecoration: const pw.BoxDecoration(color: PdfColors.red800), cellStyle: pw.TextStyle(font: font, fontSize: 10)),
      if (st.debts.isNotEmpty) ...[pw.SizedBox(height: 16), pw.Text(L('debts'), style: pw.TextStyle(fontSize: 16, font: font)), pw.SizedBox(height: 6),
        pw.TableHelper.fromTextArray(headers: [L('person'), L('amount'), '', L('due'), L('paid')],
          data: [for (final d in st.debts) [d.person, d.amount.toStringAsFixed(2), L(d.dir == 'owed_to_me' ? 'owedToMe' : 'iOwe'), d.due == null ? '-' : df.format(d.due!), d.paid ? 'x' : '']],
          cellStyle: pw.TextStyle(font: font, fontSize: 10), headerStyle: pw.TextStyle(font: font))],
    ]));
    final f = File('${(await _dir()).path}/abod_life_finance_${DateFormat('yyyyMMdd_HHmm').format(DateTime.now())}.pdf');
    await f.writeAsBytes(await doc.save());
    await _share(f.path);
    return f.path;
  }

  static Future<String> xlsx(AppState st, String lang) async {
    String L(String k) => trL(lang, k);
    final ex = Excel.createExcel(); final s = ex[L('transactions')]; ex.delete('Sheet1');
    s.appendRow([TextCellValue(L('date')), TextCellValue(L('income') + '/' + L('expense')), TextCellValue(L('category')), TextCellValue(L('amount')), TextCellValue(L('note'))]);
    for (final t in st.txs) {
      s.appendRow([TextCellValue(DateFormat('yyyy-MM-dd').format(t.date)), TextCellValue(L(t.type)), TextCellValue(t.category), DoubleCellValue(t.amount), TextCellValue(t.note)]);
    }
    final d = ex[L('debts')];
    d.appendRow([TextCellValue(L('person')), TextCellValue(L('amount')), TextCellValue('type'), TextCellValue(L('due')), TextCellValue(L('paid'))]);
    for (final x in st.debts) {
      d.appendRow([TextCellValue(x.person), DoubleCellValue(x.amount), TextCellValue(L(x.dir == 'owed_to_me' ? 'owedToMe' : 'iOwe')), TextCellValue(x.due == null ? '' : DateFormat('yyyy-MM-dd').format(x.due!)), TextCellValue(x.paid ? 'yes' : 'no')]);
    }
    final f = File('${(await _dir()).path}/abod_life_finance_${DateFormat('yyyyMMdd_HHmm').format(DateTime.now())}.xlsx');
    await f.writeAsBytes(ex.save()!);
    await _share(f.path);
    return f.path;
  }
}
