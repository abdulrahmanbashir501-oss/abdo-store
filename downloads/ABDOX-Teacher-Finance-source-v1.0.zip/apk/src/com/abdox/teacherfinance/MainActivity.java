package com.abdox.teacherfinance;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.webkit.*;
import java.io.*;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
  WebView wv;
  ValueCallback<Uri[]> chooser;
  static final int REQ = 77;

  @Override protected void onCreate(Bundle b) {
    super.onCreate(b);
    wv = new WebView(this);
    setContentView(wv);
    WebSettings s = wv.getSettings();
    s.setJavaScriptEnabled(true);
    s.setDomStorageEnabled(true);
    s.setAllowFileAccess(false);
    s.setAllowContentAccess(true);
    wv.addJavascriptInterface(new Bridge(), "AndroidBridge");
    wv.setWebViewClient(new WebViewClient() {
      @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) { return true; }
    });
    wv.setWebChromeClient(new WebChromeClient() {
      @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
        if (chooser != null) chooser.onReceiveValue(null);
        chooser = cb;
        Intent i = new Intent(Intent.ACTION_GET_CONTENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        try { startActivityForResult(Intent.createChooser(i, "اختر ملف النسخة الاحتياطية"), REQ); }
        catch (Exception e) { chooser = null; return false; }
        return true;
      }
    });
    wv.loadUrl("file:///android_asset/index.html");
  }

  @Override protected void onActivityResult(int rq, int rs, Intent d) {
    if (rq == REQ && chooser != null) {
      Uri[] r = null;
      if (rs == RESULT_OK && d != null && d.getData() != null) r = new Uri[]{d.getData()};
      chooser.onReceiveValue(r);
      chooser = null;
    }
  }

  @Override public void onBackPressed() {
    wv.evaluateJavascript("window.__back?window.__back():'0'", new ValueCallback<String>() {
      public void onReceiveValue(String v) { if (v == null || v.contains("0")) finish(); }
    });
  }

  @Override protected void onPause() {
    wv.evaluateJavascript("try{AndroidBridge.save(JSON.stringify(D))}catch(e){}", null);
    super.onPause();
  }

  File dataFile() { return new File(getFilesDir(), "data.json"); }

  class Bridge {
    @JavascriptInterface public void save(String json) {
      try {
        if (json == null || json.length() < 10) return;
        File tmp = new File(getFilesDir(), "data.json.tmp");
        try (FileOutputStream o = new FileOutputStream(tmp)) { o.write(json.getBytes(StandardCharsets.UTF_8)); o.getFD().sync(); }
        if (!tmp.renameTo(dataFile())) { dataFile().delete(); tmp.renameTo(dataFile()); }
      } catch (Exception e) { }
    }
    @JavascriptInterface public String load() {
      try {
        File f = dataFile();
        if (!f.exists()) return "";
        byte[] b = new byte[(int) f.length()];
        try (FileInputStream i = new FileInputStream(f)) { int n = 0; while (n < b.length) { int r = i.read(b, n, b.length - n); if (r < 0) break; n += r; } }
        return new String(b, StandardCharsets.UTF_8);
      } catch (Exception e) { return ""; }
    }
    @JavascriptInterface public void share(String text) {
      Intent i = new Intent(Intent.ACTION_SEND);
      i.setType("text/plain");
      i.putExtra(Intent.EXTRA_TEXT, text);
      Intent c = Intent.createChooser(i, "مشاركة");
      c.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
      startActivity(c);
    }
    @JavascriptInterface public String saveFile(String name, String mime, String text) {
      try {
        byte[] data = text.getBytes(StandardCharsets.UTF_8);
        if (Build.VERSION.SDK_INT >= 29) {
          ContentValues cv = new ContentValues();
          cv.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
          cv.put(MediaStore.MediaColumns.MIME_TYPE, mime);
          cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/ABDOX");
          Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
          if (u == null) return "ERR:insert";
          try (OutputStream o = getContentResolver().openOutputStream(u)) { o.write(data); }
          return "Download/ABDOX/" + name;
        } else {
          File dir = new File(getExternalFilesDir(null), "backup");
          dir.mkdirs();
          File f = new File(dir, name);
          try (FileOutputStream o = new FileOutputStream(f)) { o.write(data); }
          return f.getAbsolutePath();
        }
      } catch (Exception e) { return "ERR:" + e; }
    }
  }
}
