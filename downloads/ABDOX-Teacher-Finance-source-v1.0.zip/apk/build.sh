set -e
export JAVA_HOME=$HOME/w/jdk17 PATH=$HOME/w/jdk17/bin:$PATH
SDK=$HOME/w/sdk; BT=$SDK/build-tools/34.0.0; AJ=$SDK/platforms/android-34/android.jar
cd $HOME/w/apk; rm -rf out; mkdir -p out/cls out/res
cp ../app/index.html assets/index.html
$BT/aapt2 compile --dir res -o out/res.zip
$BT/aapt2 link -o out/base.apk -I $AJ --manifest AndroidManifest.xml -A assets out/res.zip --min-sdk-version 24 --target-sdk-version 34
javac -encoding UTF-8 -source 8 -target 8 -bootclasspath $AJ -d out/cls src/com/abdox/teacherfinance/*.java 2>&1
$BT/d8 --release --min-api 24 --lib $AJ --output out out/cls/com/abdox/teacherfinance/*.class
cd out && cp base.apk un.apk && zip -q -j un.apk classes.dex && cd ..
$BT/zipalign -f 4 out/un.apk out/al.apk
[ -f ~/w/abdox.jks ] || keytool -genkeypair -keystore ~/w/abdox.jks -storepass abdox-teacher-2026 -keypass abdox-teacher-2026 -alias abdox -keyalg RSA -keysize 2048 -validity 10000 -dname "CN=ABDO X, O=ABDO X, C=EG"
$BT/apksigner sign --ks ~/w/abdox.jks --ks-pass pass:abdox-teacher-2026 --key-pass pass:abdox-teacher-2026 --out out/ABDOX-Teacher-Finance-v1.0.apk out/al.apk
$BT/apksigner verify --verbose out/ABDOX-Teacher-Finance-v1.0.apk | head -5
$BT/aapt2 dump badging out/ABDOX-Teacher-Finance-v1.0.apk | head -8
ls -la out/*.apk
