ABDO X Games - شطرنج / دومينو / إكس أو (اشتغال بدون إنترنت)
Windows: افتح play-windows.bat  (او افتح menu.html في اي متصفح)
Android/Mac/Linux: افتح menu.html في المتصفح.
