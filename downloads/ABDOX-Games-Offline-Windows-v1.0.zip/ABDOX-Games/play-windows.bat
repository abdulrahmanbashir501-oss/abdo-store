@echo off
rem ABDO X Games - opens the game menu offline in Edge app window (falls back to default browser)
set "P=%~dp0menu.html"
start "" msedge --app="file:///%P:\=/%" 2>nul || start "" "%P%"
