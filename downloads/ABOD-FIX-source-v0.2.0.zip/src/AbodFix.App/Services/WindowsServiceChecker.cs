using System.Runtime.Versioning;
using System.ServiceProcess;
using AbodFix.Core.Contracts;
using AbodFix.Core.Models;
using AbodFix.Core.Safety;

namespace AbodFix.App.Services;

/// <summary>Checks important Windows services against their expected state.</summary>
[SupportedOSPlatform("windows")]
public sealed class WindowsServiceChecker : IServiceProvider2
{
    /// <summary>Important services and whether Automatic services among them should normally be running.</summary>
    private static readonly string[] Important =
    [
        "wuauserv", "WinDefend", "EventLog", "Winmgmt", "Schedule", "Dhcp", "Dnscache",
        "MpsSvc", "W32Time", "Themes", "AudioSrv", "Spooler", "BITS", "LanmanWorkstation"
    ];

    public Task<IReadOnlyList<WindowsServiceInfo>> ListImportantAsync(CancellationToken ct = default)
        => Task.Run<IReadOnlyList<WindowsServiceInfo>>(List, ct);

    private static List<WindowsServiceInfo> List()
    {
        var list = new List<WindowsServiceInfo>();
        foreach (var name in Important)
        {
            try
            {
                using var sc = new ServiceController(name);
                var startMode = sc.StartType.ToString();
                var running = sc.Status == ServiceControllerStatus.Running;
                var shouldRun = sc.StartType is ServiceStartMode.Automatic;
                list.Add(new WindowsServiceInfo
                {
                    Name = sc.ServiceName,
                    DisplayName = sc.DisplayName,
                    Status = sc.Status.ToString(),
                    StartMode = startMode,
                    IsCritical = SafetyPolicy.IsCriticalService(name),
                    LooksWrong = shouldRun && !running
                });
            }
            catch { /* service not present on this Windows edition */ }
        }
        return list;
    }

    /// <summary>Starts a service after user confirmation. Critical services are refused.</summary>
    public static string StartService(string name)
    {
        if (SafetyPolicy.IsCriticalService(name))
            return $"'{name}' is a security-critical service; ABOD FIX will not change it.";
        try
        {
            using var sc = new ServiceController(name);
            if (sc.Status == ServiceControllerStatus.Running) return $"'{name}' is already running.";
            sc.Start();
            sc.WaitForStatus(ServiceControllerStatus.Running, TimeSpan.FromSeconds(15));
            return $"Service '{name}' started.";
        }
        catch (Exception ex)
        {
            return $"Could not start '{name}': {ex.Message}";
        }
    }
}
