using AbodFix.Core.History;

namespace AbodFix.App.Services;

/// <summary>User confirmation + message dialogs (implemented with MessageBox in the shell).</summary>
public interface IConfirmService
{
    bool Confirm(string title, string message);
    void Info(string title, string message);
}

/// <summary>Save-file dialog abstraction.</summary>
public interface IFileDialogService
{
    string? AskSavePath(string defaultFileName, string extension, string filter);
}

/// <summary>Shared app-level services.</summary>
public sealed class ShellContext
{
    public required HistoryStore History { get; init; }
    public required IConfirmService Confirm { get; init; }
    public required IFileDialogService FileDialog { get; init; }
    public string AppVersion { get; init; } = "0.1.0";
}
