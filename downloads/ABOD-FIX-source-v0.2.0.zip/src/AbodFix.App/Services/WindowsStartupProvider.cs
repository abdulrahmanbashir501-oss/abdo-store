using System.IO;
using System.Runtime.Versioning;
using AbodFix.Core.Contracts;
using AbodFix.Core.Models;
using Microsoft.Win32;

namespace AbodFix.App.Services;

/// <summary>
/// Startup items from the real registry Run keys (HKCU + HKLM, including the
/// Windows-approved/disabled mirrors in StartupApproved) and the Startup folder.
/// Disable = move the value into a backup subkey we own (never delete).
/// Enable = move it back. Every change is recorded to history by the caller.
/// </summary>
[SupportedOSPlatform("windows")]
public sealed class WindowsStartupProvider : IStartupProvider
{
    private const string BackupSubKey = @"SOFTWARE\AbodFix\DisabledStartup";

    public Task<IReadOnlyList<StartupItem>> ListAsync(CancellationToken ct = default)
        => Task.Run<IReadOnlyList<StartupItem>>(List, ct);

    private static List<StartupItem> List()
    {
        var items = new List<StartupItem>();
        ReadRunKey(Registry.CurrentUser, @"SOFTWARE\Microsoft\Windows\CurrentVersion\Run", "HKCU", items);
        ReadRunKey(Registry.LocalMachine, @"SOFTWARE\Microsoft\Windows\CurrentVersion\Run", "HKLM", items);
        ReadDisabledBackup(items);
        ReadStartupFolder(items);
        return items
            .Select(i => i with { LooksImportant = NameLooksImportant(i.Name, i.Company) })
            .OrderBy(i => i.Name, StringComparer.OrdinalIgnoreCase)
            .ToList();
    }

    private static void ReadRunKey(RegistryKey root, string sub, string hive, List<StartupItem> items)
    {
        try
        {
            using var key = root.OpenSubKey(sub, writable: false);
            if (key is null) return;
            foreach (var name in key.GetValueNames())
            {
                var cmd = key.GetValue(name)?.ToString();
                items.Add(new StartupItem
                {
                    Name = name,
                    Command = cmd,
                    Path = ExtractPath(cmd),
                    Location = StartupLocation.RegistryRun,
                    SourceKey = $"{hive}\\{sub}\\{name}",
                    Enabled = true,
                    Company = TryCompany(ExtractPath(cmd))
                });
            }
        }
        catch { /* access denied to HKLM on some systems */ }
    }

    private static void ReadDisabledBackup(List<StartupItem> items)
    {
        try
        {
            using var key = Registry.CurrentUser.OpenSubKey(BackupSubKey, writable: false);
            if (key is null) return;
            foreach (var name in key.GetValueNames())
            {
                var payload = key.GetValue(name)?.ToString() ?? "";
                var parts = payload.Split('\u001f'); // original hive-subkey + command
                items.Add(new StartupItem
                {
                    Name = name,
                    Command = parts.Length > 1 ? parts[1] : payload,
                    Path = ExtractPath(parts.Length > 1 ? parts[1] : payload),
                    Location = StartupLocation.RegistryRun,
                    SourceKey = $"BACKUP\\{name}",
                    Enabled = false,
                    Company = TryCompany(ExtractPath(parts.Length > 1 ? parts[1] : payload))
                });
            }
        }
        catch { }
    }

    private static void ReadStartupFolder(List<StartupItem> items)
    {
        try
        {
            var dir = Environment.GetFolderPath(Environment.SpecialFolder.Startup);
            foreach (var f in Directory.EnumerateFiles(dir))
            {
                items.Add(new StartupItem
                {
                    Name = Path.GetFileNameWithoutExtension(f),
                    Command = f,
                    Path = f,
                    Location = StartupLocation.StartupFolder,
                    SourceKey = f,
                    Enabled = true,
                    Company = TryCompany(f)
                });
            }
        }
        catch { }
    }

    internal static string? ExtractPath(string? command)
    {
        if (string.IsNullOrWhiteSpace(command)) return null;
        var c = command.Trim();
        if (c.StartsWith('"'))
        {
            var end = c.IndexOf('"', 1);
            return end > 1 ? c[1..end] : null;
        }
        var space = c.IndexOf(' ');
        return space > 0 ? c[..space] : c;
    }

    internal static string? TryCompany(string? path)
    {
        if (string.IsNullOrWhiteSpace(path)) return null;
        try
        {
            return File.Exists(path) ? System.Diagnostics.FileVersionInfo.GetVersionInfo(path).CompanyName : null;
        }
        catch { return null; }
    }

    internal static bool NameLooksImportant(string name, string? company)
    {
        string[] hints = ["security", "antivirus", "defender", "onedrive", "sync", "backup", "audio", "realtek", "intel", "nvidia", "amd"];
        return hints.Any(h => name.Contains(h, StringComparison.OrdinalIgnoreCase)
            || (company?.Contains(h, StringComparison.OrdinalIgnoreCase) ?? false));
    }

    public Task<StartupChangeResult> SetEnabledAsync(StartupItem item, bool enabled, CancellationToken ct = default)
        => Task.Run(() => enabled ? Enable(item) : Disable(item), ct);

    private static StartupChangeResult Disable(StartupItem item)
    {
        try
        {
            if (item.Location == StartupLocation.StartupFolder)
            {
                var target = item.SourceKey + ".disabled-by-abodfix";
                File.Move(item.SourceKey, target, overwrite: false);
                return new StartupChangeResult(true, $"Moved to {target}. Rename it back to re-enable.");
            }

            // registry: HKCU\...\Run or HKLM\...\Run
            var isHkcu = item.SourceKey.StartsWith("HKCU\\", StringComparison.OrdinalIgnoreCase);
            var sub = @"SOFTWARE\Microsoft\Windows\CurrentVersion\Run";
            using var root = isHkcu ? Registry.CurrentUser : Registry.LocalMachine;
            using var run = root.OpenSubKey(sub, writable: true);
            var value = run?.GetValue(item.Name)?.ToString();
            if (run is null || value is null)
                return new StartupChangeResult(false, "Startup entry not found (it may have been removed).");

            using var backup = Registry.CurrentUser.CreateSubKey(BackupSubKey, writable: true);
            backup.SetValue(item.Name, $"{(isHkcu ? "HKCU" : "HKLM")}\u001f{value}");
            run.DeleteValue(item.Name, throwOnMissingValue: false);
            return new StartupChangeResult(true, $"'{item.Name}' disabled. Its entry is backed up inside ABOD FIX and can be re-enabled anytime.");
        }
        catch (UnauthorizedAccessException)
        {
            return new StartupChangeResult(false, "Windows refused the change (needs Administrator for machine-wide entries).");
        }
        catch (Exception ex)
        {
            return new StartupChangeResult(false, $"Failed: {ex.Message}");
        }
    }

    private static StartupChangeResult Enable(StartupItem item)
    {
        try
        {
            if (item.SourceKey.EndsWith(".disabled-by-abodfix", StringComparison.OrdinalIgnoreCase))
            {
                var original = item.SourceKey[..^".disabled-by-abodfix".Length];
                File.Move(item.SourceKey, original, overwrite: false);
                return new StartupChangeResult(true, "Re-enabled in the Startup folder.");
            }

            using var backup = Registry.CurrentUser.OpenSubKey(BackupSubKey, writable: true);
            var payload = backup?.GetValue(item.Name)?.ToString();
            if (payload is null)
                return new StartupChangeResult(false, "No ABOD FIX backup found for this entry.");
            var parts = payload.Split('\u001f');
            var hive = parts[0];
            var value = parts.Length > 1 ? parts[1] : "";

            using var root = hive == "HKCU" ? Registry.CurrentUser : Registry.LocalMachine;
            using var run = root.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Run", writable: true);
            if (run is null) return new StartupChangeResult(false, "Run key not writable (needs Administrator).");
            run.SetValue(item.Name, value);
            backup!.DeleteValue(item.Name, throwOnMissingValue: false);
            return new StartupChangeResult(true, $"'{item.Name}' re-enabled.");
        }
        catch (UnauthorizedAccessException)
        {
            return new StartupChangeResult(false, "Windows refused the change (needs Administrator for machine-wide entries).");
        }
        catch (Exception ex)
        {
            return new StartupChangeResult(false, $"Failed: {ex.Message}");
        }
    }
}
