using System.Diagnostics;
using System.IO;
using System.Net.NetworkInformation;
using System.Runtime.Versioning;
using AbodFix.Core.Contracts;
using AbodFix.Core.Models;

namespace AbodFix.App.Services;

/// <summary>
/// Live metrics from Windows Performance Counters, DriveInfo and NetworkInterface.
/// Temperature and GPU counters are reported only when the machine really exposes them.
/// </summary>
[SupportedOSPlatform("windows")]
public sealed class WindowsMetricsSampler : IMetricsSampler, IDisposable
{
    private PerformanceCounter? _cpu;
    private PerformanceCounter? _ramAvailable;
    private List<PerformanceCounter>? _gpuCounters;
    private bool _gpuCountersProbed;
    private long? _cachedTotalRam;

    public Task<SystemSnapshot> SampleAsync(CancellationToken ct = default)
        => Task.Run(Sample, ct);

    private SystemSnapshot Sample()
    {
        return new SystemSnapshot
        {
            Timestamp = DateTimeOffset.Now,
            CpuUsagePercent = ReadCpu(),
            RamTotalBytes = TotalRam(),
            RamAvailableBytes = ReadRamAvailable(),
            Disks = ReadDisks(),
            Network = NetworkInterface.GetIsNetworkAvailable() ? NetworkStatus.Connected : NetworkStatus.Disconnected,
            Uptime = TimeSpan.FromMilliseconds(Environment.TickCount64),
            CpuTemperatureCelsius = ReadCpuTemperature(),
            GpuUsagePercent = ReadGpuUsage(),
            GpuTemperatureCelsius = null // no generic Windows API; vendor SDKs are a later phase. Never fabricated.
        };
    }

    private double? ReadCpu()
    {
        try
        {
            _cpu ??= new PerformanceCounter("Processor", "% Processor Time", "_Total", readOnly: true);
            var v = _cpu.NextValue(); // first sample after creation is 0 by counter design
            return Math.Round(Math.Clamp(v, 0, 100), 1);
        }
        catch { return null; }
    }

    private long? TotalRam()
    {
        if (_cachedTotalRam is not null) return _cachedTotalRam;
        try
        {
            foreach (var mo in WmiSystemInfoProvider.Query("SELECT TotalPhysicalMemory FROM Win32_ComputerSystem"))
            {
                _cachedTotalRam = WmiSystemInfoProvider.Long(mo, "TotalPhysicalMemory");
                break;
            }
        }
        catch { }
        return _cachedTotalRam;
    }

    private long? ReadRamAvailable()
    {
        try
        {
            _ramAvailable ??= new PerformanceCounter("Memory", "Available MBytes", readOnly: true);
            return (long)(_ramAvailable.NextValue() * 1024 * 1024);
        }
        catch { return null; }
    }

    private static IReadOnlyList<DiskSample> ReadDisks()
    {
        var list = new List<DiskSample>();
        try
        {
            foreach (var d in DriveInfo.GetDrives())
            {
                if (d.DriveType != DriveType.Fixed) continue;
                try
                {
                    if (!d.IsReady) continue;
                    list.Add(new DiskSample
                    {
                        Name = d.Name,
                        VolumeLabel = d.VolumeLabel,
                        FileSystem = d.DriveFormat,
                        TotalBytes = d.TotalSize,
                        FreeBytes = d.AvailableFreeSpace
                    });
                }
                catch { /* drive not ready */ }
            }
        }
        catch { }
        return list;
    }

    /// <summary>WMI thermal zone. Most consumer PCs do not support it; then we return null and say so.</summary>
    private static double? ReadCpuTemperature()
    {
        try
        {
            foreach (var mo in WmiSystemInfoProvider.Query(
                "SELECT CurrentTemperature FROM MSAcpi_ThermalZoneTemperature", @"\\.\root\wmi"))
            {
                if (mo["CurrentTemperature"] is null) continue;
                var celsius = Convert.ToDouble(mo["CurrentTemperature"]) / 10.0 - 273.15;
                if (celsius is > 0 and < 150) return Math.Round(celsius, 1);
            }
        }
        catch { /* unsupported on this machine */ }
        return null;
    }

    private double? ReadGpuUsage()
    {
        try
        {
            if (!_gpuCountersProbed)
            {
                _gpuCountersProbed = true;
                var cat = new PerformanceCounterCategory("GPU Engine");
                _gpuCounters = cat.GetInstanceNames()
                    .Where(n => n.Contains("engtype_3D", StringComparison.OrdinalIgnoreCase))
                    .Select(n => new PerformanceCounter("GPU Engine", "Utilization Percentage", n, readOnly: true))
                    .ToList();
            }
            if (_gpuCounters is null || _gpuCounters.Count == 0) return null;
            double sum = 0;
            foreach (var c in _gpuCounters)
            {
                try { sum += c.NextValue(); } catch { }
            }
            return Math.Round(Math.Clamp(sum, 0, 100), 1);
        }
        catch { return null; }
    }

    public void Dispose()
    {
        _cpu?.Dispose();
        _ramAvailable?.Dispose();
        if (_gpuCounters is not null) foreach (var c in _gpuCounters) c.Dispose();
    }
}
