using System.Management;
using System.Runtime.Versioning;
using AbodFix.Core.Contracts;
using AbodFix.Core.Models;

namespace AbodFix.App.Services;

/// <summary>Reads the hardware/OS profile from WMI. Runs on Windows only.</summary>
[SupportedOSPlatform("windows")]
public sealed class WmiSystemInfoProvider : ISystemInfoProvider
{
    private HardwareProfile? _cache;

    public Task<HardwareProfile> GetHardwareProfileAsync(CancellationToken ct = default)
        => Task.Run(() => _cache ??= Query(), ct);

    private static HardwareProfile Query()
    {
        CpuInfo cpu = new() { Name = "Unknown CPU", PhysicalCores = 0, LogicalProcessors = Environment.ProcessorCount };
        OsInfo os = new() { Caption = "Windows", Version = Environment.OSVersion.Version.ToString(), BuildNumber = Environment.OSVersion.Version.Build.ToString() };
        long totalRam = 0;
        var gpus = new List<GpuInfo>();
        string? motherboard = null, bios = null;

        try
        {
            foreach (var mo in Query("SELECT Name, NumberOfCores, NumberOfLogicalProcessors, MaxClockSpeed, Manufacturer FROM Win32_Processor"))
            {
                cpu = new CpuInfo
                {
                    Name = Str(mo, "Name") ?? cpu.Name,
                    PhysicalCores = (int)(UInt(mo, "NumberOfCores") ?? 0u),
                    LogicalProcessors = (int)(UInt(mo, "NumberOfLogicalProcessors") ?? (uint)Environment.ProcessorCount),
                    MaxClockMHz = UInt(mo, "MaxClockSpeed"),
                    Manufacturer = Str(mo, "Manufacturer")
                };
                break; // first CPU; multi-socket is rare on consumer PCs
            }
        }
        catch { /* keep defaults; UI marks unknown values */ }

        try
        {
            foreach (var mo in Query("SELECT Caption, Version, BuildNumber, OSArchitecture, InstallDate, LastBootUpTime FROM Win32_OperatingSystem"))
            {
                os = new OsInfo
                {
                    Caption = Str(mo, "Caption") ?? os.Caption,
                    Version = Str(mo, "Version") ?? os.Version,
                    BuildNumber = Str(mo, "BuildNumber") ?? os.BuildNumber,
                    Architecture = Str(mo, "OSArchitecture"),
                    InstallDate = WmiDate(mo, "InstallDate"),
                    LastBootTime = WmiDate(mo, "LastBootUpTime")
                };
                break;
            }
        }
        catch { }

        try
        {
            foreach (var mo in Query("SELECT TotalPhysicalMemory FROM Win32_ComputerSystem"))
            {
                totalRam = Long(mo, "TotalPhysicalMemory") ?? 0;
                break;
            }
        }
        catch { }

        try
        {
            foreach (var mo in Query("SELECT Name, AdapterCompatibility, AdapterRAM, DriverVersion, DriverDate, VideoModeDescription FROM Win32_VideoController"))
            {
                gpus.Add(new GpuInfo
                {
                    Name = Str(mo, "Name") ?? "Unknown GPU",
                    Vendor = Str(mo, "AdapterCompatibility"),
                    AdapterRamBytes = Long(mo, "AdapterRAM"),
                    DriverVersion = Str(mo, "DriverVersion"),
                    DriverDate = Str(mo, "DriverDate"),
                    VideoModeDescription = Str(mo, "VideoModeDescription")
                });
            }
        }
        catch { }

        try
        {
            foreach (var mo in Query("SELECT Manufacturer, Product FROM Win32_BaseBoard"))
            {
                motherboard = $"{Str(mo, "Manufacturer")} {Str(mo, "Product")}".Trim();
                break;
            }
        }
        catch { }

        try
        {
            foreach (var mo in Query("SELECT SMBIOSBIOSVersion FROM Win32_BIOS"))
            {
                bios = Str(mo, "SMBIOSBIOSVersion");
                break;
            }
        }
        catch { }

        return new HardwareProfile
        {
            Cpu = cpu,
            Os = os,
            TotalRamBytes = totalRam,
            Gpus = gpus,
            Motherboard = motherboard,
            BiosVersion = bios,
            MachineName = Environment.MachineName,
            CollectedAt = DateTimeOffset.Now
        };
    }

    internal static List<ManagementObject> Query(string wql, string scope = @"\\.\root\cimv2")
    {
        using var searcher = new ManagementObjectSearcher(new ManagementScope(scope), new ObjectQuery(wql));
        return searcher.Get().Cast<ManagementObject>().ToList();
    }

    internal static string? Str(ManagementBaseObject mo, string name)
        => mo[name]?.ToString()?.Trim() is { Length: > 0 } s ? s : null;

    internal static uint? UInt(ManagementBaseObject mo, string name)
        => mo[name] is uint u ? u : mo[name] is null ? null : Convert.ToUInt32(mo[name]);

    internal static long? Long(ManagementBaseObject mo, string name)
        => mo[name] is null ? null : Convert.ToInt64(mo[name]);

    internal static DateTimeOffset? WmiDate(ManagementBaseObject mo, string name)
    {
        var raw = Str(mo, name);
        if (raw is null) return null;
        try { return ManagementDateTimeConverter.ToDateTime(raw); } catch { return null; }
    }
}
