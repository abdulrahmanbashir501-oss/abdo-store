using System.Runtime.Versioning;
using AbodFix.Core.Contracts;
using AbodFix.Core.Models;

namespace AbodFix.App.Services;

/// <summary>
/// Physical disk inventory + SMART failure prediction.
/// If the device/driver does not expose SMART, status is reported as Unknown with an
/// explanation - we never declare a disk healthy from a single missing indicator.
/// </summary>
[SupportedOSPlatform("windows")]
public sealed class WmiDiskHealthProvider : IDiskHealthProvider
{
    public Task<IReadOnlyList<DiskHealthInfo>> GetDisksAsync(CancellationToken ct = default)
        => Task.Run<IReadOnlyList<DiskHealthInfo>>(Query, ct);

    private static List<DiskHealthInfo> Query()
    {
        var smartByPnp = QuerySmart();
        var list = new List<DiskHealthInfo>();

        try
        {
            foreach (var mo in WmiSystemInfoProvider.Query(
                "SELECT Model, SerialNumber, InterfaceType, MediaType, Size, DeviceID, PNPDeviceID FROM Win32_DiskDrive"))
            {
                var pnp = WmiSystemInfoProvider.Str(mo, "PNPDeviceID");
                // SMART InstanceName embeds the PNP id in normalized form; match loosely.
                var norm = (pnp ?? "").Replace("\\", "").ToUpperInvariant();
                var match = smartByPnp.FirstOrDefault(kv =>
                    norm.Length > 0 && kv.Key.Replace("\\", "").ToUpperInvariant().Contains(norm));
                var (status, details) = match.Key is not null ? match.Value : (SmartStatus.Unknown, (string?)null);

                list.Add(new DiskHealthInfo
                {
                    Model = WmiSystemInfoProvider.Str(mo, "Model") ?? "Unknown disk",
                    SerialNumber = WmiSystemInfoProvider.Str(mo, "SerialNumber"),
                    InterfaceType = WmiSystemInfoProvider.Str(mo, "InterfaceType"),
                    MediaType = WmiSystemInfoProvider.Str(mo, "MediaType"),
                    DeviceId = WmiSystemInfoProvider.Str(mo, "DeviceID"),
                    SizeBytes = WmiSystemInfoProvider.Long(mo, "Size"),
                    Smart = status,
                    SmartDetails = details ?? "This drive (or its driver) did not report SMART failure prediction."
                });
            }
        }
        catch (Exception ex)
        {
            list.Add(new DiskHealthInfo
            {
                Model = "Disk query failed",
                Smart = SmartStatus.Unknown,
                SmartDetails = $"WMI disk query failed: {ex.Message}"
            });
        }
        return list;
    }

    private static Dictionary<string, (SmartStatus, string?)> QuerySmart()
    {
        var map = new Dictionary<string, (SmartStatus, string?)>(StringComparer.OrdinalIgnoreCase);
        try
        {
            foreach (var mo in WmiSystemInfoProvider.Query(
                "SELECT InstanceName, PredictFailure, Reason FROM MSStorageDriver_FailurePredictStatus", @"\\.\root\wmi"))
            {
                var instance = WmiSystemInfoProvider.Str(mo, "InstanceName") ?? "";
                // InstanceName embeds the PNP device id of the drive it belongs to.
                var predicted = mo["PredictFailure"] is bool b && b;
                var reason = WmiSystemInfoProvider.Str(mo, "Reason");
                var status = predicted ? SmartStatus.FailurePredicted : SmartStatus.NoFailurePredicted;
                var detail = predicted
                    ? $"SMART predicts a possible failure (reason code {reason ?? "n/a"}). Back up your data and replace the drive."
                    : "SMART failure prediction: no failure predicted. Note: this is one indicator only.";
                // store under every key fragment we can derive; matched loosely below
                map[instance] = (status, detail);
            }
        }
        catch { /* root\wmi storage provider missing or denied -> all Unknown */ }
        return map;
    }
}
