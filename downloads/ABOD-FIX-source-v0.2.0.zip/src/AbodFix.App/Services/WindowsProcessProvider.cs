using System.Collections.Concurrent;
using System.Diagnostics;
using System.Runtime.Versioning;
using AbodFix.Core.Contracts;
using AbodFix.Core.Models;
using AbodFix.Core.Safety;

namespace AbodFix.App.Services;

/// <summary>
/// Process list with real memory usage and delta-based per-process CPU percent.
/// Company/path are read when the OS allows it (protected processes refuse, and that is shown as empty).
/// </summary>
[SupportedOSPlatform("windows")]
public sealed class WindowsProcessProvider : IProcessProvider
{
    private readonly ConcurrentDictionary<int, (TimeSpan Cpu, DateTime When)> _last = new();

    public Task<IReadOnlyList<ProcessInfo>> ListProcessesAsync(CancellationToken ct = default)
        => Task.Run<IReadOnlyList<ProcessInfo>>(List, ct);

    private List<ProcessInfo> List()
    {
        var now = DateTime.UtcNow;
        var cores = Math.Max(1, Environment.ProcessorCount);
        var result = new List<ProcessInfo>();
        var seen = new HashSet<int>();

        foreach (var p in Process.GetProcesses())
        {
            using (p)
            {
                try
                {
                    seen.Add(p.Id);
                    long? mem = null;
                    try { mem = p.WorkingSet64; } catch { }

                    double? cpuPct = null;
                    try
                    {
                        var total = p.TotalProcessorTime;
                        if (_last.TryGetValue(p.Id, out var prev))
                        {
                            var elapsed = (now - prev.When).TotalMilliseconds;
                            if (elapsed > 50)
                                cpuPct = Math.Round(Math.Clamp(
                                    (total - prev.Cpu).TotalMilliseconds / (elapsed * cores) * 100.0, 0, 100), 1);
                        }
                        _last[p.Id] = (total, now);
                    }
                    catch { }

                    string? path = null, company = null;
                    try
                    {
                        path = p.MainModule?.FileName;
                        company = p.MainModule?.FileVersionInfo.CompanyName;
                    }
                    catch { /* access denied for protected/other-session processes */ }

                    result.Add(new ProcessInfo
                    {
                        Pid = p.Id,
                        Name = p.ProcessName,
                        CpuPercent = cpuPct,
                        MemoryBytes = mem,
                        Company = company,
                        Path = path,
                        IsCriticalSystemProcess = SafetyPolicy.IsCriticalProcess(p.ProcessName)
                    });
                }
                catch { /* process exited mid-enumeration */ }
            }
        }

        foreach (var dead in _last.Keys.Where(id => !seen.Contains(id)).ToList())
            _last.TryRemove(dead, out _);

        return result;
    }

    /// <summary>
    /// Terminates a process. Phase 1 supports only user confirmation + critical-process protection;
    /// every attempt is recorded to history by the caller. Never kills protected system processes.
    /// </summary>
    public static KillResult Kill(int pid, string name)
    {
        if (SafetyPolicy.IsCriticalProcess(name))
            return new KillResult(false, $"'{name}' is a protected Windows process and cannot be terminated from ABOD FIX.");
        try
        {
            using var p = Process.GetProcessById(pid);
            p.Kill(entireProcessTree: false);
            return new KillResult(true, $"Process '{name}' (PID {pid}) was terminated.");
        }
        catch (Exception ex)
        {
            return new KillResult(false, $"Could not terminate '{name}': {ex.Message}");
        }
    }

    public sealed record KillResult(bool Success, string Message);
}
