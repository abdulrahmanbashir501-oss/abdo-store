using System.Diagnostics.Eventing.Reader;
using System.Runtime.Versioning;
using AbodFix.Core.Contracts;
using AbodFix.Core.Models;

namespace AbodFix.App.Services;

/// <summary>Reads recent Error/Warning events from the real Windows Event Log and groups them by source.</summary>
[SupportedOSPlatform("windows")]
public sealed class WindowsEventLogScanner : IEventLogScanner
{
    private static readonly string[] Logs = ["Application", "System"];

    public Task<IReadOnlyList<EventLogIssue>> GetRecentIssuesAsync(int perLogLimit = 200, CancellationToken ct = default)
        => Task.Run<IReadOnlyList<EventLogIssue>>(() => Scan(perLogLimit), ct);

    private static List<EventLogIssue> Scan(int perLogLimit)
    {
        var grouped = new Dictionary<(string log, string source, int? id, string level), EventLogIssue>();

        foreach (var log in Logs)
        {
            EventRecord? record = null;
            try
            {
                var query = new EventLogQuery(log, PathType.LogName, "*[System[(Level=1 or Level=2 or Level=3)]]")
                { ReverseDirection = true };
                using var reader = new EventLogReader(query);
                var seen = 0;
                while (seen < perLogLimit && (record = reader.ReadEvent()) is not null)
                {
                    using (record)
                    {
                        seen++;
                        var levelName = record.Level switch { 1 => "Critical", 2 => "Error", 3 => "Warning", _ => "Other" };
                        if (levelName == "Other") continue;
                        var source = record.ProviderName ?? "Unknown";
                        var key = (log, source, record.Id, levelName);
                        string? msg = null;
                        try { msg = record.FormatDescription(); } catch { }
                        if (msg is { Length: > 300 }) msg = msg[..300];

                        if (grouped.TryGetValue(key, out var existing))
                        {
                            grouped[key] = existing with
                            {
                                Count = existing.Count + 1,
                                LastSeen = record.TimeCreated ?? existing.LastSeen,
                                SampleMessage = existing.SampleMessage ?? msg
                            };
                        }
                        else
                        {
                            grouped[key] = new EventLogIssue
                            {
                                LogName = log,
                                Source = source,
                                Level = levelName,
                                EventId = record.Id,
                                Count = 1,
                                LastSeen = record.TimeCreated,
                                SampleMessage = msg
                            };
                        }
                    }
                }
            }
            catch (EventLogException) { /* log unavailable */ }
            catch (UnauthorizedAccessException) { /* needs elevation; note as empty */ }
        }

        return grouped.Values
            .OrderByDescending(i => i.Level == "Critical" ? 3 : i.Level == "Error" ? 2 : 1)
            .ThenByDescending(i => i.Count)
            .ToList();
    }
}
