using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Runtime.Versioning;
using AbodFix.Core.Contracts;
using AbodFix.Core.Models;

namespace AbodFix.App.Services;

/// <summary>Real network checks: adapters, gateway ping, internet ping, DNS resolution.</summary>
[SupportedOSPlatform("windows")]
public sealed class WindowsNetworkDiagnostics : INetworkDiagnostics
{
    public async Task<NetworkDiagnosticsResult> RunAsync(CancellationToken ct = default)
    {
        var checks = new List<NetworkCheckResult>();
        var findings = new List<string>();
        var adapters = ReadAdapters();

        var up = adapters.Where(a => a.Status == "Up").ToList();
        checks.Add(new NetworkCheckResult
        {
            Name = "Active network adapter",
            Passed = up.Count > 0,
            Detail = up.Count > 0 ? string.Join(", ", up.Select(a => a.Name)) : "No adapter is up"
        });
        if (up.Count == 0) findings.Add("No active network adapter found; check Wi-Fi/Ethernet is enabled.");

        var gateway = up.Select(a => a.Gateway).FirstOrDefault(g => !string.IsNullOrEmpty(g));
        if (gateway is not null)
            checks.Add(await Ping("Gateway ping", gateway));
        else
            checks.Add(new NetworkCheckResult { Name = "Gateway ping", Passed = false, Detail = "No default gateway" });

        var netPing = await Ping("Internet ping (8.8.8.8)", "8.8.8.8");
        checks.Add(netPing);

        var dns = await Resolve("DNS resolution (microsoft.com)", "microsoft.com");
        checks.Add(dns);

        var anyConnectivity = netPing.Passed || dns.Passed;
        if (!anyConnectivity && up.Count > 0)
            findings.Add("Adapters are up but internet checks failed; router or ISP path may be down. Try 'Renew IP address' in the Repair Center.");
        if (!dns.Passed && netPing.Passed)
            findings.Add("Internet reachable by address but DNS failed; try 'Flush DNS cache' or change DNS servers.");
        if (up.Any(a => a.DnsServers.Count == 0))
            findings.Add("An active adapter has no DNS servers configured.");

        return new NetworkDiagnosticsResult
        {
            AnyConnectivity = anyConnectivity,
            Checks = checks,
            Adapters = adapters,
            Findings = findings
        };
    }

    private static async Task<NetworkCheckResult> Ping(string name, string host)
    {
        try
        {
            using var p = new Ping();
            var reply = await p.SendPingAsync(host, 3000);
            return new NetworkCheckResult
            {
                Name = name,
                Passed = reply.Status == IPStatus.Success,
                Detail = reply.Status.ToString(),
                LatencyMs = reply.Status == IPStatus.Success ? reply.RoundtripTime : null
            };
        }
        catch (Exception ex)
        {
            return new NetworkCheckResult { Name = name, Passed = false, Detail = ex.Message };
        }
    }

    private static async Task<NetworkCheckResult> Resolve(string name, string host)
    {
        try
        {
            var sw = System.Diagnostics.Stopwatch.StartNew();
            var addrs = await Dns.GetHostAddressesAsync(host, AddressFamily.InterNetwork);
            sw.Stop();
            return new NetworkCheckResult
            {
                Name = name,
                Passed = addrs.Length > 0,
                Detail = addrs.Length > 0 ? addrs[0].ToString() : "no address",
                LatencyMs = sw.ElapsedMilliseconds
            };
        }
        catch (Exception ex)
        {
            return new NetworkCheckResult { Name = name, Passed = false, Detail = ex.Message };
        }
    }

    private static List<NetworkAdapterInfo> ReadAdapters()
    {
        var list = new List<NetworkAdapterInfo>();
        try
        {
            foreach (var n in NetworkInterface.GetAllNetworkInterfaces())
            {
                if (n.NetworkInterfaceType is NetworkInterfaceType.Loopback) continue;
                var props = n.GetIPProperties();
                list.Add(new NetworkAdapterInfo
                {
                    Name = n.Name,
                    Description = n.Description,
                    Type = n.NetworkInterfaceType.ToString(),
                    Status = n.OperationalStatus.ToString(),
                    LinkSpeedBps = n.Speed > 0 ? n.Speed : null,
                    IPv4Addresses = props.UnicastAddresses
                        .Where(u => u.Address.AddressFamily == AddressFamily.InterNetwork)
                        .Select(u => u.Address.ToString()).ToList(),
                    Gateway = props.GatewayAddresses.Select(g => g.Address.ToString())
                        .FirstOrDefault(g => g is not "0.0.0.0" and not "::"),
                    DnsServers = props.DnsAddresses
                        .Where(a => a.AddressFamily == AddressFamily.InterNetwork)
                        .Select(a => a.ToString()).ToList(),
                    Mac = n.GetPhysicalAddress().ToString()
                });
            }
        }
        catch { }
        return list;
    }
}
