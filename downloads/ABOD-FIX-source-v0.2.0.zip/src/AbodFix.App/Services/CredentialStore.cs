using System.IO;
using System.Runtime.Versioning;
using System.Security.Cryptography;
using System.Text;

namespace AbodFix.App.Services;

/// <summary>
/// Stores the AI API key encrypted with Windows DPAPI (per-user) in the app's
/// local data folder. The key never appears in app files, source, or logs.
/// </summary>
[SupportedOSPlatform("windows")]
public static class CredentialStore
{
    private static string FilePath =>
        Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "ABOD FIX", "ai.key");

    public static void SaveApiKey(string apiKey)
    {
        var bytes = ProtectedData.Protect(Encoding.UTF8.GetBytes(apiKey), null, DataProtectionScope.CurrentUser);
        Directory.CreateDirectory(Path.GetDirectoryName(FilePath)!);
        File.WriteAllBytes(FilePath, bytes);
    }

    public static string? LoadApiKey()
    {
        try
        {
            if (!File.Exists(FilePath)) return null;
            var bytes = ProtectedData.Unprotect(File.ReadAllBytes(FilePath), null, DataProtectionScope.CurrentUser);
            return Encoding.UTF8.GetString(bytes);
        }
        catch { return null; }
    }

    public static void DeleteApiKey()
    {
        try { if (File.Exists(FilePath)) File.Delete(FilePath); } catch { }
    }
}
