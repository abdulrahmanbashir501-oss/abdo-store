using System.Runtime.Versioning;
using AbodFix.Core.Contracts;
using AbodFix.Core.Models;

namespace AbodFix.App.Services;

/// <summary>Installed drivers with problem detection. Never downloads or installs drivers - information only, with official vendor links.</summary>
[SupportedOSPlatform("windows")]
public sealed class WmiDriverInfoProvider : IDriverInfoProvider
{
    public Task<IReadOnlyList<DriverInfo>> ListAsync(CancellationToken ct = default)
        => Task.Run<IReadOnlyList<DriverInfo>>(Query, ct);

    private static List<DriverInfo> Query()
    {
        var list = new List<DriverInfo>();
        try
        {
            foreach (var mo in WmiSystemInfoProvider.Query(
                "SELECT DeviceName, Manufacturer, DriverVersion, DriverDate, DeviceClass, PNPDeviceID FROM Win32_PnPSignedDriver"))
            {
                var name = WmiSystemInfoProvider.Str(mo, "DeviceName");
                if (name is null) continue;
                list.Add(new DriverInfo
                {
                    DeviceName = name,
                    Manufacturer = WmiSystemInfoProvider.Str(mo, "Manufacturer"),
                    DriverVersion = WmiSystemInfoProvider.Str(mo, "DriverVersion"),
                    DriverDate = WmiSystemInfoProvider.Str(mo, "DriverDate"),
                    DeviceClass = WmiSystemInfoProvider.Str(mo, "DeviceClass"),
                    PnpDeviceId = WmiSystemInfoProvider.Str(mo, "PNPDeviceID")
                });
            }
        }
        catch { }

        // problem codes live on Win32_PnPEntity
        try
        {
            var problems = new Dictionary<string, (int code, string status)>(StringComparer.OrdinalIgnoreCase);
            foreach (var mo in WmiSystemInfoProvider.Query(
                "SELECT PNPDeviceID, ConfigManagerErrorCode, Status FROM Win32_PnPEntity WHERE ConfigManagerErrorCode <> 0"))
            {
                var pnp = WmiSystemInfoProvider.Str(mo, "PNPDeviceID");
                if (pnp is null) continue;
                problems[pnp] = ((int)(WmiSystemInfoProvider.UInt(mo, "ConfigManagerErrorCode") ?? 0),
                    WmiSystemInfoProvider.Str(mo, "Status") ?? "Error");
            }
            list = list.Select(d => d.PnpDeviceId is not null && problems.TryGetValue(d.PnpDeviceId, out var p)
                ? d with { ProblemCode = p.code, Status = p.status }
                : d).ToList();
        }
        catch { }

        return list.OrderByDescending(d => d.HasProblem).ThenBy(d => d.DeviceName).ToList();
    }

    /// <summary>Official driver-update pages by vendor. Never third-party driver sites.</summary>
    public static string? OfficialVendorUrl(string? manufacturer, string? deviceName)
    {
        var text = $"{manufacturer} {deviceName}".ToLowerInvariant();
        if (text.Contains("nvidia")) return "https://www.nvidia.com/drivers";
        if (text.Contains("amd")) return "https://www.amd.com/support";
        if (text.Contains("intel")) return "https://www.intel.com/content/www/us/en/download-center/home.html";
        if (text.Contains("realtek")) return "https://www.realtek.com/en/downloads";
        if (text.Contains("qualcomm") || text.Contains("atheros")) return "https://www.qualcomm.com/support";
        if (text.Contains("microsoft")) return "https://support.microsoft.com/windows";
        return null;
    }
}
