using System.Diagnostics;
using System.Runtime.Versioning;
using System.Text;

namespace AbodFix.App.Services;

/// <summary>
/// Runs a whitelisted repair command with real streamed output.
/// Commands come from RepairCatalog only - the UI never passes free-form commands.
/// </summary>
[SupportedOSPlatform("windows")]
public static class ProcessCommandRunner
{
    public sealed record CommandResult(int ExitCode, string Output, TimeSpan Duration);

    /// <summary>Runs exe + fixed args. Output lines stream to onOutput as they arrive.</summary>
    public static async Task<CommandResult> RunAsync(string exe, string args,
        Action<string>? onOutput = null, CancellationToken ct = default)
    {
        var psi = new ProcessStartInfo
        {
            FileName = exe,
            Arguments = args,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            UseShellExecute = false,
            CreateNoWindow = true,
            StandardOutputEncoding = Encoding.UTF8
        };

        var sb = new StringBuilder();
        var sw = Stopwatch.StartNew();
        using var p = new Process { StartInfo = psi };
        p.Start();

        async Task Pump(System.IO.StreamReader reader)
        {
            string? line;
            while ((line = await reader.ReadLineAsync(ct)) is not null)
            {
                sb.AppendLine(line);
                onOutput?.Invoke(line);
            }
        }

        await Task.WhenAll(Pump(p.StandardOutput), Pump(p.StandardError), p.WaitForExitAsync(ct));
        sw.Stop();
        return new CommandResult(p.ExitCode, sb.ToString(), sw.Elapsed);
    }

    /// <summary>Opens an official Windows tool/URI (ms-settings:, devmgmt.msc, taskmgr). Never arbitrary targets.</summary>
    public static void OpenWindowsTool(string target)
    {
        string[] allowed = ["ms-settings:troubleshoot", "taskmgr.exe", "devmgmt.msc", "eventvwr.msc", "services.msc", "cleanmgr.exe"];
        if (!allowed.Contains(target, StringComparer.OrdinalIgnoreCase))
            throw new InvalidOperationException($"Tool '{target}' is not on the allowlist.");
        Process.Start(new ProcessStartInfo { FileName = target, UseShellExecute = true });
    }
}
