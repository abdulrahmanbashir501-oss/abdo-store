using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using AbodFix.Core.Contracts;
using AbodFix.Core.Models;

namespace AbodFix.App.ViewModels;

public sealed partial class NetworkViewModel : ObservableObject, IActivatable
{
    private readonly INetworkDiagnostics _diag;

    public ObservableCollection<NetworkCheckResult> Checks { get; } = new();
    public ObservableCollection<NetworkAdapterInfo> Adapters { get; } = new();
    public ObservableCollection<string> Findings { get; } = new();

    [ObservableProperty] private bool _isRunning;
    [ObservableProperty] private string? _overall;

    public NetworkViewModel(INetworkDiagnostics diag) => _diag = diag;

    public void Activate() { }

    [RelayCommand]
    private async Task RunAsync()
    {
        if (IsRunning) return;
        IsRunning = true;
        Checks.Clear(); Adapters.Clear(); Findings.Clear();
        Overall = null;
        try
        {
            var r = await _diag.RunAsync();
            foreach (var c in r.Checks) Checks.Add(c);
            foreach (var a in r.Adapters) Adapters.Add(a);
            foreach (var f in r.Findings) Findings.Add(f);
            Overall = r.AnyConnectivity
                ? Localization.LocalizationManager.Instance["Net.Connected"]
                : Localization.LocalizationManager.Instance["Net.NoConnectivity"];
        }
        finally { IsRunning = false; }
    }
}
