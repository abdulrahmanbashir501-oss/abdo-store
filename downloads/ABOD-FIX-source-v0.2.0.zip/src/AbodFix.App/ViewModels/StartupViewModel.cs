using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using AbodFix.App.Localization;
using AbodFix.App.Services;
using AbodFix.Core.Contracts;
using AbodFix.Core.Models;

namespace AbodFix.App.ViewModels;

public sealed partial class StartupViewModel : ObservableObject, IActivatable
{
    private readonly IStartupProvider _provider;
    private readonly ShellContext _app;
    private bool _activated;

    public ObservableCollection<StartupItem> Items { get; } = new();
    [ObservableProperty] private string? _status;

    public StartupViewModel(IStartupProvider provider, ShellContext app)
    {
        _provider = provider;
        _app = app;
    }

    public void Activate()
    {
        if (_activated) return;
        _activated = true;
        _ = RefreshAsync();
    }

    [RelayCommand]
    private async Task RefreshAsync()
    {
        Status = null;
        var items = await _provider.ListAsync();
        Items.Clear();
        foreach (var i in items) Items.Add(i);
    }

    [RelayCommand]
    private async Task ToggleAsync(StartupItem? item)
    {
        if (item is null) return;
        var loc = LocalizationManager.Instance;

        if (item.Enabled && item.LooksImportant)
        {
            var warn = string.Format(loc["Start.WarnImportantBody"], item.Name);
            if (!_app.Confirm.Confirm(loc["Start.WarnImportantTitle"], warn)) return;
        }

        var target = !item.Enabled;
        var action = target ? "Enable" : "Disable";
        if (!_app.Confirm.Confirm(loc["Start.ConfirmTitle"],
            string.Format(loc["Start.ConfirmBody"], action, item.Name, item.SourceKey)))
            return;

        var result = await _provider.SetEnabledAsync(item, target);
        await _app.History.AddEntryAsync(new HistoryEntry
        {
            Kind = result.Success ? HistoryKind.Info : HistoryKind.Error,
            Title = $"{action} startup item: {item.Name}",
            Details = item.SourceKey,
            Result = result.Message
        });
        _app.Confirm.Info(result.Success ? "OK" : loc["Common.Error"], result.Message);
        await RefreshAsync();
    }
}
