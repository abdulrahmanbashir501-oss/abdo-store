using CommunityToolkit.Mvvm.ComponentModel;
using AbodFix.App.Localization;

namespace AbodFix.App.ViewModels;

public sealed record NavItem(string LabelKey, string Icon, ObservableObject Page)
{
    public string Label => LocalizationManager.Instance[LabelKey];
}

public sealed partial class MainViewModel : ObservableObject
{
    public IReadOnlyList<NavItem> Items { get; }

    [ObservableProperty]
    private NavItem? _selected;

    public MainViewModel(DashboardViewModel dashboard, DiagnosticsViewModel diagnostics,
        RepairViewModel repair, StartupViewModel startup, AnalyzerViewModel analyzer,
        ProcessesViewModel processes, DisksViewModel disks, NetworkViewModel network,
        DriversViewModel drivers, AiViewModel ai,
        ReportsViewModel reports, HistoryViewModel history, SettingsViewModel settings)
    {
        Items =
        [
            new NavItem("Nav.Dashboard", "\uE80F", dashboard),
            new NavItem("Nav.Diagnostics", "\uE99A", diagnostics),
            new NavItem("Nav.Repair", "\uE90F", repair),
            new NavItem("Nav.Startup", "\uE7E8", startup),
            new NavItem("Nav.Analyzer", "\uE9F5", analyzer),
            new NavItem("Nav.Processes", "\uE9D9", processes),
            new NavItem("Nav.Disks", "\uEDA2", disks),
            new NavItem("Nav.Network", "\uE968", network),
            new NavItem("Nav.Drivers", "\uE772", drivers),
            new NavItem("Nav.Ai", "\uE99B", ai),
            new NavItem("Nav.Reports", "\uE9F9", reports),
            new NavItem("Nav.History", "\uE81C", history),
            new NavItem("Nav.Settings", "\uE713", settings),
        ];
        Selected = Items[0];

        // refresh nav labels when language changes
        LocalizationManager.Instance.PropertyChanged += (_, e) =>
        {
            if (e.PropertyName is "Item[]") OnPropertyChanged(nameof(Items));
        };
    }

    partial void OnSelectedChanged(NavItem? value)
    {
        if (value?.Page is IActivatable a) a.Activate();
    }
}

/// <summary>Pages that start/stop work when shown/hidden.</summary>
public interface IActivatable
{
    void Activate();
}
