using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using AbodFix.Core.Contracts;
using AbodFix.Core.Models;

namespace AbodFix.App.ViewModels;

public sealed partial class DisksViewModel : ObservableObject, IActivatable
{
    private readonly IDiskHealthProvider _disks;
    private readonly IMetricsSampler _sampler;
    private bool _activated;

    public ObservableCollection<DiskHealthInfo> PhysicalDisks { get; } = new();
    public ObservableCollection<DiskSample> Volumes { get; } = new();

    [ObservableProperty] private bool _isLoading;

    public DisksViewModel(IDiskHealthProvider disks, IMetricsSampler sampler)
    {
        _disks = disks;
        _sampler = sampler;
    }

    public void Activate()
    {
        if (_activated) return;
        _activated = true;
        _ = RefreshAsync();
    }

    [RelayCommand]
    private async Task RefreshAsync()
    {
        IsLoading = true;
        try
        {
            var health = await _disks.GetDisksAsync();
            var snap = await _sampler.SampleAsync();
            PhysicalDisks.Clear();
            foreach (var d in health) PhysicalDisks.Add(d);
            Volumes.Clear();
            foreach (var v in snap.Disks) Volumes.Add(v);
        }
        finally { IsLoading = false; }
    }
}
