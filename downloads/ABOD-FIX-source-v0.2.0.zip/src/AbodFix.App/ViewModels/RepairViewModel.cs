using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using AbodFix.App.Localization;
using AbodFix.App.Services;
using AbodFix.Core.Models;
using AbodFix.Core.Repair;

namespace AbodFix.App.ViewModels;

/// <summary>
/// Smart Repair Center. Every operation: shows description, exact commands,
/// risks and undo, then requires explicit confirmation. File cleanup shows the
/// full preview list first. Everything is logged to history with its result.
/// </summary>
public sealed partial class RepairViewModel : ObservableObject, IActivatable
{
    private readonly ShellContext _app;

    public IReadOnlyList<RepairPlan> Plans { get; } = RepairCatalog.All;

    [ObservableProperty] private RepairPlan? _selected;
    [ObservableProperty] private bool _isBusy;
    [ObservableProperty] private string _log = "";
    [ObservableProperty] private CleanupPreview? _preview;

    public ObservableCollection<CleanupItem> PreviewItems { get; } = new();

    public RepairViewModel(ShellContext app) => _app = app;

    public void Activate() { }

    private void AppendLog(string line) => Log += line + "\n";

    [RelayCommand]
    private void PreviewCleanup()
    {
        if (Selected?.Id != "temp-cleanup") return;
        Preview = TempCleanupPlanner.BuildPreview();
        PreviewItems.Clear();
        foreach (var i in Preview.Items) PreviewItems.Add(i);
    }

    [RelayCommand]
    private async Task ExecuteAsync()
    {
        if (Selected is null || IsBusy) return;
        var loc = LocalizationManager.Instance;
        var plan = Selected;
        Log = "";
        Preview = null;

        // confirmation with full disclosure
        var risks = loc.IsArabic ? plan.RisksAr : plan.Risks;
        var confirm = string.Format(loc["Rep2.ConfirmBody"],
            loc.IsArabic ? plan.DescriptionAr : plan.Description,
            plan.Commands.Count > 0 ? string.Join("\n", plan.Commands) : "-",
            risks.Count > 0 ? string.Join("\n", risks.Select(r => "- " + r)) : "-",
            loc.IsArabic ? (plan.UndoAr ?? "-") : (plan.Undo ?? "-"));
        if (!_app.Confirm.Confirm(loc["Rep2.ConfirmTitle"], confirm)) return;

        IsBusy = true;
        var startMsg = loc.IsArabic ? plan.TitleAr : plan.Title;
        AppendLog($"=== {startMsg} ===");
        try
        {
            string result;
            switch (plan.Kind)
            {
                case RepairKind.OpenTool:
                {
                    ProcessCommandRunner.OpenWindowsTool(plan.Commands[0]);
                    result = "Opened the official Windows tool.";
                    AppendLog(result);
                    break;
                }
                case RepairKind.FileCleanup:
                {
                    var preview = TempCleanupPlanner.BuildPreview();
                    var ok = _app.Confirm.Confirm(loc["Rep2.CleanupConfirmTitle"],
                        string.Format(loc["Rep2.CleanupConfirmBody"], preview.Items.Count,
                            Core.Reports.TxtReportExporter.FormatBytes(preview.TotalBytes)));
                    if (!ok) { AppendLog("Cancelled."); IsBusy = false; return; }
                    var (deleted, skipped, freed) = TempCleanupPlanner.Execute(preview);
                    result = $"Deleted {deleted} temp file(s), freed {Core.Reports.TxtReportExporter.FormatBytes(freed)}, skipped {skipped} in use.";
                    AppendLog(result);
                    break;
                }
                default:
                {
                    var lastExit = 0;
                    foreach (var cmd in plan.Commands)
                    {
                        var (exe, args) = Split(cmd);
                        AppendLog($"> {cmd}");
                        var r = await ProcessCommandRunner.RunAsync(exe, args, line => AppendLog(line));
                        lastExit = r.ExitCode;
                        AppendLog($"exit code: {r.ExitCode}, {r.Duration.TotalSeconds:F0}s");
                    }
                    result = $"Finished with exit code {lastExit}.";
                    break;
                }
            }

            await _app.History.AddEntryAsync(new HistoryEntry
            {
                Kind = HistoryKind.Repair,
                Title = plan.Title,
                Details = plan.Commands.Count > 0 ? string.Join("; ", plan.Commands) : plan.Description,
                Result = result
            });
            AppendLog("Done. Logged to history.");
        }
        catch (Exception ex)
        {
            AppendLog($"FAILED: {ex.Message}");
            await _app.History.AddEntryAsync(new HistoryEntry
            {
                Kind = HistoryKind.Error, Title = plan.Title, Result = ex.Message
            });
        }
        finally { IsBusy = false; }
    }

    private static (string exe, string args) Split(string cmd)
    {
        var i = cmd.IndexOf(' ');
        return i < 0 ? (cmd, "") : (cmd[..i], cmd[(i + 1)..]);
    }
}
