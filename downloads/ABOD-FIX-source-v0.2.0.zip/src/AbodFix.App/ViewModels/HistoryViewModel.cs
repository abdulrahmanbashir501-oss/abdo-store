using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using AbodFix.App.Services;
using AbodFix.Core.Models;

namespace AbodFix.App.ViewModels;

public sealed partial class HistoryViewModel : ObservableObject, IActivatable
{
    private readonly ShellContext _app;
    private bool _activated;

    public ObservableCollection<HistoryEntry> Entries { get; } = new();

    public HistoryViewModel(ShellContext app) => _app = app;

    public void Activate()
    {
        if (_activated) return;
        _activated = true;
        _ = RefreshAsync();
    }

    [RelayCommand]
    public async Task RefreshAsync()
    {
        var items = await _app.History.GetRecentAsync(200);
        Entries.Clear();
        foreach (var e in items) Entries.Add(e);
    }
}
