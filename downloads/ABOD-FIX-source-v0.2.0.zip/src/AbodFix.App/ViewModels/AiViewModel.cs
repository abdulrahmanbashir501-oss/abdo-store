using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using AbodFix.App.Localization;
using AbodFix.App.Services;
using AbodFix.Core.Ai;

namespace AbodFix.App.ViewModels;

public sealed record ChatLine(string Role, string Text);

public sealed partial class AiViewModel : ObservableObject, IActivatable
{
    private readonly ShellContext _app;
    private readonly List<AiChatMessage> _history = new();

    public ObservableCollection<ChatLine> Lines { get; } = new();

    [ObservableProperty] private string _endpoint = "https://api.openai.com/v1/chat/completions";
    [ObservableProperty] private string _model = "gpt-4o-mini";
    [ObservableProperty] private bool _hasKey;
    [ObservableProperty] private string _input = "";
    [ObservableProperty] private bool _isBusy;
    [ObservableProperty] private string? _status;

    public AiViewModel(ShellContext app) => _app = app;

    public void Activate() => LoadSettings();

    private void LoadSettings()
    {
        HasKey = CredentialStore.LoadApiKey() is not null;
        _ = Task.Run(async () =>
        {
            var ep = await _app.History.GetSettingAsync("ai.endpoint");
            var m = await _app.History.GetSettingAsync("ai.model");
            System.Windows.Application.Current?.Dispatcher.Invoke(() =>
            {
                if (!string.IsNullOrWhiteSpace(ep)) Endpoint = ep;
                if (!string.IsNullOrWhiteSpace(m)) Model = m;
            });
        });
    }

    [RelayCommand]
    private async Task SaveSettingsAsync()
    {
        await _app.History.SetSettingAsync("ai.endpoint", Endpoint);
        await _app.History.SetSettingAsync("ai.model", Model);
        HasKey = CredentialStore.LoadApiKey() is not null;
        Status = "OK";
    }

    /// <summary>Called by the view's PasswordBox; the key goes straight to DPAPI storage, never to files or logs.</summary>
    public void SetApiKey(string key)
    {
        if (string.IsNullOrWhiteSpace(key)) return;
        CredentialStore.SaveApiKey(key.Trim());
        HasKey = true;
        Status = "Key saved (encrypted with Windows DPAPI, per-user).";
    }

    [RelayCommand]
    private async Task SendAsync()
    {
        var text = Input.Trim();
        if (text.Length == 0 || IsBusy) return;
        var key = CredentialStore.LoadApiKey();
        if (key is null)
        {
            Status = LocalizationManager.Instance["Ai.NeedsKey"];
            return;
        }
        Input = "";
        Lines.Add(new ChatLine("user", text));
        _history.Add(new AiChatMessage("user", text));
        IsBusy = true;
        Status = null;
        try
        {
            var client = new AiTechnicianClient(Endpoint, Model, key);
            var lang = LocalizationManager.Instance.IsArabic ? "ar" : "en";
            var reply = await client.ChatAsync(_history, AiTechnicianClient.DefaultSystemPrompt(lang));
            _history.Add(new AiChatMessage("assistant", reply));
            Lines.Add(new ChatLine("assistant", reply));
        }
        catch (Exception ex)
        {
            Status = ex.Message;
            Lines.Add(new ChatLine("system", ex.Message));
        }
        finally { IsBusy = false; }
    }
}
