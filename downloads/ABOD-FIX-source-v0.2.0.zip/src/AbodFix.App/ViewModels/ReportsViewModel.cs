using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using AbodFix.App.Localization;
using AbodFix.App.Services;
using AbodFix.Core.Models;
using AbodFix.Core.Reports;

namespace AbodFix.App.ViewModels;

public sealed record ReportFormatOption(string Label, IReportExporter Exporter);

public sealed partial class ReportsViewModel : ObservableObject, IActivatable
{
    private readonly ReportBuilder _builder;
    private readonly ShellContext _app;
    private readonly HistoryViewModel _history;

    public IReadOnlyList<ReportFormatOption> Formats { get; } =
    [
        new("PDF", new PdfReportExporter()),
        new("TXT", new TxtReportExporter()),
        new("JSON", new JsonReportExporter()),
    ];

    [ObservableProperty] private ReportFormatOption _selectedFormat;
    [ObservableProperty] private bool _isBusy;
    [ObservableProperty] private string? _status;
    [ObservableProperty] private bool _statusIsError;

    public ReportsViewModel(ReportBuilder builder, ShellContext app, HistoryViewModel history)
    {
        _builder = builder;
        _app = app;
        _history = history;
        _selectedFormat = Formats[0];
    }

    public void Activate() { }

    [RelayCommand]
    private async Task GenerateAsync()
    {
        if (IsBusy) return;
        var loc = LocalizationManager.Instance;
        var stamp = DateTime.Now.ToString("yyyy-MM-dd_HHmmss");
        var path = _app.FileDialog.AskSavePath(
            $"ABOD-FIX-report-{stamp}.{SelectedFormat.Exporter.Format}",
            SelectedFormat.Exporter.Format,
            $"{SelectedFormat.Exporter.Format.ToUpperInvariant()} report|*.{SelectedFormat.Exporter.Format}");
        if (path is null) return;

        IsBusy = true;
        StatusIsError = false;
        Status = loc["Rep.Generating"];
        try
        {
            var data = await _builder.BuildAsync(loc["Rep.System"]);
            await SelectedFormat.Exporter.ExportAsync(data, path);
            Status = $"{loc["Rep.Done"]} {path}";
            await _app.History.AddEntryAsync(new HistoryEntry
            {
                Kind = HistoryKind.Scan,
                Title = $"Report generated ({SelectedFormat.Exporter.Format.ToUpperInvariant()})",
                Result = path
            });
            await _history.RefreshAsync();
        }
        catch (Exception ex)
        {
            StatusIsError = true;
            Status = $"{loc["Rep.Failed"]} {ex.Message}";
            await _app.History.AddEntryAsync(new HistoryEntry
            {
                Kind = HistoryKind.Error,
                Title = "Report generation failed",
                Result = ex.Message
            });
        }
        finally { IsBusy = false; }
    }
}
