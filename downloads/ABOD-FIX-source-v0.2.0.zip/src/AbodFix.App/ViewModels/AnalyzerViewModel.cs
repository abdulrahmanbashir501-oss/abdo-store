using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using AbodFix.App.Services;
using AbodFix.Core.Analyzer;
using AbodFix.Core.Models;

namespace AbodFix.App.ViewModels;

public sealed partial class AnalyzerViewModel : ObservableObject, IActivatable
{
    private readonly ErrorAnalyzer _analyzer = new();
    private readonly ShellContext _app;

    [ObservableProperty] private string _input = "";
    [ObservableProperty] private ErrorAnalysis? _result;

    public AnalyzerViewModel(ShellContext app) => _app = app;

    public void Activate() { }

    [RelayCommand]
    private async Task AnalyzeAsync()
    {
        var text = Input.Trim();
        if (text.Length == 0) return;
        Result = _analyzer.Analyze(text);
        await _app.History.AddEntryAsync(new HistoryEntry
        {
            Kind = HistoryKind.Info,
            Title = $"Error analysis: {Result.ProblemName}",
            Details = text.Length > 300 ? text[..300] : text,
            Result = Result.MatchedRuleId ?? "no confident match"
        });
    }
}
