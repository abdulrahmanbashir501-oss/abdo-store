using System.Collections.ObjectModel;
using System.Windows.Threading;
using CommunityToolkit.Mvvm.ComponentModel;
using AbodFix.App.Localization;
using AbodFix.Core.Contracts;
using AbodFix.Core.Models;

namespace AbodFix.App.ViewModels;

public sealed partial class DashboardViewModel : ObservableObject, IActivatable, IDisposable
{
    private readonly ISystemInfoProvider _systemInfo;
    private readonly IMetricsSampler _sampler;
    private readonly DispatcherTimer _timer;
    private bool _activated;
    private bool _sampling;

    public ObservableCollection<double> CpuHistory { get; } = new();
    public ObservableCollection<double> RamHistory { get; } = new();

    [ObservableProperty] private string _cpuName = "...";
    [ObservableProperty] private string _gpuName = "...";
    [ObservableProperty] private string _osCaption = "...";
    [ObservableProperty] private string _cpuText = "--";
    [ObservableProperty] private string _ramText = "--";
    [ObservableProperty] private string _ramDetail = "";
    [ObservableProperty] private string _gpuText = "--";
    [ObservableProperty] private string _cpuTempText = "--";
    [ObservableProperty] private string _uptimeText = "--";
    [ObservableProperty] private string _networkText = "--";
    [ObservableProperty] private double _ramPercent;
    [ObservableProperty] private double _cpuPercent;
    [ObservableProperty] private bool _isLoading = true;

    public ObservableCollection<DiskSample> Disks { get; } = new();

    public DashboardViewModel(ISystemInfoProvider systemInfo, IMetricsSampler sampler)
    {
        _systemInfo = systemInfo;
        _sampler = sampler;

        _timer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(1) };
        _timer.Tick += async (_, _) => await SampleOnceAsync();
    }

    public void Activate()
    {
        if (_activated) return;
        _activated = true;
        _ = LoadStaticAsync();
        _timer.Start();
    }

    private async Task LoadStaticAsync()
    {
        try
        {
            var hw = await _systemInfo.GetHardwareProfileAsync();
            CpuName = hw.Cpu.Name;
            GpuName = hw.Gpus.Count > 0 ? string.Join(" + ", hw.Gpus.Select(g => g.Name)) : LocalizationManager.Instance["Dash.NotSupported"];
            OsCaption = $"{hw.Os.Caption} ({hw.Os.BuildNumber})";
        }
        catch { /* texts stay at placeholder; sample loop still runs */ }
    }

    private async Task SampleOnceAsync()
    {
        if (_sampling) return;
        _sampling = true;
        try
        {
            var s = await _sampler.SampleAsync();
            IsLoading = false;

            CpuPercent = s.CpuUsagePercent ?? 0;
            CpuText = s.CpuUsagePercent is double c ? $"{c:F1} %" : LocalizationManager.Instance["Dash.NotSupported"];
            RamPercent = s.RamUsedPercent ?? 0;
            RamText = s.RamUsedPercent is double r ? $"{r:F1} %" : "--";
            RamDetail = s.RamUsedBytes is long u && s.RamTotalBytes is long t
                ? $"{Core.Reports.TxtReportExporter.FormatBytes(u)} / {Core.Reports.TxtReportExporter.FormatBytes(t)}"
                : "";
            GpuText = s.GpuUsagePercent is double g ? $"{g:F1} %" : LocalizationManager.Instance["Dash.NotSupported"];
            CpuTempText = s.CpuTemperatureCelsius is double ct ? $"{ct:F1} °C" : LocalizationManager.Instance["Dash.NotSupported"];
            UptimeText = s.Uptime is TimeSpan up ? $"{(int)up.TotalDays}d {up.Hours}h {up.Minutes}m" : "--";
            NetworkText = s.Network == NetworkStatus.Connected
                ? LocalizationManager.Instance["Dash.Connected"]
                : LocalizationManager.Instance["Dash.Disconnected"];

            Push(CpuHistory, s.CpuUsagePercent);
            Push(RamHistory, s.RamUsedPercent);

            Disks.Clear();
            foreach (var d in s.Disks) Disks.Add(d);
        }
        catch { /* keep last values; next tick retries */ }
        finally { _sampling = false; }
    }

    private static void Push(ObservableCollection<double> points, double? value)
    {
        if (value is null) return;
        points.Add(value.Value);
        while (points.Count > 60) points.RemoveAt(0);
    }

    public void Dispose() => _timer.Stop();
}
