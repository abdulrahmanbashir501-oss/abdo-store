using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using AbodFix.App.Localization;
using AbodFix.App.Services;
using AbodFix.Core.Contracts;
using AbodFix.Core.Models;

namespace AbodFix.App.ViewModels;

public sealed partial class ProcessesViewModel : ObservableObject, IActivatable
{
    private readonly IProcessProvider _provider;
    private readonly ShellContext _app;
    private List<ProcessInfo> _all = [];
    private bool _activated;

    public ObservableCollection<ProcessInfo> Processes { get; } = new();

    [ObservableProperty] private string _filter = "";
    [ObservableProperty] private int _totalCount;
    [ObservableProperty] private string? _status;
    [ObservableProperty] private ProcessInfo? _selectedProcess;

    public ProcessesViewModel(IProcessProvider provider, ShellContext app)
    {
        _provider = provider;
        _app = app;
    }

    public void Activate()
    {
        if (_activated) return;
        _activated = true;
        _ = RefreshAsync();
    }

    partial void OnFilterChanged(string value) => ApplyFilter();

    [RelayCommand]
    private async Task RefreshAsync()
    {
        Status = null;
        try
        {
            _all = (await _provider.ListProcessesAsync())
                .OrderByDescending(p => p.MemoryBytes ?? 0).ToList();
            TotalCount = _all.Count;
            ApplyFilter();
        }
        catch (Exception ex)
        {
            Status = ex.Message;
        }
    }

    private void ApplyFilter()
    {
        var f = Filter.Trim();
        var view = f.Length == 0 ? _all
            : _all.Where(p => p.Name.Contains(f, StringComparison.OrdinalIgnoreCase)
                           || (p.Company?.Contains(f, StringComparison.OrdinalIgnoreCase) ?? false)
                           || p.Pid.ToString() == f).ToList();
        Processes.Clear();
        foreach (var p in view.Take(500)) Processes.Add(p);
    }

    [RelayCommand]
    private async Task KillAsync(ProcessInfo? p)
    {
        if (p is null) return;
        var loc = LocalizationManager.Instance;
        if (p.IsCriticalSystemProcess)
        {
            _app.Confirm.Info(loc["Proc.Protected"], $"'{p.Name}' - {loc["Proc.Protected"]}");
            return;
        }
        var msg = string.Format(loc["Proc.KillConfirm"], p.Name, p.Pid);
        if (!_app.Confirm.Confirm(loc["Proc.KillConfirmTitle"], msg)) return;

        var result = WindowsProcessProvider.Kill(p.Pid, p.Name);
        await _app.History.AddEntryAsync(new HistoryEntry
        {
            Kind = result.Success ? HistoryKind.Info : HistoryKind.Error,
            Title = $"End process {p.Name} (PID {p.Pid})",
            Result = result.Message
        });
        _app.Confirm.Info(result.Success ? "OK" : loc["Common.Error"], result.Message);
        await RefreshAsync();
    }
}
