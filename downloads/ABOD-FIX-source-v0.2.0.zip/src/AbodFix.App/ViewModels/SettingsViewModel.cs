using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using AbodFix.App.Localization;
using AbodFix.App.Services;

namespace AbodFix.App.ViewModels;

public sealed partial class SettingsViewModel : ObservableObject, IActivatable
{
    private readonly ShellContext _app;

    public SettingsViewModel(ShellContext app)
    {
        _app = app;
        _isArabic = LocalizationManager.Instance.IsArabic;
    }

    public void Activate() { }

    [ObservableProperty]
    private bool _isArabic;

    partial void OnIsArabicChanged(bool value)
    {
        LocalizationManager.Instance.Language = value ? "ar" : "en";
        _ = _app.History.SetSettingAsync("language", value ? "ar" : "en");
    }

    public async Task LoadAsync()
    {
        var lang = await _app.History.GetSettingAsync("language");
        if (lang is "ar" or "en")
        {
            LocalizationManager.Instance.Language = lang;
            IsArabic = lang == "ar";
        }
    }
}
