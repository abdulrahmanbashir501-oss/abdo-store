using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using AbodFix.Core.Contracts;
using AbodFix.Core.Models;

namespace AbodFix.App.ViewModels;

public sealed partial class DiagnosticsViewModel : ObservableObject, IActivatable
{
    private readonly IDiagnosticsRunner _runner;
    private readonly Services.ShellContext _app;

    public ObservableCollection<DiagnosticCheck> Checks { get; } = new();
    [ObservableProperty] private bool _isRunning;
    [ObservableProperty] private string? _summaryLine;

    public DiagnosticsViewModel(IDiagnosticsRunner runner, Services.ShellContext app)
    {
        _runner = runner;
        _app = app;
        _runner.CheckUpdated += OnCheckUpdated;
    }

    public void Activate() { }

    private void OnCheckUpdated(DiagnosticCheck c)
    {
        System.Windows.Application.Current?.Dispatcher.Invoke(() =>
        {
            var existing = Checks.FirstOrDefault(x => x.Id == c.Id);
            if (existing is null) Checks.Add(c);
            else
            {
                var idx = Checks.IndexOf(existing);
                Checks[idx] = c;
            }
        });
    }

    [RelayCommand]
    private async Task RunAllAsync()
    {
        if (IsRunning) return;
        IsRunning = true;
        Checks.Clear();
        SummaryLine = null;
        try
        {
            var results = await _runner.RunAllAsync();
            var bad = results.Count(r => r.Status is CheckStatus.Failed or CheckStatus.Warning);
            SummaryLine = bad == 0
                ? Localization.LocalizationManager.Instance["Diag.AllGood"]
                : string.Format(Localization.LocalizationManager.Instance["Diag.IssuesFound"], bad);
            await _app.History.AddEntryAsync(new HistoryEntry
            {
                Kind = bad == 0 ? HistoryKind.Scan : HistoryKind.Warning,
                Title = "Windows diagnostics scan",
                Result = SummaryLine
            });
        }
        finally { IsRunning = false; }
    }
}
