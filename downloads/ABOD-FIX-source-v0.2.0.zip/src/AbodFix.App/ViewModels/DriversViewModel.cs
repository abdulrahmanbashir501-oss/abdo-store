using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using AbodFix.App.Services;
using AbodFix.Core.Contracts;
using AbodFix.Core.Models;

namespace AbodFix.App.ViewModels;

public sealed partial class DriversViewModel : ObservableObject, IActivatable
{
    private readonly IDriverInfoProvider _provider;
    private bool _activated;

    public ObservableCollection<DriverInfo> Drivers { get; } = new();
    [ObservableProperty] private int _problemCount;
    [ObservableProperty] private string _filter = "";
    [ObservableProperty] private DriverInfo? _selectedDriver;

    private List<DriverInfo> _all = [];

    public DriversViewModel(IDriverInfoProvider provider) => _provider = provider;

    public void Activate()
    {
        if (_activated) return;
        _activated = true;
        _ = RefreshAsync();
    }

    partial void OnFilterChanged(string value) => Apply();

    [RelayCommand]
    private async Task RefreshAsync()
    {
        _all = (await _provider.ListAsync()).ToList();
        ProblemCount = _all.Count(d => d.HasProblem);
        Apply();
    }

    private void Apply()
    {
        var f = Filter.Trim();
        Drivers.Clear();
        foreach (var d in (f.Length == 0 ? _all : _all.Where(d =>
            d.DeviceName.Contains(f, StringComparison.OrdinalIgnoreCase)
            || (d.Manufacturer?.Contains(f, StringComparison.OrdinalIgnoreCase) ?? false))).Take(400))
            Drivers.Add(d);
    }

    [RelayCommand]
    private void OpenVendor(DriverInfo? d)
    {
        var url = WmiDriverInfoProvider.OfficialVendorUrl(d?.Manufacturer, d?.DeviceName);
        if (url is not null)
            System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo { FileName = url, UseShellExecute = true });
    }

    [RelayCommand]
    private void OpenDeviceManager() => ProcessCommandRunner.OpenWindowsTool("devmgmt.msc");
}
