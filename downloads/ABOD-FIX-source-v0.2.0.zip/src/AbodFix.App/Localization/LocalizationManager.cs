using System.ComponentModel;
using System.Windows;

namespace AbodFix.App.Localization;

/// <summary>
/// Runtime EN/AR localization. Bind with {Binding [Key], Source={x:Static loc:Loc.Manager}}.
/// Switching language refreshes every binding and the window flow direction (Arabic = RTL).
/// </summary>
public sealed class LocalizationManager : INotifyPropertyChanged
{
    public static LocalizationManager Instance { get; } = new();

    public event PropertyChangedEventHandler? PropertyChanged;

    private string _language = "ar"; // user's product: Arabic first
    public string Language
    {
        get => _language;
        set
        {
            if (_language == value) return;
            _language = value;
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs("Item[]"));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(FlowDirection)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(IsArabic)));
        }
    }

    public bool IsArabic => Language == "ar";
    public FlowDirection FlowDirection => IsArabic ? System.Windows.FlowDirection.RightToLeft : System.Windows.FlowDirection.LeftToRight;

    public string this[string key] => Translate(Language, key);

    public static string Translate(string lang, string key)
        => (lang == "ar" ? Ar : En).TryGetValue(key, out var v) ? v : En.TryGetValue(key, out var e) ? e : key;

    private static readonly Dictionary<string, string> En = new()
    {
        ["App.Title"] = "ABOD FIX",
        ["App.Subtitle"] = "Windows Diagnostic & Repair Assistant",
        ["App.ReadOnly"] = "READ-ONLY MODE",
        ["Nav.Dashboard"] = "Dashboard",
        ["Nav.Processes"] = "Processes",
        ["Nav.Disks"] = "Disk Health",
        ["Nav.Reports"] = "Reports",
        ["Nav.History"] = "History",
        ["Nav.Settings"] = "Settings",

        ["Dash.Cpu"] = "CPU",
        ["Dash.Ram"] = "Memory (RAM)",
        ["Dash.Gpu"] = "GPU",
        ["Dash.Disks"] = "Storage",
        ["Dash.Uptime"] = "Uptime",
        ["Dash.Network"] = "Network",
        ["Dash.CpuTemp"] = "CPU temperature",
        ["Dash.GpuUsage"] = "GPU usage",
        ["Dash.Connected"] = "Connected",
        ["Dash.Disconnected"] = "Disconnected",
        ["Dash.NotSupported"] = "Not supported by this device",
        ["Dash.Loading"] = "Reading real system data...",
        ["Dash.UsageHistory"] = "Usage history (last 60 seconds)",
        ["Dash.Free"] = "free",
        ["Dash.Of"] = "of",
        ["Dash.OsInfo"] = "Operating system",

        ["Proc.Search"] = "Search processes...",
        ["Proc.Name"] = "Process",
        ["Proc.Pid"] = "PID",
        ["Proc.Cpu"] = "CPU %",
        ["Proc.Memory"] = "Memory",
        ["Proc.Company"] = "Company",
        ["Proc.Protected"] = "Windows system process - protected",
        ["Proc.Kill"] = "End process",
        ["Proc.KillConfirmTitle"] = "Confirm: end process",
        ["Proc.KillConfirm"] = "End process '{0}' (PID {1})?\n\nUnsaved work in this program will be lost.",
        ["Proc.Refresh"] = "Refresh",
        ["Proc.Count"] = "processes",

        ["Disk.Title"] = "Physical disks",
        ["Disk.Volumes"] = "Volumes",
        ["Disk.Model"] = "Model",
        ["Disk.Interface"] = "Interface",
        ["Disk.Size"] = "Size",
        ["Disk.Smart"] = "SMART status",
        ["Disk.SmartOk"] = "No failure predicted",
        ["Disk.SmartBad"] = "FAILURE PREDICTED - back up now",
        ["Disk.SmartUnknown"] = "Unknown - not reported by device",
        ["Disk.Note"] = "SMART is one indicator only. A 'no failure predicted' result does not guarantee the disk is healthy.",
        ["Disk.Used"] = "used",

        ["Rep.Title"] = "Generate a report",
        ["Rep.Subtitle"] = "Reports contain real measured data from this machine only.",
        ["Rep.System"] = "System summary report",
        ["Rep.Format"] = "Format",
        ["Rep.Generate"] = "Generate report",
        ["Rep.Generating"] = "Collecting data and generating report...",
        ["Rep.Done"] = "Report saved:",
        ["Rep.Failed"] = "Report generation failed:",

        ["Hist.Title"] = "Activity history",
        ["Hist.Empty"] = "No activity recorded yet.",
        ["Hist.Kind.Scan"] = "Scan",
        ["Hist.Kind.Repair"] = "Repair",
        ["Hist.Kind.Info"] = "Info",
        ["Hist.Kind.Warning"] = "Warning",
        ["Hist.Kind.Error"] = "Error",

        ["Set.Language"] = "Language",
        ["Set.Language.Ar"] = "العربية",
        ["Set.Language.En"] = "English",
        ["Set.Mode"] = "Safety mode",
        ["Set.Mode.ReadOnly"] = "Read-only (diagnosis only, nothing is changed on the system)",
        ["Set.Mode.Note"] = "Repair actions (phase 2) will always ask for your confirmation and show the exact commands before running.",
        ["Set.About"] = "About",
        ["Set.AboutText"] = "ABOD FIX reads real data from Windows (WMI, Performance Counters, Event Log). It never invents values. If a sensor is not supported by your device, the app says so instead of showing a fake number.",

        ["Nav.Diagnostics"] = "Diagnostics",
        ["Nav.Repair"] = "Repair Center",
        ["Nav.Startup"] = "Startup Apps",
        ["Nav.Analyzer"] = "Error Analyzer",
        ["Nav.Network"] = "Network",
        ["Nav.Drivers"] = "Drivers",
        ["Nav.Ai"] = "AI Technician",

        ["Diag.Title"] = "Windows diagnostics",
        ["Diag.Run"] = "Run full scan",
        ["Diag.Running"] = "Scanning...",
        ["Diag.AllGood"] = "All checks passed.",
        ["Diag.IssuesFound"] = "{0} check(s) need attention.",
        ["Diag.Status.Passed"] = "Passed",
        ["Diag.Status.Warning"] = "Warning",
        ["Diag.Status.Failed"] = "Failed",
        ["Diag.Status.Running"] = "Running...",
        ["Diag.Status.Pending"] = "Pending",

        ["Rep2.Title"] = "Smart Repair Center",
        ["Rep2.Note"] = "Every action shows exactly what it will do and waits for your confirmation. Everything is logged.",
        ["Rep2.Commands"] = "Commands that will run:",
        ["Rep2.Risks"] = "Risks:",
        ["Rep2.Undo"] = "Undo:",
        ["Rep2.Admin"] = "Needs Administrator",
        ["Rep2.Execute"] = "Run this repair",
        ["Rep2.Preview"] = "Preview files",
        ["Rep2.ConfirmTitle"] = "Confirm repair",
        ["Rep2.ConfirmBody"] = "{0}\n\nCommands:\n{1}\n\nRisks:\n{2}\n\nUndo: {3}\n\nProceed?",
        ["Rep2.CleanupConfirmTitle"] = "Confirm temp cleanup",
        ["Rep2.CleanupConfirmBody"] = "Delete {0} temp file(s), total {1}? Files in use are skipped. This cannot be undone.",
        ["Rep2.Log"] = "Operation log",

        ["Start.Title"] = "Startup programs",
        ["Start.Note"] = "Disabling moves the entry to a safe ABOD FIX backup - nothing is deleted, and you can re-enable anytime.",
        ["Start.Enabled"] = "Enabled",
        ["Start.Disabled"] = "Disabled",
        ["Start.ToggleOn"] = "Disable",
        ["Start.ToggleOff"] = "Enable",
        ["Start.Important"] = "Looks important",
        ["Start.WarnImportantTitle"] = "This looks important",
        ["Start.WarnImportantBody"] = "'{0}' looks like a security or sync component. Disabling it may reduce protection. Continue?",
        ["Start.ConfirmTitle"] = "Confirm startup change",
        ["Start.ConfirmBody"] = "{0} startup item '{1}'?\n\nLocation: {2}",

        ["Ana.Title"] = "Smart Error Analyzer",
        ["Ana.Note"] = "Paste an error message or code. The analyzer matches documented Windows errors and explains them in simple words.",
        ["Ana.Placeholder"] = "Paste error text or code, e.g. 0x80070005...",
        ["Ana.Analyze"] = "Analyze",
        ["Ana.Problem"] = "Problem",
        ["Ana.Severity"] = "Severity",
        ["Ana.Cause"] = "Likely cause",
        ["Ana.Explain"] = "In simple words",
        ["Ana.Solutions"] = "Solutions (easiest first)",
        ["Ana.Undo"] = "Undo",
        ["Ana.Admin"] = "Needs Administrator",
        ["Ana.NoMatch"] = "No confident match - the steps below gather better evidence.",
        ["Ana.Sev.Low"] = "Low",
        ["Ana.Sev.Medium"] = "Medium",
        ["Ana.Sev.High"] = "High",
        ["Ana.Sev.Critical"] = "Critical",

        ["Net.Title"] = "Network diagnostics",
        ["Net.Run"] = "Run checks",
        ["Net.Connected"] = "Internet connectivity: OK",
        ["Net.NoConnectivity"] = "Internet connectivity: FAILED",
        ["Net.Findings"] = "Findings",
        ["Net.Adapters"] = "Adapters",

        ["Drv.Title"] = "Device drivers",
        ["Drv.Problems"] = "device(s) with errors",
        ["Drv.OpenDevMgr"] = "Open Device Manager",
        ["Drv.VendorSite"] = "Official vendor page",
        ["Drv.Note"] = "ABOD FIX never downloads or installs drivers. Use only the official vendor pages linked here.",

        ["Ai.Title"] = "AI Technician",
        ["Ai.Endpoint"] = "API endpoint",
        ["Ai.Model"] = "Model",
        ["Ai.Key"] = "API key",
        ["Ai.KeySet"] = "Key saved (encrypted)",
        ["Ai.KeyMissing"] = "No key saved",
        ["Ai.Save"] = "Save settings",
        ["Ai.SaveKey"] = "Save key",
        ["Ai.NeedsKey"] = "Save an API key first. It is stored encrypted on your device only.",
        ["Ai.Note"] = "Your key is stored encrypted with Windows DPAPI (per-user). It never leaves your device except to the API endpoint you set.",
        ["Ai.Placeholder"] = "Ask about a Windows problem...",
        ["Ai.Send"] = "Send",
        ["Common.Yes"] = "Yes",
        ["Common.No"] = "No",
        ["Common.Ok"] = "OK",
        ["Common.Cancel"] = "Cancel",
        ["Common.Error"] = "Error",
        ["Common.Save"] = "Save",
    };

    private static readonly Dictionary<string, string> Ar = new()
    {
        ["App.Title"] = "ABOD FIX",
        ["App.Subtitle"] = "مساعد تشخيص وإصلاح ويندوز الاحترافي",
        ["App.ReadOnly"] = "وضع القراءة فقط",
        ["Nav.Dashboard"] = "لوحة التحكم",
        ["Nav.Processes"] = "العمليات",
        ["Nav.Disks"] = "صحة الأقراص",
        ["Nav.Reports"] = "التقارير",
        ["Nav.History"] = "السجل",
        ["Nav.Settings"] = "الإعدادات",

        ["Dash.Cpu"] = "المعالج",
        ["Dash.Ram"] = "الذاكرة (RAM)",
        ["Dash.Gpu"] = "كارت الشاشة",
        ["Dash.Disks"] = "التخزين",
        ["Dash.Uptime"] = "مدة التشغيل",
        ["Dash.Network"] = "الشبكة",
        ["Dash.CpuTemp"] = "حرارة المعالج",
        ["Dash.GpuUsage"] = "استهلاك كارت الشاشة",
        ["Dash.Connected"] = "متصل",
        ["Dash.Disconnected"] = "غير متصل",
        ["Dash.NotSupported"] = "غير مدعوم من هذا الجهاز",
        ["Dash.Loading"] = "جاري قراءة بيانات الجهاز الحقيقية...",
        ["Dash.UsageHistory"] = "سجل الاستهلاك (آخر 60 ثانية)",
        ["Dash.Free"] = "متاح",
        ["Dash.Of"] = "من",
        ["Dash.OsInfo"] = "نظام التشغيل",

        ["Proc.Search"] = "ابحث في العمليات...",
        ["Proc.Name"] = "العملية",
        ["Proc.Pid"] = "PID",
        ["Proc.Cpu"] = "المعالج %",
        ["Proc.Memory"] = "الذاكرة",
        ["Proc.Company"] = "الشركة",
        ["Proc.Protected"] = "عملية نظام محمية",
        ["Proc.Kill"] = "إنهاء العملية",
        ["Proc.KillConfirmTitle"] = "تأكيد إنهاء العملية",
        ["Proc.KillConfirm"] = "هل تريد إنهاء العملية '{0}' (PID {1})؟\n\nأي عمل غير محفوظ في هذا البرنامج سيضيع.",
        ["Proc.Refresh"] = "تحديث",
        ["Proc.Count"] = "عملية",

        ["Disk.Title"] = "الأقراص الفعلية",
        ["Disk.Volumes"] = "وحدات التخزين",
        ["Disk.Model"] = "الموديل",
        ["Disk.Interface"] = "الواجهة",
        ["Disk.Size"] = "الحجم",
        ["Disk.Smart"] = "حالة SMART",
        ["Disk.SmartOk"] = "لا يوجد عطل متوقع",
        ["Disk.SmartBad"] = "عطل متوقع - انسخ بياناتك فوراً",
        ["Disk.SmartUnknown"] = "غير معروف - الجهاز لم يبلغ عن الحالة",
        ["Disk.Note"] = "SMART مؤشر واحد فقط. نتيجة 'لا يوجد عطل متوقع' لا تضمن أن القرص سليم تماماً.",
        ["Disk.Used"] = "مستخدم",

        ["Rep.Title"] = "إنشاء تقرير",
        ["Rep.Subtitle"] = "التقارير تحتوي على بيانات حقيقية مقاسة من هذا الجهاز فقط.",
        ["Rep.System"] = "تقرير مواصفات الجهاز",
        ["Rep.Format"] = "الصيغة",
        ["Rep.Generate"] = "إنشاء التقرير",
        ["Rep.Generating"] = "جاري جمع البيانات وإنشاء التقرير...",
        ["Rep.Done"] = "تم حفظ التقرير:",
        ["Rep.Failed"] = "فشل إنشاء التقرير:",

        ["Hist.Title"] = "سجل النشاط",
        ["Hist.Empty"] = "لا يوجد نشاط مسجل بعد.",
        ["Hist.Kind.Scan"] = "فحص",
        ["Hist.Kind.Repair"] = "إصلاح",
        ["Hist.Kind.Info"] = "معلومة",
        ["Hist.Kind.Warning"] = "تحذير",
        ["Hist.Kind.Error"] = "خطأ",

        ["Set.Language"] = "اللغة",
        ["Set.Language.Ar"] = "العربية",
        ["Set.Language.En"] = "English",
        ["Set.Mode"] = "وضع الأمان",
        ["Set.Mode.ReadOnly"] = "قراءة فقط (تشخيص فقط، لا يتم تغيير أي شيء في النظام)",
        ["Set.Mode.Note"] = "عمليات الإصلاح (المرحلة الثانية) ستطلب موافقتك دائماً وستعرض الأوامر الفعلية قبل تشغيلها.",
        ["Set.About"] = "حول البرنامج",
        ["Set.AboutText"] = "ABOD FIX يقرأ بيانات حقيقية من ويندوز (WMI وعدادات الأداء وسجل الأحداث). لا يعرض أرقاماً وهمية أبداً. إذا كان المستشعر غير مدعوم في جهازك، يوضح البرنامج ذلك بدلاً من عرض رقم مزيف.",

        ["Nav.Diagnostics"] = "التشخيص",
        ["Nav.Repair"] = "مركز الإصلاح",
        ["Nav.Startup"] = "برامج البدء",
        ["Nav.Analyzer"] = "محلل الأخطاء",
        ["Nav.Network"] = "الشبكة",
        ["Nav.Drivers"] = "التعريفات",
        ["Nav.Ai"] = "المساعد الذكي",

        ["Diag.Title"] = "تشخيص ويندوز",
        ["Diag.Run"] = "تشغيل الفحص الكامل",
        ["Diag.Running"] = "جاري الفحص...",
        ["Diag.AllGood"] = "كل الفحوصات سليمة.",
        ["Diag.IssuesFound"] = "{0} فحص يحتاج انتباهك.",
        ["Diag.Status.Passed"] = "سليم",
        ["Diag.Status.Warning"] = "تحذير",
        ["Diag.Status.Failed"] = "فشل",
        ["Diag.Status.Running"] = "جاري...",
        ["Diag.Status.Pending"] = "منتظر",

        ["Rep2.Title"] = "مركز الإصلاح الذكي",
        ["Rep2.Note"] = "كل عملية تعرض بالضبط ما ستفعله وتنتظر تأكيدك. وكل شيء يُسجَّل.",
        ["Rep2.Commands"] = "الأوامر التي سيتم تنفيذها:",
        ["Rep2.Risks"] = "المخاطر:",
        ["Rep2.Undo"] = "التراجع:",
        ["Rep2.Admin"] = "يحتاج صلاحيات المسؤول",
        ["Rep2.Execute"] = "تنفيذ الإصلاح",
        ["Rep2.Preview"] = "معاينة الملفات",
        ["Rep2.ConfirmTitle"] = "تأكيد الإصلاح",
        ["Rep2.ConfirmBody"] = "{0}\n\nالأوامر:\n{1}\n\nالمخاطر:\n{2}\n\nالتراجع: {3}\n\nهل تريد المتابعة؟",
        ["Rep2.CleanupConfirmTitle"] = "تأكيد تنظيف الملفات المؤقتة",
        ["Rep2.CleanupConfirmBody"] = "حذف {0} ملف مؤقت بإجمالي {1}؟ الملفات المستخدمة تُتخطى. لا يمكن التراجع.",
        ["Rep2.Log"] = "سجل العملية",

        ["Start.Title"] = "برامج بدء التشغيل",
        ["Start.Note"] = "التعطيل ينقل العنصر إلى نسخة احتياطية آمنة داخل ABOD FIX - لا يُحذف شيء، ويمكن إعادة التفعيل في أي وقت.",
        ["Start.Enabled"] = "مفعّل",
        ["Start.Disabled"] = "معطّل",
        ["Start.ToggleOn"] = "تعطيل",
        ["Start.ToggleOff"] = "تفعيل",
        ["Start.Important"] = "يبدو مهماً",
        ["Start.WarnImportantTitle"] = "هذا العنصر يبدو مهماً",
        ["Start.WarnImportantBody"] = "'{0}' يبدو مكون حماية أو مزامنة. تعطيله قد يقلل الحماية. هل تريد المتابعة؟",
        ["Start.ConfirmTitle"] = "تأكيد تغيير بدء التشغيل",
        ["Start.ConfirmBody"] = "{0} عنصر البدء '{1}'؟\n\nالمكان: {2}",

        ["Ana.Title"] = "محلل الأخطاء الذكي",
        ["Ana.Note"] = "الصق نص الخطأ أو الكود. المحلل يطابق أخطاء ويندوز الموثقة ويشرحها بلغة بسيطة.",
        ["Ana.Placeholder"] = "الصق نص الخطأ أو الكود، مثال: 0x80070005...",
        ["Ana.Analyze"] = "تحليل",
        ["Ana.Problem"] = "المشكلة",
        ["Ana.Severity"] = "الخطورة",
        ["Ana.Cause"] = "السبب المحتمل",
        ["Ana.Explain"] = "بلغة بسيطة",
        ["Ana.Solutions"] = "الحلول (من الأسهل للأصعب)",
        ["Ana.Undo"] = "التراجع",
        ["Ana.Admin"] = "يحتاج صلاحيات المسؤول",
        ["Ana.NoMatch"] = "لا يوجد تطابق مؤكد - الخطوات التالية تجمع أدلة أفضل.",
        ["Ana.Sev.Low"] = "منخفضة",
        ["Ana.Sev.Medium"] = "متوسطة",
        ["Ana.Sev.High"] = "عالية",
        ["Ana.Sev.Critical"] = "حرجة",

        ["Net.Title"] = "تشخيص الشبكة",
        ["Net.Run"] = "تشغيل الفحوصات",
        ["Net.Connected"] = "الاتصال بالإنترنت: يعمل",
        ["Net.NoConnectivity"] = "الاتصال بالإنترنت: فشل",
        ["Net.Findings"] = "النتائج",
        ["Net.Adapters"] = "المحوّلات",

        ["Drv.Title"] = "تعريفات الأجهزة",
        ["Drv.Problems"] = "جهاز به أخطاء",
        ["Drv.OpenDevMgr"] = "فتح إدارة الأجهزة",
        ["Drv.VendorSite"] = "صفحة الشركة الرسمية",
        ["Drv.Note"] = "ABOD FIX لا يحمّل ولا يثبّت تعريفات أبداً. استخدم صفحات الشركات الرسمية الموجودة هنا فقط.",

        ["Ai.Title"] = "المساعد الذكي",
        ["Ai.Endpoint"] = "عنوان الـ API",
        ["Ai.Model"] = "النموذج",
        ["Ai.Key"] = "مفتاح API",
        ["Ai.KeySet"] = "المفتاح محفوظ (مشفر)",
        ["Ai.KeyMissing"] = "لا يوجد مفتاح",
        ["Ai.Save"] = "حفظ الإعدادات",
        ["Ai.SaveKey"] = "حفظ المفتاح",
        ["Ai.NeedsKey"] = "احفظ مفتاح API أولاً. يُحفظ مشفراً على جهازك فقط.",
        ["Ai.Note"] = "مفتاحك محفوظ مشفراً بـ Windows DPAPI (لكل مستخدم). لا يغادر جهازك إلا إلى عنوان الـ API الذي تحدده.",
        ["Ai.Placeholder"] = "اسأل عن مشكلة في ويندوز...",
        ["Ai.Send"] = "إرسال",
        ["Common.Yes"] = "نعم",
        ["Common.No"] = "لا",
        ["Common.Ok"] = "حسناً",
        ["Common.Cancel"] = "إلغاء",
        ["Common.Error"] = "خطأ",
        ["Common.Save"] = "حفظ",
    };
}

/// <summary>Shortcut for XAML: Source={x:Static loc:Loc.Manager}</summary>
public static class Loc
{
    public static LocalizationManager Manager => LocalizationManager.Instance;
}
