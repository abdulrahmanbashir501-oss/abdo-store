using System.Windows.Controls;

namespace AbodFix.App.Views;

public partial class ProcessesView : UserControl
{
    public ProcessesView() => InitializeComponent();
}
