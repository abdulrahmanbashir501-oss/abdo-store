using System.Windows.Controls;

namespace AbodFix.App.Views;

public partial class DashboardView : UserControl
{
    public DashboardView() => InitializeComponent();
}
