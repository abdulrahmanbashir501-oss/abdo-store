using System.Windows.Controls;

namespace AbodFix.App.Views;

public partial class RepairView : UserControl
{
    public RepairView() => InitializeComponent();
}
