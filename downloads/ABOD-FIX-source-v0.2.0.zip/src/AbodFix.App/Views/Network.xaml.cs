using System.Windows.Controls;

namespace AbodFix.App.Views;

public partial class NetworkView : UserControl
{
    public NetworkView() => InitializeComponent();
}
