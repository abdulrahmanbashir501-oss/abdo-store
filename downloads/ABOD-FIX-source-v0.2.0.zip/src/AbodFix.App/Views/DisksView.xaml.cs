using System.Windows.Controls;

namespace AbodFix.App.Views;

public partial class DisksView : UserControl
{
    public DisksView() => InitializeComponent();
}
