using System.Windows.Controls;

namespace AbodFix.App.Views;

public partial class DiagnosticsView : UserControl
{
    public DiagnosticsView() => InitializeComponent();
}
