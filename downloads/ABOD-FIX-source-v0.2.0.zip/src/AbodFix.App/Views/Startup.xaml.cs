using System.Windows.Controls;

namespace AbodFix.App.Views;

public partial class StartupView : UserControl
{
    public StartupView() => InitializeComponent();
}
