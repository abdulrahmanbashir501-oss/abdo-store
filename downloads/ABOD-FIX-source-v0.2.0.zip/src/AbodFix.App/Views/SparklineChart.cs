using System.Collections;
using System.Collections.Specialized;
using System.Windows;
using System.Windows.Media;
using System.Windows.Controls;
using System.Windows.Shapes;

namespace AbodFix.App.Views;

/// <summary>
/// Minimal live line chart (0-100 scale) with soft fill. Draws real data points only,
/// no animation tricks. Used for CPU/RAM history on the dashboard.
/// </summary>
public sealed class SparklineChart : FrameworkElement
{
    private readonly Polyline _line = new();
    private readonly Polygon _fill = new();
    private readonly Canvas _canvas = new();

    public SparklineChart()
    {
        _canvas.ClipToBounds = true;
        AddVisualChild(_canvas);
        AddLogicalChild(_canvas);
        _canvas.Children.Add(_fill);
        _canvas.Children.Add(_line);
        SizeChanged += (_, _) => Redraw();
    }

    protected override int VisualChildrenCount => 1;
    protected override Visual GetVisualChild(int index) => _canvas;
    protected override Size MeasureOverride(Size availableSize)
    {
        _canvas.Measure(availableSize);
        return availableSize;
    }
    protected override Size ArrangeOverride(Size finalSize)
    {
        _canvas.Arrange(new Rect(finalSize));
        return finalSize;
    }

    public static readonly DependencyProperty PointsProperty = DependencyProperty.Register(
        nameof(Points), typeof(IList), typeof(SparklineChart),
        new FrameworkPropertyMetadata(null, OnPointsChanged));

    public IList? Points
    {
        get => (IList?)GetValue(PointsProperty);
        set => SetValue(PointsProperty, value);
    }

    public static readonly DependencyProperty StrokeProperty = DependencyProperty.Register(
        nameof(Stroke), typeof(Brush), typeof(SparklineChart),
        new FrameworkPropertyMetadata(Brushes.Red, FrameworkPropertyMetadataOptions.AffectsRender, OnStyleChanged));

    public Brush Stroke
    {
        get => (Brush)GetValue(StrokeProperty);
        set => SetValue(StrokeProperty, value);
    }

    private static void OnStyleChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        => ((SparklineChart)d).ApplyStyle();

    private static void OnPointsChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
    {
        var c = (SparklineChart)d;
        if (e.OldValue is INotifyCollectionChanged oldC) oldC.CollectionChanged -= c.OnCollectionChanged;
        if (e.NewValue is INotifyCollectionChanged newC) newC.CollectionChanged += c.OnCollectionChanged;
        c.Redraw();
    }

    private void OnCollectionChanged(object? sender, NotifyCollectionChangedEventArgs e) => Redraw();

    private void ApplyStyle()
    {
        _line.Stroke = Stroke;
        _line.StrokeThickness = 2;
        _line.StrokeLineJoin = PenLineJoin.Round;
        if (Stroke is SolidColorBrush scb)
        {
            var c = scb.Color;
            _fill.Fill = new LinearGradientBrush(
                Color.FromArgb(60, c.R, c.G, c.B),
                Color.FromArgb(0, c.R, c.G, c.B), 90);
        }
    }

    private void Redraw()
    {
        ApplyStyle();
        var w = ActualWidth;
        var h = ActualHeight;
        if (w <= 0 || h <= 0 || Points is not { Count: > 1 } pts)
        {
            _line.Points = new PointCollection();
            _fill.Points = new PointCollection();
            return;
        }

        var n = pts.Count;
        var line = new PointCollection(n);
        for (var i = 0; i < n; i++)
        {
            var v = pts[i] is double d ? d : 0;
            v = Math.Clamp(v, 0, 100);
            line.Add(new Point(i * w / (n - 1), h - v / 100.0 * (h - 4) - 2));
        }
        _line.Points = line;

        var fill = new PointCollection(line) { new Point(w, h), new Point(0, h) };
        _fill.Points = fill;
    }
}
