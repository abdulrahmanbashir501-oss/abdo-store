using System.Windows.Controls;

namespace AbodFix.App.Views;

public partial class SettingsView : UserControl
{
    public SettingsView() => InitializeComponent();
}
