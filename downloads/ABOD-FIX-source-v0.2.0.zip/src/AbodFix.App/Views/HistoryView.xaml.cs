using System.Windows.Controls;

namespace AbodFix.App.Views;

public partial class HistoryView : UserControl
{
    public HistoryView() => InitializeComponent();
}
