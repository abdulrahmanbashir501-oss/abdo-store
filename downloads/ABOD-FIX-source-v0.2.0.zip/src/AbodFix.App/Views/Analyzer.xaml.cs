using System.Windows.Controls;

namespace AbodFix.App.Views;

public partial class AnalyzerView : UserControl
{
    public AnalyzerView() => InitializeComponent();
}
