using System.Windows.Controls;

namespace AbodFix.App.Views;

public partial class ReportsView : UserControl
{
    public ReportsView() => InitializeComponent();
}
