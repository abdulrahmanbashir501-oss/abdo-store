using System.Windows.Controls;

namespace AbodFix.App.Views;

public partial class DriversView : UserControl
{
    public DriversView() => InitializeComponent();
}
