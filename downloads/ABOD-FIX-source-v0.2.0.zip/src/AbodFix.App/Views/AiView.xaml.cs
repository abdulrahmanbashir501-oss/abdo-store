using System.Windows.Controls;
using System.Windows.Input;
using AbodFix.App.ViewModels;

namespace AbodFix.App.Views;

public partial class AiView : UserControl
{
    public AiView() => InitializeComponent();

    private AiViewModel? Vm => DataContext as AiViewModel;

    private void SaveKey_Click(object sender, System.Windows.RoutedEventArgs e)
    {
        Vm?.SetApiKey(KeyBox.Password);
        KeyBox.Clear();
    }

    private void Input_KeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.Enter && Vm?.SendCommand.CanExecute(null) == true)
        {
            Vm.SendCommand.Execute(null);
            e.Handled = true;
        }
    }
}
