using System.Globalization;
using System.Windows;
using System.Windows.Data;
using AbodFix.Core.Models;
using AbodFix.Core.Reports;

namespace AbodFix.App;

public sealed class ByteSizeConverter : IValueConverter
{
    public static ByteSizeConverter Instance { get; } = new();
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        => value is long b ? TxtReportExporter.FormatBytes(b) : "--";
    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        => Binding.DoNothing;
}

public sealed class SmartStatusTextConverter : IValueConverter
{
    public static SmartStatusTextConverter Instance { get; } = new();
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
    {
        var loc = Localization.LocalizationManager.Instance;
        return value is SmartStatus s ? s switch
        {
            SmartStatus.NoFailurePredicted => loc["Disk.SmartOk"],
            SmartStatus.FailurePredicted => loc["Disk.SmartBad"],
            _ => loc["Disk.SmartUnknown"]
        } : "--";
    }
    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        => Binding.DoNothing;
}

public sealed class SmartStatusBrushConverter : IValueConverter
{
    public static SmartStatusBrushConverter Instance { get; } = new();
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
    {
        var app = Application.Current;
        return value is SmartStatus s ? s switch
        {
            SmartStatus.NoFailurePredicted => new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(0x2E, 0xC2, 0x7D)),
            SmartStatus.FailurePredicted => app.Resources["AccentBrush"],
            _ => app.Resources["TextDimBrush"]
        } : app.Resources["TextDimBrush"];
    }
    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        => Binding.DoNothing;
}

public sealed class InvertBoolConverter : IValueConverter
{
    public static InvertBoolConverter Instance { get; } = new();
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        => value is bool b ? !b : true;
    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        => Binding.DoNothing;
}

public sealed class ProtectedTooltipConverter : IValueConverter
{
    public static ProtectedTooltipConverter Instance { get; } = new();
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        => value is bool b && b
            ? Localization.LocalizationManager.Instance["Proc.Protected"]
            : Localization.LocalizationManager.Instance["Proc.Kill"];
    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        => Binding.DoNothing;
}

public sealed class StatusBrushConverter : IValueConverter
{
    public static StatusBrushConverter Instance { get; } = new();
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        => value is bool b && b
            ? Application.Current.Resources["AccentBrush"]
            : new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(0x2E, 0xC2, 0x7D));
    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        => Binding.DoNothing;
}

public sealed class CheckStatusTextConverter : IValueConverter
{
    public static CheckStatusTextConverter Instance { get; } = new();
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
    {
        var loc = Localization.LocalizationManager.Instance;
        return value is Core.Models.CheckStatus s ? loc[$"Diag.Status.{s}"] : "";
    }
    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) => Binding.DoNothing;
}

public sealed class CheckStatusBrushConverter : IValueConverter
{
    public static CheckStatusBrushConverter Instance { get; } = new();
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        => value is Core.Models.CheckStatus s ? s switch
        {
            Core.Models.CheckStatus.Passed => new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(0x2E, 0xC2, 0x7D)),
            Core.Models.CheckStatus.Warning => new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(0xE8, 0xA0, 0x2D)),
            Core.Models.CheckStatus.Failed => Application.Current.Resources["AccentBrush"],
            _ => Application.Current.Resources["TextDimBrush"]
        } : Application.Current.Resources["TextDimBrush"];
    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) => Binding.DoNothing;
}

/// <summary>Picks the EN or AR member of a diagnostic check by the current language. Parameter: title|summary.</summary>
public sealed class DiagnosticTextConverter : IValueConverter
{
    public static DiagnosticTextConverter Instance { get; } = new();
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
    {
        if (value is not Core.Models.DiagnosticCheck c) return "";
        var ar = Localization.LocalizationManager.Instance.IsArabic;
        return parameter as string == "summary"
            ? (ar ? c.SummaryAr ?? c.Summary ?? "" : c.Summary ?? c.SummaryAr ?? "")
            : (ar ? c.TitleAr : c.Title);
    }
    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) => Binding.DoNothing;
}

public sealed class SeverityTextConverter : IValueConverter
{
    public static SeverityTextConverter Instance { get; } = new();
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        => value is Core.Analyzer.ErrorSeverity s ? Localization.LocalizationManager.Instance[$"Ana.Sev.{s}"] : "";
    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) => Binding.DoNothing;
}

public sealed class BoolToVisibilityConverter : IValueConverter
{
    public static BoolToVisibilityConverter Instance { get; } = new();
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        => value is bool b && b ? Visibility.Visible : Visibility.Collapsed;
    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) => Binding.DoNothing;
}

public sealed class NullToVisibilityConverter : IValueConverter
{
    public static NullToVisibilityConverter Instance { get; } = new();
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        => value is null ? Visibility.Collapsed : Visibility.Visible;
    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) => Binding.DoNothing;
}

public sealed class ToggleTextConverter : IValueConverter
{
    public static ToggleTextConverter Instance { get; } = new();
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
    {
        var loc = Localization.LocalizationManager.Instance;
        return value is bool b && b ? loc["Start.ToggleOn"] : loc["Start.ToggleOff"];
    }
    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) => Binding.DoNothing;
}

public sealed class ImportantMarkConverter : IValueConverter
{
    public static ImportantMarkConverter Instance { get; } = new();
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        => value is bool b && b ? $" ({Localization.LocalizationManager.Instance["Start.Important"]})" : "";
    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) => Binding.DoNothing;
}

public sealed class PositiveIntToVisibilityConverter : IValueConverter
{
    public static PositiveIntToVisibilityConverter Instance { get; } = new();
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        => value is int i && i > 0 ? Visibility.Visible : Visibility.Collapsed;
    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) => Binding.DoNothing;
}

public sealed class AdminMarkConverter : IValueConverter
{
    public static AdminMarkConverter Instance { get; } = new();
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        => value is bool b && b ? $" ({Localization.LocalizationManager.Instance["Ana.Admin"]})" : "";
    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) => Binding.DoNothing;
}

public sealed class PassFailConverter : IValueConverter
{
    public static PassFailConverter Instance { get; } = new();
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        => value is bool b && b ? "OK" : "FAIL";
    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) => Binding.DoNothing;
}

public sealed class PassFailBrushConverter : IValueConverter
{
    public static PassFailBrushConverter Instance { get; } = new();
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        => value is bool b && b
            ? new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(0x2E, 0xC2, 0x7D))
            : Application.Current.Resources["AccentBrush"];
    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) => Binding.DoNothing;
}

public sealed class ProblemCodeConverter : IValueConverter
{
    public static ProblemCodeConverter Instance { get; } = new();
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        => value is int i && i > 0 ? $"Error {i}" : "OK";
    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) => Binding.DoNothing;
}

public sealed class KeyStateConverter : IValueConverter
{
    public static KeyStateConverter Instance { get; } = new();
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
    {
        var loc = Localization.LocalizationManager.Instance;
        return value is bool b && b ? loc["Ai.KeySet"] : loc["Ai.KeyMissing"];
    }
    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) => Binding.DoNothing;
}

public sealed class RoleNameConverter : IValueConverter
{
    public static RoleNameConverter Instance { get; } = new();
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        => (value as string) switch
        {
            "user" => Localization.LocalizationManager.Instance.IsArabic ? "أنت" : "You",
            "assistant" => "AI",
            _ => "ABOD FIX"
        };
    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) => Binding.DoNothing;
}
