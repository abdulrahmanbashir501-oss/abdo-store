using System.Windows;

namespace AbodFix.App;

public partial class MainWindow : Window
{
    public MainWindow() => InitializeComponent();
}
