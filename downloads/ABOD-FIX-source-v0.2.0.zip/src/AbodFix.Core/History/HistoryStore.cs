using AbodFix.Core.Models;
using Microsoft.Data.Sqlite;

namespace AbodFix.Core.History;

/// <summary>
/// Local SQLite store for scan/repair history, detected issues and app settings.
/// The database file lives in the user's local app data folder on a real install.
/// </summary>
public sealed class HistoryStore : IDisposable
{
    private readonly string _connectionString;

    public HistoryStore(string databasePath)
    {
        var dir = Path.GetDirectoryName(Path.GetFullPath(databasePath));
        if (!string.IsNullOrEmpty(dir)) Directory.CreateDirectory(dir);
        _connectionString = new SqliteConnectionStringBuilder { DataSource = databasePath }.ToString();
        Initialize();
    }

    private SqliteConnection Open()
    {
        var con = new SqliteConnection(_connectionString);
        con.Open();
        return con;
    }

    private void Initialize()
    {
        using var con = Open();
        using var cmd = con.CreateCommand();
        cmd.CommandText = """
            CREATE TABLE IF NOT EXISTS history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ts TEXT NOT NULL,
                kind TEXT NOT NULL,
                title TEXT NOT NULL,
                details TEXT,
                result TEXT
            );
            CREATE TABLE IF NOT EXISTS settings (
                key TEXT PRIMARY KEY,
                value TEXT
            );
            """;
        cmd.ExecuteNonQuery();
    }

    public async Task<long> AddEntryAsync(HistoryEntry entry, CancellationToken ct = default)
    {
        await using var con = Open();
        await using var cmd = con.CreateCommand();
        cmd.CommandText = "INSERT INTO history (ts, kind, title, details, result) VALUES ($ts, $kind, $title, $details, $result); SELECT last_insert_rowid();";
        cmd.Parameters.AddWithValue("$ts", entry.Timestamp.ToString("O"));
        cmd.Parameters.AddWithValue("$kind", entry.Kind.ToString());
        cmd.Parameters.AddWithValue("$title", entry.Title);
        cmd.Parameters.AddWithValue("$details", (object?)entry.Details ?? DBNull.Value);
        cmd.Parameters.AddWithValue("$result", (object?)entry.Result ?? DBNull.Value);
        return (long)(await cmd.ExecuteScalarAsync(ct))!;
    }

    public async Task<IReadOnlyList<HistoryEntry>> GetRecentAsync(int limit = 100, CancellationToken ct = default)
    {
        var list = new List<HistoryEntry>();
        await using var con = Open();
        await using var cmd = con.CreateCommand();
        cmd.CommandText = "SELECT id, ts, kind, title, details, result FROM history ORDER BY id DESC LIMIT $limit";
        cmd.Parameters.AddWithValue("$limit", limit);
        await using var reader = await cmd.ExecuteReaderAsync(ct);
        while (await reader.ReadAsync(ct))
        {
            list.Add(new HistoryEntry
            {
                Id = reader.GetInt64(0),
                Timestamp = DateTimeOffset.Parse(reader.GetString(1)),
                Kind = Enum.Parse<HistoryKind>(reader.GetString(2)),
                Title = reader.GetString(3),
                Details = reader.IsDBNull(4) ? null : reader.GetString(4),
                Result = reader.IsDBNull(5) ? null : reader.GetString(5)
            });
        }
        return list;
    }

    public async Task SetSettingAsync(string key, string? value, CancellationToken ct = default)
    {
        await using var con = Open();
        await using var cmd = con.CreateCommand();
        cmd.CommandText = "INSERT INTO settings (key, value) VALUES ($k, $v) ON CONFLICT(key) DO UPDATE SET value = $v";
        cmd.Parameters.AddWithValue("$k", key);
        cmd.Parameters.AddWithValue("$v", (object?)value ?? DBNull.Value);
        await cmd.ExecuteNonQueryAsync(ct);
    }

    public async Task<string?> GetSettingAsync(string key, CancellationToken ct = default)
    {
        await using var con = Open();
        await using var cmd = con.CreateCommand();
        cmd.CommandText = "SELECT value FROM settings WHERE key = $k";
        cmd.Parameters.AddWithValue("$k", key);
        return (string?)await cmd.ExecuteScalarAsync(ct);
    }

    public void Dispose() { }
}
