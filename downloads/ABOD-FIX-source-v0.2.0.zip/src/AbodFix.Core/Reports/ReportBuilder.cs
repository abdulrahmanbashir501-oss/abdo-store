using AbodFix.Core.Contracts;
using AbodFix.Core.Models;

namespace AbodFix.Core.Reports;

/// <summary>Collects data from the monitoring providers into a ReportData.</summary>
public sealed class ReportBuilder(
    ISystemInfoProvider systemInfo,
    IMetricsSampler metrics,
    IProcessProvider processes,
    IDiskHealthProvider diskHealth,
    string appVersion = "")
{
    public async Task<ReportData> BuildAsync(string title, CancellationToken ct = default)
    {
        var hw = await systemInfo.GetHardwareProfileAsync(ct);
        var snap = await metrics.SampleAsync(ct);
        var procs = await processes.ListProcessesAsync(ct);
        var disks = await diskHealth.GetDisksAsync(ct);

        var notes = new List<string>();
        if (snap.CpuTemperatureCelsius is null)
            notes.Add("CPU temperature: this device did not expose a readable sensor (common on many PCs; WMI thermal zone is often unsupported).");
        if (disks.All(d => d.Smart == SmartStatus.Unknown))
            notes.Add("SMART status was not reported by any drive; disk health cannot be confirmed from a single indicator.");

        return new ReportData
        {
            Title = title,
            GeneratedAt = DateTimeOffset.Now,
            MachineName = hw.MachineName,
            AppVersion = appVersion,
            Hardware = hw,
            Snapshot = snap,
            DiskHealth = disks,
            TopProcessesByMemory = procs.Where(p => p.MemoryBytes is not null)
                                        .OrderByDescending(p => p.MemoryBytes).Take(10).ToList(),
            TopProcessesByCpu = procs.Where(p => p.CpuPercent is not null)
                                     .OrderByDescending(p => p.CpuPercent).Take(10).ToList(),
            Notes = notes
        };
    }
}
