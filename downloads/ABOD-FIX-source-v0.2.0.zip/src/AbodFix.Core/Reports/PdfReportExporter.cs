using System.Globalization;
using AbodFix.Core.Models;
using QuestPDF.Fluent;
using QuestPDF.Helpers;
using QuestPDF.Infrastructure;

namespace AbodFix.Core.Reports;

/// <summary>
/// PDF export via QuestPDF (community license - free for individuals and small businesses).
/// Text shaping (Arabic) is handled by HarfBuzz bundled with QuestPDF.
/// </summary>
public sealed class PdfReportExporter : IReportExporter
{
    static PdfReportExporter() => QuestPDF.Settings.License = LicenseType.Community;

    public string Format => "pdf";

    public Task ExportAsync(ReportData data, string filePath, CancellationToken ct = default)
    {
        var dark = Colors.Grey.Darken4;
        var red = Colors.Red.Darken2;

        var doc = Document.Create(container =>
        {
            container.Page(page =>
            {
                page.Size(PageSizes.A4);
                page.Margin(36);
                page.DefaultTextStyle(x => x.FontSize(10));

                page.Header().Row(row =>
                {
                    row.RelativeItem().Column(col =>
                    {
                        col.Item().Text("ABOD FIX").FontSize(20).Bold().FontColor(red);
                        col.Item().Text(data.Title).FontSize(12).FontColor(dark);
                    });
                    row.ConstantItem(170).Column(col =>
                    {
                        col.Item().AlignRight().Text($"Generated: {data.GeneratedAt:yyyy-MM-dd HH:mm}").FontSize(8);
                        col.Item().AlignRight().Text($"Machine: {data.MachineName}").FontSize(8);
                    });
                });

                page.Content().PaddingVertical(12).Column(col =>
                {
                    col.Spacing(10);

                    if (data.Hardware is { } hw)
                    {
                        Section(col, "HARDWARE", red);
                        Line(col, "CPU", $"{hw.Cpu.Name} - {hw.Cpu.PhysicalCores} cores / {hw.Cpu.LogicalProcessors} threads");
                        foreach (var g in hw.Gpus)
                            Line(col, "GPU", g.Name + (g.DriverVersion is string dv ? $" (driver {dv})" : ""));
                        Line(col, "RAM", TxtReportExporter.FormatBytes(hw.TotalRamBytes));
                        Line(col, "OS", $"{hw.Os.Caption} {hw.Os.Version} (build {hw.Os.BuildNumber})");
                    }

                    if (data.Snapshot is { } s)
                    {
                        Section(col, "LIVE METRICS", red);
                        Line(col, "CPU usage", s.CpuUsagePercent is double c ? Pct(c) : "not available");
                        Line(col, "RAM usage", s.RamUsedPercent is double r
                            ? $"{Pct(r)} ({TxtReportExporter.FormatBytes(s.RamUsedBytes)} / {TxtReportExporter.FormatBytes(s.RamTotalBytes)})"
                            : "not available");
                        Line(col, "GPU usage", s.GpuUsagePercent is double g ? Pct(g) : "not available");
                        Line(col, "CPU temperature", s.CpuTemperatureCelsius is double ct ? $"{ct:F1} C" : "sensor not supported by this device");
                        Line(col, "GPU temperature", s.GpuTemperatureCelsius is double gt ? $"{gt:F1} C" : "sensor not supported by this device");
                        Line(col, "Network", s.Network.ToString());
                        if (s.Uptime is TimeSpan up) Line(col, "Uptime", $"{(int)up.TotalDays}d {up.Hours}h {up.Minutes}m");
                        foreach (var d in s.Disks)
                            Line(col, $"Disk {d.Name}", $"{d.UsedPercent:F1}% used, {TxtReportExporter.FormatBytes(d.FreeBytes)} free of {TxtReportExporter.FormatBytes(d.TotalBytes)} [{d.FileSystem ?? "?"}]");
                    }

                    if (data.DiskHealth.Count > 0)
                    {
                        Section(col, "DISK HEALTH (SMART)", red);
                        foreach (var d in data.DiskHealth)
                            Line(col, d.Model, $"{TxtReportExporter.SmartText(d.Smart)}");
                    }

                    if (data.TopProcessesByMemory.Count > 0)
                    {
                        Section(col, "TOP PROCESSES BY MEMORY", red);
                        foreach (var p in data.TopProcessesByMemory.Take(10))
                            Line(col, $"{p.Name} (PID {p.Pid})", TxtReportExporter.FormatBytes(p.MemoryBytes));
                    }

                    foreach (var n in data.Notes)
                        col.Item().Text($"* {n}").FontSize(8).Italic();
                });

                page.Footer().AlignCenter().Text(t =>
                {
                    t.Span("ABOD FIX - all values are real measurements taken on this machine. Page ").FontSize(8);
                    t.CurrentPageNumber().FontSize(8);
                });
            });
        });

        doc.GeneratePdf(filePath);
        return Task.CompletedTask;

        static string Pct(double v) => v.ToString("F1", CultureInfo.InvariantCulture) + " %";
        static void Section(ColumnDescriptor col, string title, string color) =>
            col.Item().PaddingTop(6).Text(title).FontSize(12).Bold().FontColor(color);
        static void Line(ColumnDescriptor col, string label, string value) =>
            col.Item().Row(r =>
            {
                r.ConstantItem(150).Text(label).SemiBold();
                r.RelativeItem().Text(value);
            });
    }
}
