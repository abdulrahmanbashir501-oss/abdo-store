using System.Text.Json;
using AbodFix.Core.Models;

namespace AbodFix.Core.Reports;

public sealed class JsonReportExporter : IReportExporter
{
    private static readonly JsonSerializerOptions Options = new()
    {
        WriteIndented = true,
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase
    };

    public string Format => "json";

    public async Task ExportAsync(ReportData data, string filePath, CancellationToken ct = default)
    {
        await using var fs = File.Create(filePath);
        await JsonSerializer.SerializeAsync(fs, data, Options, ct);
    }
}
