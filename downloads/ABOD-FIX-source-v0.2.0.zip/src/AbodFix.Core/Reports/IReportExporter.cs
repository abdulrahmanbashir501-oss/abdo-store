using AbodFix.Core.Models;

namespace AbodFix.Core.Reports;

public interface IReportExporter
{
    /// <summary>File extension without dot, e.g. "txt".</summary>
    string Format { get; }
    Task ExportAsync(ReportData data, string filePath, CancellationToken ct = default);
}
