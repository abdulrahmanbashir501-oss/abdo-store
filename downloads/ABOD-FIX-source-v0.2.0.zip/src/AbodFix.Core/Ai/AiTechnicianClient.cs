using System.Net.Http.Json;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace AbodFix.Core.Ai;

public sealed record AiChatMessage(string Role, string Content);

/// <summary>
/// OpenAI-compatible chat endpoint client. Works with OpenAI, Azure OpenAI-style
/// routes, and local servers (Ollama/LM Studio) that expose /v1/chat/completions.
/// The API key is supplied by the caller from secure storage - it is never
/// written to app files by this client.
/// </summary>
public sealed class AiTechnicianClient
{
    private readonly HttpClient _http;
    private readonly string _endpoint;   // e.g. https://api.openai.com/v1/chat/completions
    private readonly string _model;
    private readonly string _apiKey;

    public AiTechnicianClient(string endpoint, string model, string apiKey, HttpClient? http = null)
    {
        if (string.IsNullOrWhiteSpace(endpoint)) throw new ArgumentException("endpoint required");
        if (string.IsNullOrWhiteSpace(model)) throw new ArgumentException("model required");
        if (string.IsNullOrWhiteSpace(apiKey)) throw new ArgumentException("api key required");
        _endpoint = endpoint;
        _model = model;
        _apiKey = apiKey;
        _http = http ?? new HttpClient { Timeout = TimeSpan.FromSeconds(60) };
    }

    public static string DefaultSystemPrompt(string language) => language == "ar"
        ? "أنت فني صيانة كمبيوتر محترف داخل برنامج ABOD FIX. أجب بالعربية البسيطة. اشرح الأوامر قبل تنفيذها، ولا تقترح أبداً حذف ملفات نظام أو تعديل ريجستري عشوائي أو تحميل تعريفات من مواقع غير رسمية. إذا أعطاك المستخدم بيانات فحص، حللها واقترح خطوات مرتبة من الأسهل للأصعب."
        : "You are a professional PC maintenance technician inside ABOD FIX. Answer in the user's language. Explain commands before running them, and never suggest deleting system files, random registry edits, or downloading drivers from unofficial sites. If the user pastes scan data, analyze it and order fixes from easiest to most advanced.";

    public async Task<string> ChatAsync(IReadOnlyList<AiChatMessage> messages, string systemPrompt, CancellationToken ct = default)
    {
        var payload = new
        {
            model = _model,
            messages = new[] { new { role = "system", content = systemPrompt } }
                .Concat(messages.Select(m => new { role = m.Role, content = m.Content })).ToArray(),
            temperature = 0.3
        };

        using var req = new HttpRequestMessage(HttpMethod.Post, _endpoint);
        req.Headers.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", _apiKey);
        req.Content = new StringContent(JsonSerializer.Serialize(payload), Encoding.UTF8, "application/json");

        using var resp = await _http.SendAsync(req, ct);
        var body = await resp.Content.ReadAsStringAsync(ct);
        if (!resp.IsSuccessStatusCode)
            throw new AiRequestException((int)resp.StatusCode, body);

        using var doc = JsonDocument.Parse(body);
        var content = doc.RootElement
            .GetProperty("choices")[0]
            .GetProperty("message")
            .GetProperty("content")
            .GetString();
        return content ?? "";
    }
}

public sealed class AiRequestException : Exception
{
    public int StatusCode { get; }
    public AiRequestException(int statusCode, string body)
        : base($"AI request failed with HTTP {statusCode}: {(body.Length > 200 ? body[..200] : body)}")
        => StatusCode = statusCode;
}
