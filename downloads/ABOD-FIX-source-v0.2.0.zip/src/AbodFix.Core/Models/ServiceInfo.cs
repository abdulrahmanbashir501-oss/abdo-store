namespace AbodFix.Core.Models;

public sealed record WindowsServiceInfo
{
    public required string Name { get; init; }
    public required string DisplayName { get; init; }
    public required string Status { get; init; }       // Running / Stopped / ...
    public string? StartMode { get; init; }           // Automatic / Manual / Disabled
    public bool IsCritical { get; init; }
    /// <summary>True when an automatic service that should be running is stopped.</summary>
    public bool LooksWrong { get; init; }
}
