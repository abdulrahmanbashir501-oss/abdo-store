namespace AbodFix.Core.Models;

public sealed record DriverInfo
{
    public required string DeviceName { get; init; }
    public string? Manufacturer { get; init; }
    public string? DriverVersion { get; init; }
    public string? DriverDate { get; init; }
    public string? DeviceClass { get; init; }
    public string? Status { get; init; }
    /// <summary>Windows problem code; 0 or null means no reported problem.</summary>
    public int? ProblemCode { get; init; }
    public bool HasProblem => ProblemCode is > 0;
    public string? PnpDeviceId { get; init; }
}
