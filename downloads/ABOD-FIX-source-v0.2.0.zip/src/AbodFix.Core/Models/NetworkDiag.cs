namespace AbodFix.Core.Models;

public sealed record NetworkAdapterInfo
{
    public required string Name { get; init; }
    public string? Description { get; init; }
    public string? Type { get; init; }
    public string? Status { get; init; }
    public long? LinkSpeedBps { get; init; }
    public IReadOnlyList<string> IPv4Addresses { get; init; } = [];
    public string? Gateway { get; init; }
    public IReadOnlyList<string> DnsServers { get; init; } = [];
    public string? Mac { get; init; }
}

public sealed record NetworkCheckResult
{
    public required string Name { get; init; }
    public required bool Passed { get; init; }
    public string? Detail { get; init; }
    public long? LatencyMs { get; init; }
}

public sealed record NetworkDiagnosticsResult
{
    public DateTimeOffset RunAt { get; init; } = DateTimeOffset.Now;
    public bool AnyConnectivity { get; init; }
    public IReadOnlyList<NetworkCheckResult> Checks { get; init; } = [];
    public IReadOnlyList<NetworkAdapterInfo> Adapters { get; init; } = [];
    public IReadOnlyList<string> Findings { get; init; } = [];
}
