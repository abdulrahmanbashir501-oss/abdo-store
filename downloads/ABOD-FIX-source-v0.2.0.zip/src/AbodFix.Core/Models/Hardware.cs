namespace AbodFix.Core.Models;

/// <summary>Static hardware and OS profile. Values come from real system queries (WMI on Windows).</summary>
public sealed record HardwareProfile
{
    public required CpuInfo Cpu { get; init; }
    public required OsInfo Os { get; init; }
    public required long TotalRamBytes { get; init; }
    public IReadOnlyList<GpuInfo> Gpus { get; init; } = [];
    public string? Motherboard { get; init; }
    public string? BiosVersion { get; init; }
    public string MachineName { get; init; } = "";
    public DateTimeOffset CollectedAt { get; init; } = DateTimeOffset.Now;
}

public sealed record CpuInfo
{
    public required string Name { get; init; }
    public required int PhysicalCores { get; init; }
    public required int LogicalProcessors { get; init; }
    public uint? MaxClockMHz { get; init; }
    public string? Manufacturer { get; init; }
    public string? Architecture { get; init; }
}

public sealed record GpuInfo
{
    public required string Name { get; init; }
    public string? Vendor { get; init; }
    /// <summary>Adapter RAM as reported by WMI. Note: Win32_VideoController caps this at 4 GB; treat as approximate.</summary>
    public long? AdapterRamBytes { get; init; }
    public string? DriverVersion { get; init; }
    public string? DriverDate { get; init; }
    public string? VideoModeDescription { get; init; }
}

public sealed record OsInfo
{
    public required string Caption { get; init; }
    public required string Version { get; init; }
    public required string BuildNumber { get; init; }
    public string? Architecture { get; init; }
    public DateTimeOffset? InstallDate { get; init; }
    public DateTimeOffset? LastBootTime { get; init; }
}
