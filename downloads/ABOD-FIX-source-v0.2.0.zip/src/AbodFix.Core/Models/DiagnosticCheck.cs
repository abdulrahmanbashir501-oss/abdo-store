namespace AbodFix.Core.Models;

public enum CheckStatus { Pending, Running, Passed, Warning, Failed, Skipped }

public sealed record DiagnosticCheck
{
    public required string Id { get; init; }
    public required string Title { get; init; }
    public required string TitleAr { get; init; }
    public CheckStatus Status { get; set; } = CheckStatus.Pending;
    public string? Summary { get; set; }
    public string? SummaryAr { get; set; }
    public string? Details { get; set; }
    public TimeSpan? Duration { get; set; }
    /// <summary>Suggested repair operation id when the check can be fixed by one.</summary>
    public string? SuggestedRepairId { get; set; }
}
