namespace AbodFix.Core.Models;

public enum HistoryKind { Info, Scan, Repair, Warning, Error }

public sealed record HistoryEntry
{
    public long Id { get; init; }
    public DateTimeOffset Timestamp { get; init; } = DateTimeOffset.Now;
    public required HistoryKind Kind { get; init; }
    public required string Title { get; init; }
    public string? Details { get; init; }
    public string? Result { get; init; }
}
