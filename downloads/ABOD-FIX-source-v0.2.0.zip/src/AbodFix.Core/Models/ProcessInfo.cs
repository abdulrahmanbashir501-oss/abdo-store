namespace AbodFix.Core.Models;

public sealed record ProcessInfo
{
    public required int Pid { get; init; }
    public required string Name { get; init; }
    public double? CpuPercent { get; init; }
    public long? MemoryBytes { get; init; }
    public string? Company { get; init; }
    /// <summary>Executable path. May be null when access is denied (protected processes).</summary>
    public string? Path { get; init; }
    public bool IsCriticalSystemProcess { get; init; }
}
