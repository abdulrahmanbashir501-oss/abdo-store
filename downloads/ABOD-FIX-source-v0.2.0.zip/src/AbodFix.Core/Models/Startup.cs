namespace AbodFix.Core.Models;

public enum StartupLocation { RegistryRun, RegistryRunOnce, StartupFolder, Task, Unknown }

public sealed record StartupItem
{
    public required string Name { get; init; }
    public string? Command { get; init; }
    public string? Path { get; init; }
    public string? Company { get; init; }
    public required StartupLocation Location { get; init; }
    /// <summary>Where the change applies, e.g. HKCU\...\Run or a file path.</summary>
    public required string SourceKey { get; init; }
    public bool Enabled { get; init; } = true;
    /// <summary>Startup impact as reported by Windows when available: "High", "Medium", "Low", or null.</summary>
    public string? Impact { get; init; }
    /// <summary>True when disabling could remove security or sync functionality the user likely wants.</summary>
    public bool LooksImportant { get; init; }
}

public sealed record StartupChangeResult(bool Success, string Message);
