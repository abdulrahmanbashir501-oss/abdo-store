namespace AbodFix.Core.Models;

public sealed record EventLogIssue
{
    public required string LogName { get; init; }       // Application / System
    public required string Source { get; init; }
    public required string Level { get; init; }          // Error / Warning
    public int? EventId { get; init; }
    public int Count { get; init; }                      // occurrences in the scanned window
    public DateTimeOffset? LastSeen { get; init; }
    public string? SampleMessage { get; init; }
}
