namespace AbodFix.Core.Models;

/// <summary>One point-in-time sample of live system metrics. Every value is measured, never invented.</summary>
public sealed record SystemSnapshot
{
    public DateTimeOffset Timestamp { get; init; } = DateTimeOffset.Now;

    /// <summary>Total CPU usage 0-100, or null when the counter is unavailable.</summary>
    public double? CpuUsagePercent { get; init; }

    public long? RamTotalBytes { get; init; }
    public long? RamAvailableBytes { get; init; }
    public long? RamUsedBytes => RamTotalBytes is long t && RamAvailableBytes is long a ? t - a : null;
    public double? RamUsedPercent => RamTotalBytes is long t2 && t2 > 0 && RamUsedBytes is long u ? u * 100.0 / t2 : null;

    public IReadOnlyList<DiskSample> Disks { get; init; } = [];
    public NetworkStatus Network { get; init; } = NetworkStatus.Unknown;
    public TimeSpan? Uptime { get; init; }

    /// <summary>CPU temperature in Celsius when a real sensor reports it, otherwise null (never fabricated).</summary>
    public double? CpuTemperatureCelsius { get; init; }
    public double? GpuTemperatureCelsius { get; init; }

    /// <summary>GPU utilization 0-100 summed from GPU Engine counters, or null when unsupported.</summary>
    public double? GpuUsagePercent { get; init; }
}

public sealed record DiskSample
{
    public required string Name { get; init; }        // e.g. C:\
    public string? VolumeLabel { get; init; }
    public string? FileSystem { get; init; }
    public string? DriveFormat { get; init; }
    public required long TotalBytes { get; init; }
    public required long FreeBytes { get; init; }
    public long UsedBytes => TotalBytes - FreeBytes;
    public double UsedPercent => TotalBytes > 0 ? UsedBytes * 100.0 / TotalBytes : 0;
}

public enum NetworkStatus { Unknown, Connected, Disconnected }
