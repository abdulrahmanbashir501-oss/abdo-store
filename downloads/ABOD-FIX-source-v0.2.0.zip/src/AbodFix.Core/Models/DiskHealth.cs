namespace AbodFix.Core.Models;

public enum SmartStatus
{
    /// <summary>Device does not expose SMART prediction or query failed. Never presented as "healthy".</summary>
    Unknown,
    /// <summary>SMART failure prediction reports no predicted failure.</summary>
    NoFailurePredicted,
    /// <summary>SMART predicts a possible failure. Back up immediately.</summary>
    FailurePredicted
}

public sealed record DiskHealthInfo
{
    public required string Model { get; init; }
    public string? SerialNumber { get; init; }
    public string? InterfaceType { get; init; }
    public string? MediaType { get; init; }
    public string? DeviceId { get; init; }
    public long? SizeBytes { get; init; }
    public SmartStatus Smart { get; init; } = SmartStatus.Unknown;
    /// <summary>Human readable explanation of how Smart was determined (or why it is Unknown).</summary>
    public string? SmartDetails { get; init; }
    public IReadOnlyList<string> Partitions { get; init; } = [];
}
