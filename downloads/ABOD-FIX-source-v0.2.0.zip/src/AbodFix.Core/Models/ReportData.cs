namespace AbodFix.Core.Models;

/// <summary>All data that goes into a generated report.</summary>
public sealed record ReportData
{
    public required string Title { get; init; }
    public DateTimeOffset GeneratedAt { get; init; } = DateTimeOffset.Now;
    public string MachineName { get; init; } = "";
    public string AppVersion { get; init; } = "";
    public HardwareProfile? Hardware { get; init; }
    public SystemSnapshot? Snapshot { get; init; }
    public IReadOnlyList<DiskHealthInfo> DiskHealth { get; init; } = [];
    public IReadOnlyList<ProcessInfo> TopProcessesByMemory { get; init; } = [];
    public IReadOnlyList<ProcessInfo> TopProcessesByCpu { get; init; } = [];
    /// <summary>Free-form findings and notes. Each note states its source.</summary>
    public IReadOnlyList<string> Notes { get; init; } = [];
}
