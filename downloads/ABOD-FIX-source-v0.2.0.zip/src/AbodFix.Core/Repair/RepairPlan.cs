namespace AbodFix.Core.Repair;

public enum RepairKind { Command, FileCleanup, OpenTool, ServiceRestart }

/// <summary>A fully-described repair operation: what runs, risks, undo. UI must show all of this and get explicit confirmation.</summary>
public sealed record RepairPlan
{
    public required string Id { get; init; }
    public required string Title { get; init; }
    public required string TitleAr { get; init; }
    public required string Description { get; init; }
    public required string DescriptionAr { get; init; }
    public required RepairKind Kind { get; init; }
    /// <summary>Exact command lines that will run (Command kind). Shown verbatim.</summary>
    public IReadOnlyList<string> Commands { get; init; } = [];
    public IReadOnlyList<string> Risks { get; init; } = [];
    public IReadOnlyList<string> RisksAr { get; init; } = [];
    public string? Undo { get; init; }
    public string? UndoAr { get; init; }
    public bool RequiresAdmin { get; init; }
    public string? ExpectedDuration { get; init; }
    public string? ExpectedDurationAr { get; init; }
}

public static class RepairCatalog
{
    public static readonly RepairPlan SfcScan = new()
    {
        Id = "sfc-scan", Title = "Repair system files (SFC)", TitleAr = "إصلاح ملفات النظام (SFC)",
        Description = "Scans protected Windows system files and restores corrupted copies from the component store.",
        DescriptionAr = "يفحص ملفات ويندوز المحمية ويستعيد النسخ التالفة من مخزن المكونات.",
        Kind = RepairKind.Command,
        Commands = ["sfc.exe /scannow"],
        Risks = ["Takes 5-15 minutes.", "Needs Administrator rights."],
        RisksAr = ["يستغرق 5-15 دقيقة.", "يحتاج صلاحيات المسؤول."],
        Undo = "Nothing to undo: SFC only restores original Microsoft files.",
        UndoAr = "لا يوجد تراجع: SFC يستعيد ملفات مايكروسوفت الأصلية فقط.",
        RequiresAdmin = true, ExpectedDuration = "5-15 min", ExpectedDurationAr = "5-15 دقيقة"
    };

    public static readonly RepairPlan DismRestoreHealth = new()
    {
        Id = "dism-restorehealth", Title = "Repair Windows image (DISM)", TitleAr = "إصلاح صورة ويندوز (DISM)",
        Description = "Repairs the system image SFC relies on, using Windows Update as source.",
        DescriptionAr = "يصلح صورة النظام التي يعتمد عليها SFC، باستخدام Windows Update كمصدر.",
        Kind = RepairKind.Command,
        Commands = ["DISM.exe /Online /Cleanup-Image /RestoreHealth"],
        Risks = ["Takes 10-30 minutes.", "Needs internet and Administrator rights."],
        RisksAr = ["يستغرق 10-30 دقيقة.", "يحتاج إنترنت وصلاحيات المسؤول."],
        RequiresAdmin = true, ExpectedDuration = "10-30 min", ExpectedDurationAr = "10-30 دقيقة"
    };

    public static readonly RepairPlan TempCleanup = new()
    {
        Id = "temp-cleanup", Title = "Clean temporary files", TitleAr = "تنظيف الملفات المؤقتة",
        Description = "Deletes temp files in safe, known locations only. You review the full list with sizes before anything is deleted. Files in use are skipped.",
        DescriptionAr = "يحذف الملفات المؤقتة من أماكن آمنة ومعروفة فقط. تراجع القائمة الكاملة بالأحجام قبل أي حذف. الملفات المستخدمة تُتخطى.",
        Kind = RepairKind.FileCleanup,
        Risks = ["Programs may recreate these files; no personal files are touched."],
        RisksAr = ["البرامج قد تعيد إنشاء هذه الملفات؛ لا يتم لمس أي ملفات شخصية."],
        Undo = "Temp files cannot be restored after deletion; that is why you review the preview first.",
        UndoAr = "الملفات المؤقتة لا تُستعاد بعد الحذف؛ لذلك تراجع المعاينة أولاً."
    };

    public static readonly RepairPlan IpRenew = new()
    {
        Id = "ip-renew", Title = "Renew IP address", TitleAr = "تجديد عنوان IP",
        Description = "Releases and renews the DHCP address of your network adapters.",
        DescriptionAr = "يحرر ويجدد عنوان DHCP لمحوّلات الشبكة.",
        Kind = RepairKind.Command,
        Commands = ["ipconfig.exe /release", "ipconfig.exe /renew"],
        Risks = ["Connection drops for a few seconds."],
        RisksAr = ["ينقطع الاتصال لثوانٍ معدودة."],
        Undo = "Renew again or reconnect the adapter.",
        UndoAr = "جدّد مجدداً أو أعد توصيل المحوّل."
    };

    public static readonly RepairPlan FlushDns = new()
    {
        Id = "flush-dns", Title = "Flush DNS cache", TitleAr = "مسح ذاكرة DNS",
        Description = "Clears the local DNS resolver cache so fresh answers are fetched.",
        DescriptionAr = "يمسح ذاكرة DNS المحلية ليتم جلب إجابات جديدة.",
        Kind = RepairKind.Command,
        Commands = ["ipconfig.exe /flushdns"],
        Risks = ["First site visit after flushing may be slightly slower."],
        RisksAr = ["أول زيارة لكل موقع بعد المسح قد تكون أبطأ قليلاً."]
    };

    public static readonly RepairPlan OpenTroubleshooters = new()
    {
        Id = "open-troubleshooters", Title = "Open Windows troubleshooters", TitleAr = "فتح أدوات استكشاف أخطاء ويندوز",
        Description = "Opens the official Windows troubleshooters page. Nothing runs without your choice there.",
        DescriptionAr = "يفتح صفحة أدوات استكشاف الأخطاء الرسمية في ويندوز. لا يعمل شيء دون اختيارك هناك.",
        Kind = RepairKind.OpenTool,
        Commands = ["ms-settings:troubleshoot"]
    };

    public static readonly RepairPlan ServicesRestart = new()
    {
        Id = "services-restart", Title = "Restart stopped important services", TitleAr = "إعادة تشغيل الخدمات المهمة المتوقفة",
        Description = "Restarts automatic Windows services found stopped (never security-critical ones, and you confirm each).",
        DescriptionAr = "يعيد تشغيل خدمات ويندوز التلقائية المتوقفة (وليس الحساسة أمنياً أبداً، وبعد تأكيدك لكل واحدة).",
        Kind = RepairKind.ServiceRestart,
        Risks = ["Dependent features pause briefly.", "Needs Administrator rights for some services."],
        RisksAr = ["الميزات التابعة تتوقف لحظياً.", "بعض الخدمات يحتاج صلاحيات المسؤول."]
    };

    public static IReadOnlyList<RepairPlan> All { get; } =
        [SfcScan, DismRestoreHealth, TempCleanup, IpRenew, FlushDns, OpenTroubleshooters, ServicesRestart];

    public static RepairPlan? Find(string? id) => All.FirstOrDefault(p => p.Id == id);
}
