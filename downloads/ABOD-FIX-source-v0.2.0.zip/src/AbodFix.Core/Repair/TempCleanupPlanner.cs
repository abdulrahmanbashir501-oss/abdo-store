namespace AbodFix.Core.Repair;

/// <summary>One deletable item in the preview.</summary>
public sealed record CleanupItem(string Path, long SizeBytes);

public sealed record CleanupPreview(IReadOnlyList<CleanupItem> Items, long TotalBytes, int SkippedLocked);

/// <summary>
/// Builds the temp-cleanup preview. Locations are an explicit safe allowlist -
/// user temp folder and Windows temp folder only. Never touches personal files,
/// never wildcards outside the allowlist.
/// </summary>
public static class TempCleanupPlanner
{
    public static IReadOnlyList<string> SafeRoots()
    {
        var roots = new List<string>();
        var userTemp = Path.GetTempPath(); // %LOCALAPPDATA%\Temp on Windows
        if (!string.IsNullOrWhiteSpace(userTemp)) roots.Add(userTemp);
        var winTemp = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows), "Temp");
        roots.Add(winTemp);
        return roots;
    }

    public static CleanupPreview BuildPreview(IEnumerable<string>? roots = null)
    {
        var items = new List<CleanupItem>();
        foreach (var root in (roots ?? SafeRoots()).Distinct())
        {
            if (!Directory.Exists(root)) continue;
            IEnumerable<string> files;
            try { files = Directory.EnumerateFiles(root, "*", new EnumerationOptions
                    { RecurseSubdirectories = true, IgnoreInaccessible = true }); }
            catch { continue; }
            foreach (var f in files)
            {
                try
                {
                    var fi = new FileInfo(f);
                    if (!fi.Exists) continue;
                    items.Add(new CleanupItem(f, fi.Length));
                }
                catch { /* skip unreadable */ }
            }
        }
        return new CleanupPreview(items, items.Sum(i => i.SizeBytes), 0);
    }

    /// <summary>Deletes the previewed files. Locked/in-use files are skipped and counted.</summary>
    public static (int deleted, int skipped, long freedBytes) Execute(CleanupPreview preview)
    {
        int deleted = 0, skipped = 0;
        long freed = 0;
        foreach (var item in preview.Items)
        {
            try
            {
                File.Delete(item.Path);
                deleted++;
                freed += item.SizeBytes;
            }
            catch { skipped++; }
        }
        return (deleted, skipped, freed);
    }
}
