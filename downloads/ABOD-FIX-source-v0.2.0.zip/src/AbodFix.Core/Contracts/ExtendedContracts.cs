using AbodFix.Core.Models;

namespace AbodFix.Core.Contracts;

public interface IEventLogScanner
{
    Task<IReadOnlyList<EventLogIssue>> GetRecentIssuesAsync(int perLogLimit = 200, CancellationToken ct = default);
}

public interface IStartupProvider
{
    Task<IReadOnlyList<StartupItem>> ListAsync(CancellationToken ct = default);
    /// <summary>Disable by moving the value aside (registry) or renaming the file. Returns a human result message.</summary>
    Task<StartupChangeResult> SetEnabledAsync(StartupItem item, bool enabled, CancellationToken ct = default);
}

public interface IServiceProvider2 // named to avoid clash with System.IServiceProvider
{
    Task<IReadOnlyList<WindowsServiceInfo>> ListImportantAsync(CancellationToken ct = default);
}

public interface INetworkDiagnostics
{
    Task<NetworkDiagnosticsResult> RunAsync(CancellationToken ct = default);
}

public interface IDriverInfoProvider
{
    Task<IReadOnlyList<DriverInfo>> ListAsync(CancellationToken ct = default);
}

/// <summary>Runs a full Windows diagnostic pass; each check reports real progress.</summary>
public interface IDiagnosticsRunner
{
    event Action<DiagnosticCheck>? CheckUpdated;
    Task<IReadOnlyList<DiagnosticCheck>> RunAllAsync(CancellationToken ct = default);
}
