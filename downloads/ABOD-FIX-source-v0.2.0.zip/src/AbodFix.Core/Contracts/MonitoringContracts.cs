using AbodFix.Core.Models;

namespace AbodFix.Core.Contracts;

/// <summary>Reads the static hardware/OS profile. Windows implementation uses WMI.</summary>
public interface ISystemInfoProvider
{
    Task<HardwareProfile> GetHardwareProfileAsync(CancellationToken ct = default);
}

/// <summary>Samples live metrics (CPU, RAM, disks, network, uptime, supported sensors).</summary>
public interface IMetricsSampler
{
    Task<SystemSnapshot> SampleAsync(CancellationToken ct = default);
}

public interface IProcessProvider
{
    Task<IReadOnlyList<ProcessInfo>> ListProcessesAsync(CancellationToken ct = default);
}

public interface IDiskHealthProvider
{
    Task<IReadOnlyList<DiskHealthInfo>> GetDisksAsync(CancellationToken ct = default);
}
