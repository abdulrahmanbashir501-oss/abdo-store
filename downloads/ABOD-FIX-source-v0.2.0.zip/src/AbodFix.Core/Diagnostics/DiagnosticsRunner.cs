using System.Diagnostics;
using AbodFix.Core.Contracts;
using AbodFix.Core.Models;

namespace AbodFix.Core.Diagnostics;

/// <summary>
/// Full Windows diagnostic pass. Every check reports real progress and a real result.
/// Read-only: diagnostics never modify the system.
/// </summary>
public sealed class DiagnosticsRunner : IDiagnosticsRunner
{
    private readonly IMetricsSampler _metrics;
    private readonly IServiceProvider2 _services;
    private readonly IStartupProvider _startup;
    private readonly IEventLogScanner _eventLog;
    private readonly IDiskHealthProvider _disks;

    public event Action<DiagnosticCheck>? CheckUpdated;

    public DiagnosticsRunner(IMetricsSampler metrics, IServiceProvider2 services,
        IStartupProvider startup, IEventLogScanner eventLog, IDiskHealthProvider disks)
    {
        _metrics = metrics;
        _services = services;
        _startup = startup;
        _eventLog = eventLog;
        _disks = disks;
    }

    public async Task<IReadOnlyList<DiagnosticCheck>> RunAllAsync(CancellationToken ct = default)
    {
        var checks = new List<DiagnosticCheck>
        {
            new() { Id = "disk-space", Title = "Disk space", TitleAr = "مساحة الأقراص" },
            new() { Id = "smart", Title = "Drive SMART status", TitleAr = "حالة SMART للأقراص" },
            new() { Id = "memory-pressure", Title = "Memory pressure", TitleAr = "ضغط الذاكرة" },
            new() { Id = "services", Title = "Important Windows services", TitleAr = "خدمات ويندوز المهمة" },
            new() { Id = "startup", Title = "Startup programs", TitleAr = "برامج بدء التشغيل" },
            new() { Id = "eventlog", Title = "Recent Event Log errors", TitleAr = "أخطاء سجل الأحداث الحديثة" },
        };

        foreach (var c in checks)
        {
            ct.ThrowIfCancellationRequested();
            c.Status = CheckStatus.Running;
            CheckUpdated?.Invoke(c);
            var sw = Stopwatch.StartNew();
            try
            {
                await RunAsync(c, ct);
            }
            catch (Exception ex)
            {
                c.Status = CheckStatus.Failed;
                c.Summary = "Check failed to run";
                c.SummaryAr = "فشل تشغيل الفحص";
                c.Details = ex.Message;
            }
            sw.Stop();
            c.Duration = sw.Elapsed;
            CheckUpdated?.Invoke(c);
        }
        return checks;
    }

    private async Task RunAsync(DiagnosticCheck c, CancellationToken ct)
    {
        switch (c.Id)
        {
            case "disk-space":
            {
                var snap = await _metrics.SampleAsync(ct);
                var full = snap.Disks.Where(d => d.UsedPercent >= 90).ToList();
                var warn = snap.Disks.Where(d => d.UsedPercent is >= 75 and < 90).ToList();
                if (full.Count > 0)
                {
                    c.Status = CheckStatus.Failed;
                    c.Summary = $"Critically full: {string.Join(", ", full.Select(d => $"{d.Name} {d.UsedPercent:F0}%"))}";
                    c.SummaryAr = $"ممتلئة بشكل خطير: {string.Join(", ", full.Select(d => $"{d.Name} {d.UsedPercent:F0}%"))}";
                    c.SuggestedRepairId = "temp-cleanup";
                }
                else if (warn.Count > 0)
                {
                    c.Status = CheckStatus.Warning;
                    c.Summary = $"Getting full: {string.Join(", ", warn.Select(d => $"{d.Name} {d.UsedPercent:F0}%"))}";
                    c.SummaryAr = $"تقترب من الامتلاء: {string.Join(", ", warn.Select(d => $"{d.Name} {d.UsedPercent:F0}%"))}";
                    c.SuggestedRepairId = "temp-cleanup";
                }
                else
                {
                    c.Status = CheckStatus.Passed;
                    c.Summary = $"{snap.Disks.Count} fixed drive(s), all under 75% used";
                    c.SummaryAr = $"{snap.Disks.Count} قرص، كلها أقل من 75% استهلاكاً";
                }
                break;
            }
            case "smart":
            {
                var disks = await _disks.GetDisksAsync(ct);
                if (disks.Any(d => d.Smart == SmartStatus.FailurePredicted))
                {
                    c.Status = CheckStatus.Failed;
                    c.Summary = "A drive predicts failure - back up now";
                    c.SummaryAr = "قرص يتوقع عطلاً - انسخ بياناتك فوراً";
                }
                else if (disks.All(d => d.Smart == SmartStatus.Unknown))
                {
                    c.Status = CheckStatus.Warning;
                    c.Summary = "No drive reported SMART status; health cannot be confirmed";
                    c.SummaryAr = "لا يوجد تقرير SMART من أي قرص؛ لا يمكن تأكيد الصحة";
                }
                else
                {
                    c.Status = CheckStatus.Passed;
                    c.Summary = "No failure predicted by reporting drives";
                    c.SummaryAr = "لا عطل متوقع من الأقراص المُبلِغة";
                }
                break;
            }
            case "memory-pressure":
            {
                var snap = await _metrics.SampleAsync(ct);
                if (snap.RamUsedPercent is >= 90)
                {
                    c.Status = CheckStatus.Warning;
                    c.Summary = $"RAM usage very high ({snap.RamUsedPercent:F0}%)";
                    c.SummaryAr = $"استهلاك الرام مرتفع جداً ({snap.RamUsedPercent:F0}%)";
                }
                else
                {
                    c.Status = CheckStatus.Passed;
                    c.Summary = snap.RamUsedPercent is double p ? $"RAM usage {p:F0}%" : "RAM counters unavailable";
                    c.SummaryAr = snap.RamUsedPercent is double p2 ? $"استهلاك الرام {p2:F0}%" : "عدادات الرام غير متاحة";
                }
                break;
            }
            case "services":
            {
                var svcs = await _services.ListImportantAsync(ct);
                var wrong = svcs.Where(s => s.LooksWrong).ToList();
                if (wrong.Count > 0)
                {
                    c.Status = CheckStatus.Warning;
                    c.Summary = $"{wrong.Count} important service(s) stopped: {string.Join(", ", wrong.Select(s => s.Name))}";
                    c.SummaryAr = $"{wrong.Count} خدمة مهمة متوقفة: {string.Join(", ", wrong.Select(s => s.Name))}";
                    c.SuggestedRepairId = "services-restart";
                }
                else
                {
                    c.Status = CheckStatus.Passed;
                    c.Summary = $"{svcs.Count} important services checked, all as expected";
                    c.SummaryAr = $"{svcs.Count} خدمة مهمة تم فحصها، كلها كما هو متوقع";
                }
                break;
            }
            case "startup":
            {
                var items = await _startup.ListAsync(ct);
                var enabled = items.Where(i => i.Enabled).ToList();
                var high = enabled.Count(i => i.Impact == "High");
                c.Status = high >= 5 ? CheckStatus.Warning : CheckStatus.Passed;
                c.Summary = $"{enabled.Count} startup app(s), {high} high impact";
                c.SummaryAr = $"{enabled.Count} برنامج بدء تشغيل، {high} عالي التأثير";
                break;
            }
            case "eventlog":
            {
                var issues = await _eventLog.GetRecentIssuesAsync(200, ct);
                var errors = issues.Where(i => i.Level == "Error").ToList();
                if (errors.Count > 0)
                {
                    c.Status = CheckStatus.Warning;
                    var top = errors.OrderByDescending(e => e.Count).Take(3)
                        .Select(e => $"{e.Source} ({e.Count}x)");
                    c.Summary = $"{errors.Count} recurring error source(s): {string.Join(", ", top)}";
                    c.SummaryAr = $"{errors.Count} مصدر أخطاء متكرر: {string.Join(", ", top)}";
                    c.Details = string.Join("\n", errors.Take(10).Select(e =>
                        $"[{e.LogName}] {e.Source} #{e.EventId} x{e.Count} - {e.SampleMessage}"));
                }
                else
                {
                    c.Status = CheckStatus.Passed;
                    c.Summary = "No recurring errors in the recent window";
                    c.SummaryAr = "لا أخطاء متكررة في الفترة الأخيرة";
                }
                break;
            }
        }
    }
}
