using System.Text.RegularExpressions;

namespace AbodFix.Core.Analyzer;

/// <summary>
/// Rule-based error analyzer. Rules map documented Windows error patterns to
/// explanations and fixes. Unmatched input gets an explicit "unknown" analysis.
/// </summary>
public sealed class ErrorAnalyzer
{
    private sealed record Rule(
        string Id, string[] Patterns,
        string Name, string NameAr, ErrorSeverity Severity,
        string Cause, string CauseAr, string Explain, string ExplainAr,
        ErrorSolution[] Solutions)
    {
        public bool Matches(string input)
            => Patterns.Any(p => Regex.IsMatch(input, p, RegexOptions.IgnoreCase));
    }

    private static ErrorSolution S(string t, string ta, string[] steps, string[] stepsAr,
        string? repair = null, bool admin = false, string? undo = null, string? undoAr = null)
        => new() { Title = t, TitleAr = ta, Steps = steps, StepsAr = stepsAr,
                   RepairOperationId = repair, RequiresAdmin = admin, Undo = undo, UndoAr = undoAr };

    private static readonly Rule[] Rules =
    [
        new("access-denied", ["0x80070005", "E_ACCESSDENIED", "access is denied", "تم رفض الوصول"],
            "Access denied", "تم رفض الوصول", ErrorSeverity.Medium,
            "The program or Windows lacked permission for a file, folder or registry key.",
            "البرنامج أو ويندوز لم يكن لديه صلاحية الوصول لملف أو مجلد أو مفتاح ريجستري.",
            "Windows blocked an action because the account or app lacked the needed rights.",
            "ويندوز منع العملية لأن الحساب أو البرنامج لا يملك الصلاحية المطلوبة.",
            [ S("Run as administrator", "شغّل كمسؤول",
                ["Right-click the program > 'Run as administrator'.", "Retry the action."],
                ["كليك يمين على البرنامج ثم 'تشغيل كمسؤول'.", "أعد المحاولة."], admin: true),
              S("Check folder permissions", "راجع صلاحيات المجلد",
                ["Right-click the folder > Properties > Security.", "Ensure your user has Full control."],
                ["كليك يمين على المجلد ثم خصائص ثم الأمان.", "تأكد أن المستخدم لديه تحكم كامل."],
                undo: "Restore previous permissions from the same tab.", undoAr: "أعد الصلاحيات من نفس التبويب.") ]),

        new("file-not-found", ["0x80070002", "ERROR_FILE_NOT_FOUND", "cannot find the file", "system cannot find"],
            "File not found", "الملف غير موجود", ErrorSeverity.Medium,
            "A needed file or path is missing, moved or deleted.",
            "ملف أو مسار مطلوب مفقود أو تم نقله أو حذفه.",
            "Something tried to open a file that is not where it was expected.",
            "شيء حاول فتح ملف غير موجود في مكانه المتوقع.",
            [ S("System file scan", "فحص ملفات النظام",
                ["Run the SFC scan from the Repair Center."], ["شغّل فحص SFC من مركز الإصلاح."],
                repair: "sfc-scan", admin: true),
              S("Reinstall the affected app", "أعد تثبيت البرنامج",
                ["Uninstall from Settings > Apps.", "Install again from the official source."],
                ["احذفه من الإعدادات ثم التطبيقات.", "ثبّته من مصدره الرسمي."]) ]),

        new("unspecified", ["0x80004005"],
            "Unspecified error 0x80004005", "خطأ غير محدد 0x80004005", ErrorSeverity.Medium,
            "Generic failure, often updates, archives or blocked files.",
            "فشل عام يظهر غالباً مع التحديثات أو الملفات المضغوطة أو الملفات المحظورة.",
            "Windows reported a failure without a specific reason; context decides the fix.",
            "ويندوز أبلغ عن فشل بدون سبب محدد؛ الحل يعتمد على سياق الخطأ.",
            [ S("Restart and retry", "أعد التشغيل وحاول مجدداً",
                ["Restart the PC.", "Retry the failed action."], ["أعد تشغيل الجهاز.", "أعد العملية التي فشلت."]),
              S("Windows Update troubleshooter", "مستكشف أخطاء التحديث",
                ["Open it from the Repair Center (official troubleshooters)."],
                ["افتحه من مركز الإصلاح (أدوات ويندوز الرسمية)."], repair: "open-troubleshooters") ]),

        new("update-failure", ["0x80070643", "0x8024\\w{4}"],
            "Windows Update failure", "فشل تحديث ويندوز", ErrorSeverity.Medium,
            "Damaged update cache or system image, or a pending reboot blocks install.",
            "ذاكرة التحديث أو صورة النظام تالفة، أو إعادة تشغيل معلقة تمنع التثبيت.",
            "An update could not install; usually fixed by repairing the image and retrying.",
            "تحديث لم يُثبّت؛ وغالباً يُحل بإصلاح الصورة وإعادة المحاولة.",
            [ S("Restart first", "أعد التشغيل أولاً",
                ["Restart, then run Windows Update again."], ["أعد التشغيل ثم شغّل التحديث مجدداً."]),
              S("Repair the image (DISM)", "إصلاح الصورة (DISM)",
                ["Run DISM RestoreHealth from the Repair Center, then retry."],
                ["شغّل DISM من مركز الإصلاح ثم أعد المحاولة."], repair: "dism-restorehealth", admin: true) ]),

        new("access-violation", ["0xc0000005", "access violation"],
            "Application crash (access violation)", "انهيار تطبيق (انتهاك وصول)", ErrorSeverity.High,
            "Bad RAM, a buggy app or a conflicting driver made it touch memory it may not use.",
            "رام معيبة أو خطأ في التطبيق أو تعريف متعارض جعله يلمس ذاكرة غير مسموح بها.",
            "The app crashed on illegal memory access; often software, sometimes hardware.",
            "التطبيق انهار بسبب وصول غير قانوني للذاكرة؛ غالباً برمجي وأحياناً عتاد.",
            [ S("Update or reinstall the app", "حدّث أو أعد تثبيت التطبيق",
                ["Check for an update.", "Otherwise reinstall it."], ["ابحث عن تحديث.", "وإلا أعد تثبيته."]),
              S("Test the RAM", "اختبر الرام",
                ["Run mdsched.exe and let both passes finish."], ["شغّل mdsched.exe واترك الفحص يكمل."], admin: true) ]),

        new("bad-image", ["0xc000007b", "unable to start correctly", "bad image"],
            "Application cannot start (0xc000007b)", "التطبيق لا يستطيع البدء", ErrorSeverity.Medium,
            "Mixed 32/64-bit components or damaged Visual C++ / DirectX runtimes.",
            "خلط مكونات 32/64 بت أو تلف مكتبات Visual C++ أو DirectX.",
            "The app loads a system library of the wrong type and fails to start.",
            "التطبيق يحمل مكتبة نظام بنوع خاطئ فيفشل في البدء.",
            [ S("Reinstall Visual C++ Redistributables", "أعد تثبيت حزم Visual C++",
                ["Install official x64 and x86 packages from microsoft.com, restart."],
                ["ثبّت الحزم الرسمية x64 وx86 من موقع مايكروسوفت وأعد التشغيل."]),
              S("System file scan", "فحص ملفات النظام",
                ["Run SFC from the Repair Center."], ["شغّل SFC من مركز الإصلاح."], repair: "sfc-scan", admin: true) ]),

        new("dll-missing", ["\\.dll.*(missing|not found|was not found)", "missing.*\\.dll"],
            "Missing DLL file", "ملف DLL مفقود", ErrorSeverity.Medium,
            "The app needs an absent library; reinstalling the app or runtime fixes it - random DLL downloads are a malware path.",
            "التطبيق يحتاج مكتبة مفقودة؛ إعادة التثبيت هي الحل، وتحميل DLL عشوائي طريق للبرمجيات الخبيثة.",
            "A required component is missing. Never download DLL files from websites.",
            "مكوّن مطلوب مفقود. لا تحمّل ملفات DLL من مواقع أبداً.",
            [ S("Reinstall the affected app", "أعد تثبيت التطبيق",
                ["Reinstall it from its official site."], ["أعد تثبيته من موقعه الرسمي."]),
              S("System file scan", "فحص ملفات النظام",
                ["If the DLL belongs to Windows, run SFC from the Repair Center."],
                ["إن كان الملف تابعاً لويندوز، شغّل SFC من مركز الإصلاح."], repair: "sfc-scan", admin: true) ]),

        new("dns", ["dns_probe", "nxdomain", "dns.*(fail|not responding|error)"],
            "DNS resolution problem", "مشكلة في DNS", ErrorSeverity.Medium,
            "The DNS server did not answer or the local cache is stale.",
            "خادم DNS لم يرد أو الذاكرة المؤقتة قديمة.",
            "The PC could not translate site names; internet may work while sites do not open.",
            "الجهاز لم يترجم أسماء المواقع؛ قد يعمل الإنترنت بينما المواقع لا تفتح.",
            [ S("Flush the DNS cache", "امسح ذاكرة DNS",
                ["Run 'Flush DNS cache' from the Repair Center."],
                ["شغّل 'مسح ذاكرة DNS' من مركز الإصلاح."], repair: "flush-dns"),
              S("Change DNS servers", "غيّر خوادم DNS",
                ["Set 8.8.8.8 and 1.1.1.1 in the adapter DNS settings.", "Retry."],
                ["اضبط 8.8.8.8 و1.1.1.1 في إعدادات DNS للمحوّل.", "أعد المحاولة."]) ]),

        new("bsod", ["irql_not_less_or_equal", "page_fault_in_nonpaged_area", "memory_management",
                     "critical_process_died", "blue screen", "bsod", "system_service_exception", "kmode_exception"],
            "Blue screen (BSOD)", "الشاشة الزرقاء", ErrorSeverity.Critical,
            "A driver, faulty RAM or overheating crashed the kernel; the stop code names the family.",
            "تعريف أو رام معيبة أو سخونة أسقطت النواة؛ كود الإيقاف يحدد العائلة.",
            "Windows stopped itself to prevent damage. Repeated BSODs deserve attention.",
            "ويندوز أوقف نفسه لمنع ضرر أكبر. التكرار يستحق الانتباه.",
            [ S("Check drivers and updates", "راجع التعريفات والتحديثات",
                ["Open the Drivers section; devices with errors are marked.", "Install pending updates."],
                ["افتح قسم التعريفات؛ الأجهزة المعطوبة مميزة.", "ثبّت التحديثات المعلقة."]),
              S("Test the RAM", "اختبر الرام",
                ["Run mdsched.exe to completion."], ["شغّل mdsched.exe حتى النهاية."], admin: true),
              S("System file and image repair", "إصلاح الملفات والصورة",
                ["Run SFC then DISM from the Repair Center."],
                ["شغّل SFC ثم DISM من مركز الإصلاح."], repair: "sfc-scan", admin: true) ]),

        new("disk-full", ["0x80070070", "not enough (disk )?space", "disk (is )?full"],
            "Not enough disk space", "لا توجد مساحة كافية", ErrorSeverity.High,
            "The drive is nearly full; Windows needs room for updates, paging and temp files.",
            "القرص شبه ممتلئ؛ ويندوز يحتاج مساحة للتحديثات والترحيل والملفات المؤقتة.",
            "The drive ran out of room. Cleaning temp files is the safe first step.",
            "القرص امتلأ. تنظيف الملفات المؤقتة أول خطوة آمنة.",
            [ S("Clean temporary files", "نظّف الملفات المؤقتة",
                ["Run 'Clean temporary files' from the Repair Center and review the preview first."],
                ["شغّل 'تنظيف الملفات المؤقتة' من مركز الإصلاح وراجع المعاينة أولاً."], repair: "temp-cleanup"),
              S("Review drive usage", "راجع استهلاك الأقراص",
                ["Open Disk Health to see usage per drive."], ["افتح صحة الأقراص لرؤية الاستهلاك."]) ]),

        new("app-hang", ["not responding", "لا يستجيب", "stopped working"],
            "Application not responding", "التطبيق لا يستجيب", ErrorSeverity.Low,
            "The app is stuck on a slow operation, a deadlock, or waiting on a resource.",
            "التطبيق عالق في عملية بطيئة أو توقف داخلي أو ينتظر مورداً.",
            "The program froze; ending it loses unsaved work but is safe for the system.",
            "البرنامج تجمد؛ إنهاؤه يفقد غير المحفوظ لكنه آمن على النظام.",
            [ S("End the process", "أنهِ العملية",
                ["Processes section: find the app and end it after confirming."],
                ["قسم العمليات: ابحث عن التطبيق وأنهِه بعد التأكيد."]),
              S("Check system load", "راجع حمل النظام",
                ["A saturated CPU/RAM makes apps hang; see the Dashboard."],
                ["المعالج أو الرام المثقلان يجمدان التطبيقات؛ انظر لوحة التحكم."]) ]),

        new("no-internet", ["no internet", "network.*unreachable", "لا يوجد اتصال", "limited access"],
            "No internet connectivity", "لا يوجد اتصال بالإنترنت", ErrorSeverity.High,
            "Adapter, router or ISP path is down, or the PC kept a stale address.",
            "المحوّل أو الراوتر أو المزود متوقف، أو الجهاز احتفظ بعنوان قديم.",
            "The connection itself failed, not just one site.",
            "الاتصال نفسه فشل، وليس موقعاً واحداً.",
            [ S("Run network diagnostics", "شغّل تشخيص الشبكة",
                ["Open the Network section and run the checks."], ["افتح قسم الشبكة وشغّل الفحوصات."]),
              S("Renew the IP address", "جدّد عنوان IP",
                ["Run 'Renew IP address' from the Repair Center."],
                ["شغّل 'تجديد عنوان IP' من مركز الإصلاح."], repair: "ip-renew"),
              S("Restart the router", "أعد تشغيل الراوتر",
                ["Unplug 10 seconds, plug back, wait 2 minutes."],
                ["افصله 10 ثوان، أعد توصيله، انتظر دقيقتين."]) ]),

        new("driver", ["driver.*(fail|error|corrupt|missing)", "code 43", "code 31", "code 10", "device cannot start"],
            "Device driver problem", "مشكلة في تعريف جهاز", ErrorSeverity.High,
            "The driver is missing, corrupted or blocked by an update.",
            "التعريف مفقود أو تالف أو متعارض مع تحديث.",
            "Hardware has no working driver, so Windows cannot use it correctly.",
            "عتاد بلا تعريف صالح فلا يستخدمه ويندوز بشكل صحيح.",
            [ S("Inspect the Drivers section", "افحص قسم التعريفات",
                ["Devices with errors are marked; use only official vendor links shown there."],
                ["الأجهزة المعطوبة مميزة؛ استخدم روابط الشركات الرسمية فقط."]),
              S("Reinstall the driver", "أعد تثبيت التعريف",
                ["Device Manager: right-click > Uninstall, restart; Windows reinstalls it."],
                ["إدارة الأجهزة: كليك يمين ثم إلغاء تثبيت، أعد التشغيل؛ ويندوز يعيد تثبيته."]) ]),
    ];

    private static readonly Rule Fallback = new(
        "unknown", [],
        "Unrecognized error", "خطأ غير معروف", ErrorSeverity.Medium,
        "The input did not match a documented Windows error pattern.",
        "المدخل لم يطابق نمط خطأ موثق في ويندوز.",
        "No confident match; these steps gather better evidence instead of guessing.",
        "لا يوجد تطابق مؤكد؛ هذه الخطوات تجمع أدلة أفضل بدلاً من التخمين.",
        [ S("Scan recent Event Log errors", "افحص أخطاء سجل الأحداث",
            ["Run Windows diagnostics; it lists recurring recent errors with sources."],
            ["شغّل تشخيص ويندوز؛ يعرض الأخطاء المتكررة الحديثة ومصادرها."]),
          S("System file scan", "فحص ملفات النظام",
            ["Run SFC from the Repair Center when the cause is unclear."],
            ["عند عدم وضوح السبب، شغّل SFC من مركز الإصلاح."], repair: "sfc-scan", admin: true) ]);

    public ErrorAnalysis Analyze(string input)
    {
        var rule = Rules.FirstOrDefault(r => r.Matches(input)) ?? Fallback;
        return new ErrorAnalysis
        {
            ProblemName = rule.Name,
            ProblemNameAr = rule.NameAr,
            Severity = rule.Severity,
            LikelyCause = rule.Cause,
            LikelyCauseAr = rule.CauseAr,
            SimpleExplanation = rule.Explain,
            SimpleExplanationAr = rule.ExplainAr,
            Solutions = rule.Solutions,
            MatchedRuleId = rule.Id == "unknown" ? null : rule.Id,
            Input = input
        };
    }
}
