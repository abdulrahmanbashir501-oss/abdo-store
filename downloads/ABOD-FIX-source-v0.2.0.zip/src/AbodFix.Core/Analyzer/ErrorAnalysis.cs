namespace AbodFix.Core.Analyzer;

public enum ErrorSeverity { Low, Medium, High, Critical }

/// <summary>One suggested fix, ordered from easiest to most advanced.</summary>
public sealed record ErrorSolution
{
    public required string Title { get; init; }
    public required string TitleAr { get; init; }
    public IReadOnlyList<string> Steps { get; init; } = [];
    public IReadOnlyList<string> StepsAr { get; init; } = [];
    public string? Undo { get; init; }
    public string? UndoAr { get; init; }
    public bool RequiresAdmin { get; init; }
    /// <summary>Id of a built-in repair operation when one exists (e.g. "sfc-scan"), else null.</summary>
    public string? RepairOperationId { get; init; }
}

/// <summary>Structured result every analysis must contain (per the product spec).</summary>
public sealed record ErrorAnalysis
{
    public required string ProblemName { get; init; }
    public required string ProblemNameAr { get; init; }
    public required ErrorSeverity Severity { get; init; }
    public required string LikelyCause { get; init; }
    public required string LikelyCauseAr { get; init; }
    public required string SimpleExplanation { get; init; }
    public required string SimpleExplanationAr { get; init; }
    public IReadOnlyList<ErrorSolution> Solutions { get; init; } = [];
    /// <summary>Id of the rule that matched, or null for the generic fallback.</summary>
    public string? MatchedRuleId { get; init; }
    public required string Input { get; init; }
}
