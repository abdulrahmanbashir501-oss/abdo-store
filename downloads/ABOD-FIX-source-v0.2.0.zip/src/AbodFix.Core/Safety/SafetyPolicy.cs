namespace AbodFix.Core.Safety;

public enum SafetyMode
{
    /// <summary>Default: diagnose only, nothing on the system is modified.</summary>
    ReadOnly,
    /// <summary>Repair actions enabled, each still requires explicit user confirmation.</summary>
    RepairsEnabled
}

/// <summary>
/// Central safety rules. Phase 1 ships read-only; these lists already protect
/// the phase 2 actions (kill process, disable startup item, run admin commands).
/// </summary>
public static class SafetyPolicy
{
    /// <summary>
    /// Processes that must never be terminated from the app. Killing any of these
    /// can crash or destabilize Windows. Matching is by process name, case-insensitive.
    /// </summary>
    public static readonly IReadOnlySet<string> ProtectedProcessNames = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
    {
        "System", "System Idle Process", "Registry", "Memory Compression", "Secure System",
        "smss", "csrss", "wininit", "winlogon", "services", "lsass", "lsaiso", "svchost",
        "fontdrvhost", "dwm", "explorer", "sihost", "taskhostw", "RuntimeBroker",
        "MsMpEng", "SecurityHealthService", "csrss", "conhost", "spoolsv", "SearchIndexer",
        "WmiPrvSE", "audiodg", "SystemSettings", "ShellExperienceHost", "StartMenuExperienceHost"
    };

    public static bool IsCriticalProcess(string? processName)
        => processName is not null && ProtectedProcessNames.Contains(processName);

    /// <summary>Windows services that must never be stopped from the app.</summary>
    public static readonly IReadOnlySet<string> ProtectedServiceNames = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
    {
        "WinDefend", "wuauserv", "EventLog", "RpcSs", "DcomLaunch", "Winmgmt", "Schedule",
        "MpsSvc", "SamSs", "ProfSvc", "UserManager", "Dhcp", "Dnscache", "W32Time"
    };

    public static bool IsCriticalService(string? serviceName)
        => serviceName is not null && ProtectedServiceNames.Contains(serviceName);
}
