namespace AbodFix.Core.Safety;

public enum OperationRisk { Low, Medium, High }

/// <summary>
/// Describes a repair/admin operation BEFORE it runs: what it does, the exact
/// commands that will be executed, the risks, and how to undo. The UI must show
/// this and get explicit confirmation. Used by phase 2 repair center.
/// </summary>
public sealed record OperationDescriptor
{
    public required string Id { get; init; }
    public required string Title { get; init; }
    public required string Description { get; init; }
    /// <summary>Exact command lines that will be run, displayed to the user verbatim.</summary>
    public IReadOnlyList<string> Commands { get; init; } = [];
    public IReadOnlyList<string> Risks { get; init; } = [];
    public string? UndoInstructions { get; init; }
    public OperationRisk Risk { get; init; } = OperationRisk.Low;
    public bool RequiresAdmin { get; init; }

    public static readonly OperationDescriptor SfcScan = new()
    {
        Id = "sfc-scan",
        Title = "System File Checker scan",
        Description = "Scans protected Windows system files and repairs corrupted copies from the component store.",
        Commands = ["sfc.exe /scannow"],
        Risks = ["Can take 5-15 minutes.", "Requires Administrator."],
        UndoInstructions = "No undo needed: SFC only restores original Microsoft files.",
        Risk = OperationRisk.Low,
        RequiresAdmin = true
    };

    public static readonly OperationDescriptor DismRestoreHealth = new()
    {
        Id = "dism-restorehealth",
        Title = "DISM image repair",
        Description = "Checks and repairs the Windows system image used by SFC.",
        Commands = ["DISM.exe /Online /Cleanup-Image /RestoreHealth"],
        Risks = ["Can take 10-30 minutes.", "Needs internet access to Windows Update.", "Requires Administrator."],
        Risk = OperationRisk.Low,
        RequiresAdmin = true
    };
}
