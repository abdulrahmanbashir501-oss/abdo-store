# ABOD FIX
### مساعد تشخيص وإصلاح ويندوز الاحترافي — Professional Windows Diagnostic & Repair Assistant

**العربية أولاً، English below.**

---

## العربية

### ما هو ABOD FIX؟
برنامج تشخيص وصيانة حقيقي لأجهزة Windows 10 وWindows 11. يقرأ بيانات جهازك الفعلية عبر أدوات ويندوز الرسمية (WMI، عدادات الأداء، سجل الأحداث) ويعرضها بواجهة Cyber Dark سوداء/حمراء باللغتين العربية (RTL) والإنجليزية.

**المبدأ الأساسي: لا أرقام وهمية أبداً.** إذا كان المستشعر غير مدعوم في جهازك، يخبرك البرنامج بذلك صراحة بدلاً من اختلاق قيمة. ولا يوجد أي زر لا يعمل.

### النسخة 0.2.0 — كل ما يعمل فعلاً

**المراقبة الحية:**
- **لوحة التحكم:** اسم المعالج ونسبة استخدامه، الرام، الأقراص والمساحة، كارت الشاشة واستخدامه (عند دعم العدادات)، حرارة المعالج (عند وجود مستشعر فعلي فقط)، حالة الشبكة، مدة التشغيل، رسوم بيانية حية لآخر 60 ثانية.
- **إدارة العمليات:** كل العمليات مع PID والذاكرة والمعالج والشركة، بحث وفلترة، وإنهاء بعد تأكيدك مع حماية صارمة لعمليات ويندوز الأساسية.
- **صحة الأقراص:** الأقراص الفعلية وحالة SMART كما يبلغها الجهاز. «غير معروف» تُعرض كما هي.

**التشخيص والإصلاح (الجديد):**
- **فحص ويندوز الكامل:** 6 فحوصات حقيقية (مساحة الأقراص، SMART، ضغط الذاكرة، خدمات ويندوز المهمة، برامج البدء، أخطاء Event Log الأخيرة) — كل فحص يعرض حالته وملخصه ومدته الفعلية، ويقترح إصلاحاً مناسباً عند الحاجة.
- **مركز الإصلاح الذكي:** SFC وDISM، تنظيف الملفات المؤقتة، تجديد IP، مسح DNS، فتح مستكشفات أخطاء ويندوز، إعادة تشغيل خدمات متعطلة. **كل عملية تعرض: الوصف، الأوامر الفعلية التي ستُنفَّذ، المخاطر، طريقة التراجع — وتنتظر موافقتك الصريحة.** تنظيف الملفات يعرض القائمة الكاملة بالأحجام قبل حذف أي شيء، والملفات المقفلة تُتخطَّى بأمان. كل شيء يُسجَّل في السجل.
- **إدارة بدء التشغيل:** كل برامج البدء (الريجستري ومجلد Startup) مع الشركة والمسار وتأثير البدء، وتفعيل/تعطيل حقيقي مع تنبيه للعناصر المهمة (مثل برامج الحماية).
- **محلل الأخطاء الذكي:** الصق رمز الخطأ (مثل 0x80070005) أو وصف المشكلة بالعربية أو الإنجليزية، فيشرح لك السبب المحتمل بلغة بسيطة مع خطوات حل مرتبة وطريقة التراجع — 13 قاعدة موثقة للأخطاء الشائعة، والمدخل غير المعروف يُصرَّح بأنه غير معروف.
- **فحص الشبكة:** اختبار الاتصال الفعلي، DNS، البوابة، والمحولات مع عناوين IP — من نتائج حقيقية فقط.
- **التعريفات:** كل الأجهزة والتعريفات (الاسم، الشركة، الإصدار، التاريخ) مع تمييز الأجهزة التي بها مشاكل (كود الخطأ الحقيقي)، ورابط الموقع الرسمي للشركة المصنعة فقط — لا تحميل تعريفات تلقائي ولا مواقع خارجية مشبوهة.
- **AI Technician:** مساعد ذكي اختياري يعمل مع أي مزوّد متوافق مع OpenAI (OpenAI، أو خادم محلي مثل Ollama / LM Studio). مفتاح API يُحفظ مشفراً في حسابك على ويندوز (DPAPI) ولا يوجد أبداً داخل ملفات البرنامج. بدون مفتاح، كل باقي البرنامج يعمل كاملاً.

**عام:**
- **التقارير:** PDF وTXT وJSON تحفظ حيث تختار.
- **السجل:** كل نشاط في قاعدة SQLite محلية.
- **الأمان:** لا أمر إداري دون موافقة مسبقة، لا حذف تلقائي، لا تعديل ريجستري عشوائي، لا إيقاف خدمات أساسية.

### حدود صادقة — اقرأها قبل الحكم
- البرنامج طُوّر وبُني على بيئة Linux عبر الاستهداف المتقاطع. **الكود يُترجم بنجاح وكل اختبارات المنطق تمر (56 اختباراً)، لكن الواجهة لم تُجرَّب بعد على جهاز Windows حقيقي.**
- حرارة المعالج/كارت الشاشة تظهر فقط إذا وفّر جهازك مستشعراً تقرأه WMI.
- قيمة VRAM من WMI مقيدة بحد 4GB في بعض الأنظمة (قيد معروف في Win32_VideoController).
- تشغيل SFC وDISM يحتاج تشغيل البرنامج كمسؤول — البرنامج يوضح ذلك قبل العملية ولا يرفع صلاحياته بنفسه.
- لا يوجد مثبّت بعد: ملف EXE واحد يعمل مباشرة، مع مجلد الخطوط LatoFont بجانبه.

### المتطلبات والتشغيل
- Windows 10 أو 11 (64-bit). لا يحتاج تثبيت .NET (Self-Contained).
- فك الضغط وشغّل `ABOD FIX.exe` مع إبقاء مجلد LatoFont بجانبه.
- التوقيع الرقمي غير موجود بعد: عند تحذير SmartScreen اختر More info ثم Run anyway.

### البناء من المصدر
```powershell
git clone <repo>
cd abod-fix
dotnet restore
dotnet test -c Release
dotnet publish src/AbodFix.App -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -o artifacts/publish
```

### بنية المشروع (Modular)
```
src/AbodFix.Core    منطق مستقل عن النظام: النماذج، العقود، التشخيص، الإصلاح، محلل الأخطاء، عميل AI، التقارير، السجل
src/AbodFix.App     تطبيق WPF: تنفيذات WMI/PerformanceCounter/EventLog، الواجهة، الترجمة
tests/AbodFix.Tests اختبارات xunit لطبقة المنطق (56 اختباراً)
```

### خارطة الطريق
- **المرحلة 4:** تطبيق Android المرافق (Flutter) وربطه بالبرنامج.

---

## English

### What is ABOD FIX?
A real diagnostic and maintenance assistant for Windows 10/11. It reads your machine's actual data through official Windows interfaces (WMI, Performance Counters, Event Log) and presents it in a black/red Cyber Dark UI, in Arabic (RTL) and English.

**Core principle: never a fake number.** If your device does not expose a sensor, the app says so instead of inventing a value. No dead buttons.

### v0.2.0 - what actually works

**Live monitoring:**
- **Dashboard:** CPU name/usage, RAM, disks and free space, GPU name/usage (when counters exist), CPU temperature (only from a real sensor), network status, uptime, live 60-second charts.
- **Process manager:** all processes with PID/memory/CPU/company, search, terminate with confirmation and a hard protection list for critical Windows processes.
- **Disk health:** physical disks and SMART prediction as reported by the device. "Unknown" is shown honestly.

**Diagnostics and repair (new):**
- **Full Windows diagnostic:** 6 real checks (disk space, SMART, memory pressure, important services, startup programs, recent Event Log errors) with live status, summaries, durations and repair suggestions.
- **Smart Repair Center:** SFC and DISM, temp-file cleanup, IP renew, DNS flush, Windows troubleshooters, restart of stopped services. **Every operation shows its description, the exact commands that will run, risks, and undo steps - then waits for your explicit approval.** Cleanup shows the full file list with sizes before deleting anything; locked files are skipped safely. Everything is logged.
- **Startup manager:** every startup entry (registry + startup folder) with company, path and impact; real enable/disable with warnings for security-relevant items.
- **Smart Error Analyzer:** paste an error code (e.g. 0x80070005) or describe the problem in Arabic or English; you get the likely cause in plain language, ordered fix steps and undo notes. 13 documented rules for common errors; unknown input is declared unknown.
- **Network diagnostics:** real connectivity, DNS and gateway checks plus adapters with their IP addresses.
- **Drivers:** every device and driver (name, manufacturer, version, date) with problem devices flagged by their real error code, plus a link to the manufacturer's official site only. No automatic driver downloads.
- **AI Technician:** optional assistant that works with any OpenAI-compatible endpoint (OpenAI, or a local server like Ollama / LM Studio). The API key is stored encrypted in your Windows account (DPAPI) and never in app files. Without a key, everything else works fully.

**General:**
- **Reports:** PDF, TXT or JSON saved where you choose.
- **History:** every action in a local SQLite database.
- **Safety:** no admin command without prior approval, no automatic deletion, no random registry edits, no stopping core services.

### Honest limitations - read before judging
- Developed and cross-compiled on Linux. **The code compiles and all 56 logic tests pass, but the UI has not yet been run on a real Windows machine.**
- Temperatures appear only if your hardware exposes a WMI-readable sensor.
- WMI-reported VRAM is capped at 4 GB on some systems.
- SFC/DISM require running the app as administrator - the app says so before the operation and never elevates itself.
- No installer yet: a single portable EXE, keep the LatoFont folder next to it.
- Not code-signed yet: on the SmartScreen warning choose "More info" then "Run anyway".

### Requirements
Windows 10/11 x64. No .NET install needed (self-contained). No admin rights at startup.

### Build from source
Same commands as the Arabic section.

### Architecture
Modular: `AbodFix.Core` (OS-independent logic: diagnostics, repair plans, error analyzer, AI client, reports, history) + `AbodFix.App` (WPF UI + Windows services) + `AbodFix.Tests` (56 xunit tests).

### Roadmap
Phase 4: Android companion app (Flutter) linked to the desktop app.

### Third-party licenses
- QuestPDF (PDF reports) - Community license, free for individuals and small businesses.
- Microsoft.Data.Sqlite, CommunityToolkit.Mvvm - MIT.
