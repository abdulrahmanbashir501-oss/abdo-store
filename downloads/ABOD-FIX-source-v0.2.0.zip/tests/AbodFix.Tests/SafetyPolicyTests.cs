using AbodFix.Core.Safety;

namespace AbodFix.Tests;

public sealed class SafetyPolicyTests
{
    [Theory]
    [InlineData("svchost")]
    [InlineData("SVCHOST")]
    [InlineData("System")]
    [InlineData("lsass")]
    [InlineData("explorer")]
    [InlineData("MsMpEng")]
    public void CriticalProcessesAreProtected(string name)
        => Assert.True(SafetyPolicy.IsCriticalProcess(name));

    [Theory]
    [InlineData("notepad")]
    [InlineData("chrome")]
    [InlineData("game")]
    public void UserProcessesAreNotProtected(string name)
        => Assert.False(SafetyPolicy.IsCriticalProcess(name));

    [Fact]
    public void NullIsNotProtected() => Assert.False(SafetyPolicy.IsCriticalProcess(null));

    [Theory]
    [InlineData("WinDefend")]
    [InlineData("EventLog")]
    [InlineData("wuauserv")]
    public void CriticalServicesAreProtected(string name)
        => Assert.True(SafetyPolicy.IsCriticalService(name));

    [Fact]
    public void RepairDescriptorsShowCommandsAndAdmin()
    {
        Assert.True(OperationDescriptor.SfcScan.RequiresAdmin);
        Assert.Contains("sfc.exe /scannow", OperationDescriptor.SfcScan.Commands);
        Assert.True(OperationDescriptor.DismRestoreHealth.RequiresAdmin);
        Assert.NotEmpty(OperationDescriptor.DismRestoreHealth.Risks);
    }
}
