using AbodFix.Core.History;
using AbodFix.Core.Models;

namespace AbodFix.Tests;

public sealed class HistoryStoreTests : IDisposable
{
    private readonly string _dbPath = Path.Combine(Path.GetTempPath(), $"abodfix-test-{Guid.NewGuid():N}.db");
    private readonly HistoryStore _store;

    public HistoryStoreTests() => _store = new HistoryStore(_dbPath);

    [Fact]
    public async Task AddAndReadBackEntries()
    {
        var id = await _store.AddEntryAsync(new HistoryEntry
        {
            Kind = HistoryKind.Scan,
            Title = "SFC scan",
            Details = "sfc /scannow",
            Result = "No integrity violations"
        });

        Assert.True(id > 0);
        var entries = await _store.GetRecentAsync();
        var e = Assert.Single(entries);
        Assert.Equal("SFC scan", e.Title);
        Assert.Equal(HistoryKind.Scan, e.Kind);
        Assert.Equal("No integrity violations", e.Result);
    }

    [Fact]
    public async Task EntriesComeBackNewestFirst()
    {
        await _store.AddEntryAsync(new HistoryEntry { Kind = HistoryKind.Info, Title = "first" });
        await _store.AddEntryAsync(new HistoryEntry { Kind = HistoryKind.Info, Title = "second" });
        var entries = await _store.GetRecentAsync();
        Assert.Equal("second", entries[0].Title);
        Assert.Equal("first", entries[1].Title);
    }

    [Fact]
    public async Task SettingsRoundTrip()
    {
        Assert.Null(await _store.GetSettingAsync("language"));
        await _store.SetSettingAsync("language", "ar");
        Assert.Equal("ar", await _store.GetSettingAsync("language"));
        await _store.SetSettingAsync("language", "en");
        Assert.Equal("en", await _store.GetSettingAsync("language"));
    }

    [Fact]
    public async Task SurvivesReopen()
    {
        await _store.AddEntryAsync(new HistoryEntry { Kind = HistoryKind.Repair, Title = "repair-1" });
        using var store2 = new HistoryStore(_dbPath);
        var entries = await store2.GetRecentAsync();
        Assert.Single(entries);
    }

    public void Dispose()
    {
        _store.Dispose();
        try { File.Delete(_dbPath); } catch { }
    }
}
