using AbodFix.Core.Contracts;
using AbodFix.Core.Models;
using AbodFix.Core.Reports;

namespace AbodFix.Tests;

public sealed class ModelTests
{
    [Fact]
    public void RamMathIsCorrect()
    {
        var s = TestData.Snapshot;
        Assert.Equal(8L * 1024 * 1024 * 1024, s.RamUsedBytes);
        Assert.Equal(50.0, s.RamUsedPercent);
    }

    [Fact]
    public void MissingRamYieldsNullNotZero()
    {
        var s = new SystemSnapshot();
        Assert.Null(s.RamUsedBytes);
        Assert.Null(s.RamUsedPercent);
    }

    [Fact]
    public void DiskPercentIsCorrect()
    {
        var d = TestData.Snapshot.Disks[0];
        Assert.Equal(60.0, d.UsedPercent, precision: 3);
    }

    [Fact]
    public void ByteFormatting()
    {
        Assert.Equal("1.0 GB", TxtReportExporter.FormatBytes(1024L * 1024 * 1024));
        Assert.Equal("512.0 MB", TxtReportExporter.FormatBytes(512L * 1024 * 1024));
        Assert.Equal("n/a", TxtReportExporter.FormatBytes(null));
    }
}

public sealed class ReportBuilderTests
{
    private sealed class FakeInfo : ISystemInfoProvider
        { public Task<HardwareProfile> GetHardwareProfileAsync(CancellationToken ct = default) => Task.FromResult(TestData.Hardware); }
    private sealed class FakeMetrics : IMetricsSampler
        { public Task<SystemSnapshot> SampleAsync(CancellationToken ct = default) => Task.FromResult(TestData.Snapshot); }
    private sealed class FakeProcs : IProcessProvider
        { public Task<IReadOnlyList<ProcessInfo>> ListProcessesAsync(CancellationToken ct = default) => Task.FromResult(TestData.Report.TopProcessesByMemory); }
    private sealed class FakeDisks : IDiskHealthProvider
        { public Task<IReadOnlyList<DiskHealthInfo>> GetDisksAsync(CancellationToken ct = default) => Task.FromResult(TestData.Report.DiskHealth); }

    [Fact]
    public async Task BuildsAndNotesUnsupportedSensors()
    {
        var builder = new ReportBuilder(new FakeInfo(), new FakeMetrics(), new FakeProcs(), new FakeDisks(), "0.1.0");
        var report = await builder.BuildAsync("test");

        Assert.Equal("TEST-PC", report.MachineName);
        Assert.Equal(2, report.TopProcessesByMemory.Count);
        // temperature unsupported + SMART unknown must surface as explicit notes
        Assert.Contains(report.Notes, n => n.Contains("temperature"));
        Assert.Contains(report.Notes, n => n.Contains("SMART"));
    }
}
