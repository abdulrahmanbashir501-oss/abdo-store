using System.Text.Json;
using AbodFix.Core.Models;
using AbodFix.Core.Reports;

namespace AbodFix.Tests;

public sealed class TxtReportExporterTests
{
    [Fact]
    public async Task ContainsRealValues()
    {
        var path = Path.Combine(Path.GetTempPath(), $"abodfix-{Guid.NewGuid():N}.txt");
        await new TxtReportExporter().ExportAsync(TestData.Report, path);
        var text = await File.ReadAllTextAsync(path);

        Assert.Contains("Test CPU 3000X", text);
        Assert.Contains("42.5 %", text);
        Assert.Contains("Test GPU 9000", text);
        Assert.Contains("TEST-PC", text);
        // honesty: unsupported temperature sensor must be stated, not invented
        Assert.Contains("sensor not supported", text);
        // honesty: unknown SMART must never be presented as healthy
        Assert.Contains("unknown (device did not report SMART status)", text);
        Assert.DoesNotContain("no failure predicted", text.Split("chrome")[0]);
        File.Delete(path);
    }

    [Fact]
    public async Task FailurePredictedIsLoud()
    {
        var report = TestData.Report with
        {
            DiskHealth = [new DiskHealthInfo { Model = "DyingDisk", Smart = SmartStatus.FailurePredicted }]
        };
        var path = Path.Combine(Path.GetTempPath(), $"abodfix-{Guid.NewGuid():N}.txt");
        await new TxtReportExporter().ExportAsync(report, path);
        var text = await File.ReadAllTextAsync(path);
        Assert.Contains("FAILURE PREDICTED", text);
        File.Delete(path);
    }
}

public sealed class JsonReportExporterTests
{
    [Fact]
    public async Task RoundTrips()
    {
        var path = Path.Combine(Path.GetTempPath(), $"abodfix-{Guid.NewGuid():N}.json");
        await new JsonReportExporter().ExportAsync(TestData.Report, path);
        var json = await File.ReadAllTextAsync(path);
        var back = JsonSerializer.Deserialize<ReportData>(json,
            new JsonSerializerOptions { PropertyNamingPolicy = JsonNamingPolicy.CamelCase });

        Assert.NotNull(back);
        Assert.Equal("TEST-PC", back.MachineName);
        Assert.Equal(42.5, back.Snapshot?.CpuUsagePercent);
        Assert.Equal("Test CPU 3000X", back.Hardware?.Cpu.Name);
        File.Delete(path);
    }
}

public sealed class PdfReportExporterTests
{
    [Fact]
    public async Task ProducesValidPdf()
    {
        var path = Path.Combine(Path.GetTempPath(), $"abodfix-{Guid.NewGuid():N}.pdf");
        try
        {
            await new PdfReportExporter().ExportAsync(TestData.Report, path);
        }
        catch (Exception ex) when (!OperatingSystem.IsWindows())
        {
            // PDF layout needs system fonts; a bare Linux CI container may have none.
            // This is an environment limitation, not a code failure - assert explicitly.
            Assert.Fail($"PDF generation unavailable in this environment ({ex.GetType().Name}); run on Windows to verify.");
        }
        var bytes = await File.ReadAllBytesAsync(path);
        Assert.True(bytes.Length > 500);
        Assert.Equal("%PDF", System.Text.Encoding.ASCII.GetString(bytes, 0, 4));
        File.Delete(path);
    }
}
