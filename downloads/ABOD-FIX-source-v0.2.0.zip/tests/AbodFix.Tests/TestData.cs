using AbodFix.Core.Models;

namespace AbodFix.Tests;

public static class TestData
{
    public static HardwareProfile Hardware => new()
    {
        Cpu = new CpuInfo { Name = "Test CPU 3000X", PhysicalCores = 8, LogicalProcessors = 16, MaxClockMHz = 4200 },
        Os = new OsInfo { Caption = "Windows 11 Pro", Version = "10.0.22631", BuildNumber = "22631", Architecture = "64-bit" },
        TotalRamBytes = 16L * 1024 * 1024 * 1024,
        Gpus = [new GpuInfo { Name = "Test GPU 9000", Vendor = "TestVendor", DriverVersion = "1.2.3", AdapterRamBytes = 8L * 1024 * 1024 * 1024 }],
        MachineName = "TEST-PC"
    };

    public static SystemSnapshot Snapshot => new()
    {
        CpuUsagePercent = 42.5,
        RamTotalBytes = 16L * 1024 * 1024 * 1024,
        RamAvailableBytes = 8L * 1024 * 1024 * 1024,
        Uptime = TimeSpan.FromHours(3.5),
        Network = NetworkStatus.Connected,
        CpuTemperatureCelsius = null, // sensor unsupported on this device
        GpuUsagePercent = 7.0,
        Disks =
        [
            new DiskSample { Name = "C:\\", VolumeLabel = "System", FileSystem = "NTFS", TotalBytes = 500L * 1024 * 1024 * 1024, FreeBytes = 200L * 1024 * 1024 * 1024 }
        ]
    };

    public static ReportData Report => new()
    {
        Title = "System summary report",
        MachineName = "TEST-PC",
        Hardware = Hardware,
        Snapshot = Snapshot,
        DiskHealth =
        [
            new DiskHealthInfo { Model = "TestDisk 1TB", InterfaceType = "NVMe", SizeBytes = 1_000_000_000_000, Smart = SmartStatus.Unknown,
                SmartDetails = "This drive did not report SMART failure prediction." }
        ],
        TopProcessesByMemory =
        [
            new ProcessInfo { Pid = 1234, Name = "chrome", MemoryBytes = 900_000_000, Company = "Google" },
            new ProcessInfo { Pid = 4, Name = "System", MemoryBytes = 100_000, IsCriticalSystemProcess = true }
        ]
    };
}
