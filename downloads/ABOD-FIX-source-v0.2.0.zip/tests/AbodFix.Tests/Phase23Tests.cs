using System.Net;
using System.Text;
using AbodFix.Core.Ai;
using AbodFix.Core.Analyzer;
using AbodFix.Core.Contracts;
using AbodFix.Core.Diagnostics;
using AbodFix.Core.Models;
using AbodFix.Core.Repair;
using Xunit;

namespace AbodFix.Tests;

public class ErrorAnalyzerTests
{
    private readonly ErrorAnalyzer _analyzer = new();

    [Theory]
    [InlineData("Error 0x80070005 when installing", "access-denied")]
    [InlineData("E_ACCESSDENIED from COM", "access-denied")]
    [InlineData("The system cannot find the file specified", "file-not-found")]
    [InlineData("0x80004005 unspecified", "unspecified")]
    [InlineData("VCRUNTIME140.dll is missing", "dll-missing")]
    [InlineData("DNS server not responding", "dns")]
    [InlineData("no internet access after update", "no-internet")]
    [InlineData("blue screen IRQL_NOT_LESS_OR_EQUAL", "bsod")]
    [InlineData("disk is full", "disk-full")]
    public void Known_patterns_match_their_rule(string input, string expectedRule)
    {
        var result = _analyzer.Analyze(input);
        Assert.Equal(expectedRule, result.MatchedRuleId);
        Assert.NotEmpty(result.Solutions);
        Assert.NotEmpty(result.ProblemNameAr);
        Assert.NotEmpty(result.SimpleExplanationAr);
    }

    [Fact]
    public void Arabic_input_matches_rules()
    {
        var result = _analyzer.Analyze("ظهرت رسالة: تم رفض الوصول عند فتح المجلد");
        Assert.Equal("access-denied", result.MatchedRuleId);
    }

    [Fact]
    public void Unknown_input_gets_explicit_unknown_analysis()
    {
        var result = _analyzer.Analyze("my toaster makes a weird noise");
        Assert.Null(result.MatchedRuleId);
        Assert.NotEmpty(result.ProblemName);
        Assert.NotEmpty(result.Solutions); // fallback still offers safe general steps
    }

    [Fact]
    public void Solutions_linked_to_repairs_reference_real_catalog_ids()
    {
        foreach (var ruleInput in new[] { "0x80070002", "0x80070005", "dns probe finished no internet", "disk full", "0xc000007b" })
        {
            var result = _analyzer.Analyze(ruleInput);
            foreach (var s in result.Solutions.Where(s => s.RepairOperationId is not null))
                Assert.NotNull(RepairCatalog.Find(s.RepairOperationId));
        }
    }
}

public class RepairCatalogTests
{
    [Fact]
    public void All_plans_have_unique_ids_and_bilingual_text()
    {
        Assert.Equal(RepairCatalog.All.Count, RepairCatalog.All.Select(p => p.Id).Distinct().Count());
        foreach (var p in RepairCatalog.All)
        {
            Assert.False(string.IsNullOrWhiteSpace(p.Title));
            Assert.False(string.IsNullOrWhiteSpace(p.TitleAr));
            Assert.False(string.IsNullOrWhiteSpace(p.Description));
            Assert.False(string.IsNullOrWhiteSpace(p.DescriptionAr));
        }
    }

    [Fact]
    public void Command_plans_declare_their_exact_commands()
    {
        foreach (var p in RepairCatalog.All.Where(p => p.Kind == RepairKind.Command))
            Assert.NotEmpty(p.Commands);
    }

    [Fact]
    public void Destructive_or_risky_plans_are_marked()
    {
        Assert.True(RepairCatalog.SfcScan.RequiresAdmin);
        Assert.True(RepairCatalog.DismRestoreHealth.RequiresAdmin);
        Assert.Equal(RepairKind.FileCleanup, RepairCatalog.TempCleanup.Kind);
    }

    [Fact]
    public void Find_resolves_known_ids()
    {
        Assert.NotNull(RepairCatalog.Find("sfc-scan"));
        Assert.NotNull(RepairCatalog.Find("flush-dns"));
        Assert.Null(RepairCatalog.Find("delete-system32"));
    }
}

public class TempCleanupPlannerTests
{
    [Fact]
    public void Preview_lists_files_under_given_roots_with_real_sizes()
    {
        var root = Path.Combine(Path.GetTempPath(), "abodfix-test-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(root);
        try
        {
            File.WriteAllBytes(Path.Combine(root, "a.tmp"), new byte[1000]);
            File.WriteAllBytes(Path.Combine(root, "b.log"), new byte[2000]);
            var sub = Directory.CreateDirectory(Path.Combine(root, "sub"));
            File.WriteAllBytes(Path.Combine(sub.FullName, "c.tmp"), new byte[500]);

            var preview = TempCleanupPlanner.BuildPreview([root]);
            Assert.Equal(3, preview.Items.Count);
            Assert.Equal(3500, preview.TotalBytes);
        }
        finally { Directory.Delete(root, true); }
    }

    [Fact]
    public void Execute_deletes_listed_files_and_reports_freed_bytes()
    {
        var root = Path.Combine(Path.GetTempPath(), "abodfix-test-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(root);
        try
        {
            var f1 = Path.Combine(root, "a.tmp");
            var f2 = Path.Combine(root, "b.tmp");
            File.WriteAllBytes(f1, new byte[100]);
            File.WriteAllBytes(f2, new byte[200]);
            var preview = TempCleanupPlanner.BuildPreview([root]);

            var (deleted, skipped, freed) = TempCleanupPlanner.Execute(preview);
            Assert.Equal(2, deleted);
            Assert.Equal(0, skipped);
            Assert.Equal(300, freed);
            Assert.False(File.Exists(f1));
            Assert.False(File.Exists(f2));
        }
        finally { Directory.Delete(root, true); }
    }

    [Fact]
    public void SafeRoots_only_returns_temp_locations_never_system_dirs()
    {
        foreach (var r in TempCleanupPlanner.SafeRoots())
        {
            Assert.DoesNotContain("system32", r, StringComparison.OrdinalIgnoreCase);
            Assert.DoesNotMatch(@"^[A-Za-z]:\\Windows\\?$", r);
        }
    }
}

public class AiTechnicianClientTests
{
    private sealed class StubHandler(HttpStatusCode status, string body) : HttpMessageHandler
    {
        public HttpRequestMessage? LastRequest;
        public string? LastBody;
        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            LastRequest = request;
            LastBody = request.Content is null ? null : await request.Content.ReadAsStringAsync(cancellationToken);
            return new HttpResponseMessage(status)
            {
                Content = new StringContent(body, Encoding.UTF8, "application/json")
            };
        }
    }

    [Fact]
    public async Task ChatAsync_returns_message_content_and_sends_bearer_key()
    {
        var handler = new StubHandler(HttpStatusCode.OK,
            """{"choices":[{"message":{"role":"assistant","content":"جرب إعادة تشغيل الجهاز أولاً"}}]}""");
        var client = new AiTechnicianClient("https://example.invalid/v1/chat/completions", "test-model", "secret-key",
            new HttpClient(handler));

        var reply = await client.ChatAsync([new AiChatMessage("user", "الجهاز بطيء")], "system prompt");

        Assert.Equal("جرب إعادة تشغيل الجهاز أولاً", reply);
        Assert.Equal("Bearer", handler.LastRequest?.Headers.Authorization?.Scheme);
        Assert.Equal("secret-key", handler.LastRequest?.Headers.Authorization?.Parameter);
        using var sent = System.Text.Json.JsonDocument.Parse(handler.LastBody!);
        Assert.Equal("test-model", sent.RootElement.GetProperty("model").GetString());
        var msgs = sent.RootElement.GetProperty("messages");
        Assert.Equal("system prompt", msgs[0].GetProperty("content").GetString());
        Assert.Equal("الجهاز بطيء", msgs[1].GetProperty("content").GetString());
    }

    [Fact]
    public async Task ChatAsync_throws_typed_exception_on_http_error()
    {
        var handler = new StubHandler(HttpStatusCode.Unauthorized, """{"error":"bad key"}""");
        var client = new AiTechnicianClient("https://example.invalid/v1/chat/completions", "m", "k", new HttpClient(handler));

        var ex = await Assert.ThrowsAsync<AiRequestException>(() => client.ChatAsync([], "s"));
        Assert.Equal(401, ex.StatusCode);
    }

    [Fact]
    public void Constructor_rejects_empty_arguments()
    {
        Assert.Throws<ArgumentException>(() => new AiTechnicianClient("", "m", "k"));
        Assert.Throws<ArgumentException>(() => new AiTechnicianClient("e", "", "k"));
        Assert.Throws<ArgumentException>(() => new AiTechnicianClient("e", "m", ""));
    }

    [Fact]
    public void System_prompt_exists_in_both_languages_and_carries_safety_rules()
    {
        var ar = AiTechnicianClient.DefaultSystemPrompt("ar");
        var en = AiTechnicianClient.DefaultSystemPrompt("en");
        Assert.Contains("ABOD FIX", ar);
        Assert.Contains("ABOD FIX", en);
        Assert.Contains("registry", en);
    }
}

public class DiagnosticsRunnerTests
{
    private sealed class FakeMetrics(SystemSnapshot snapshot) : IMetricsSampler
    {
        public Task<SystemSnapshot> SampleAsync(CancellationToken ct = default) => Task.FromResult(snapshot);
    }

    private sealed class FakeServices(IReadOnlyList<WindowsServiceInfo> items) : IServiceProvider2
    {
        public Task<IReadOnlyList<WindowsServiceInfo>> ListImportantAsync(CancellationToken ct = default) => Task.FromResult(items);
    }

    private sealed class FakeStartup(IReadOnlyList<StartupItem> items) : IStartupProvider
    {
        public Task<IReadOnlyList<StartupItem>> ListAsync(CancellationToken ct = default) => Task.FromResult(items);
        public Task<StartupChangeResult> SetEnabledAsync(StartupItem item, bool enabled, CancellationToken ct = default)
            => Task.FromResult(new StartupChangeResult(true, "ok"));
    }

    private sealed class FakeEventLog(IReadOnlyList<EventLogIssue> issues) : IEventLogScanner
    {
        public Task<IReadOnlyList<EventLogIssue>> GetRecentIssuesAsync(int perLogLimit = 200, CancellationToken ct = default)
            => Task.FromResult(issues);
    }

    private sealed class FakeDisks(IReadOnlyList<DiskHealthInfo> disks) : IDiskHealthProvider
    {
        public Task<IReadOnlyList<DiskHealthInfo>> GetDisksAsync(CancellationToken ct = default) => Task.FromResult(disks);
    }

    private static DiagnosticsRunner HealthyRunner() => new(
        new FakeMetrics(TestData.Snapshot),
        new FakeServices([new WindowsServiceInfo { Name = "WinDefend", DisplayName = "Defender", Status = "Running", StartMode = "Automatic", IsCritical = true }]),
        new FakeStartup([new StartupItem { Name = "OneDrive", Location = StartupLocation.RegistryRun, SourceKey = "HKCU\\Run", Enabled = true }]),
        new FakeEventLog([]),
        new FakeDisks([new DiskHealthInfo { Model = "Good Disk", InterfaceType = "NVMe", SizeBytes = 1_000_000_000_000,
            Smart = SmartStatus.NoFailurePredicted, SmartDetails = "Drive reports no SMART errors." }]));

    [Fact]
    public async Task RunAll_completes_every_check_with_a_real_status()
    {
        var runner = HealthyRunner();
        var results = await runner.RunAllAsync();

        Assert.Equal(6, results.Count);
        foreach (var c in results)
        {
            Assert.NotEqual(CheckStatus.Pending, c.Status);
            Assert.NotEqual(CheckStatus.Running, c.Status);
            Assert.NotNull(c.Summary);
            Assert.NotNull(c.Duration);
        }
    }

    [Fact]
    public async Task Healthy_system_passes_without_suggested_repairs()
    {
        var results = await HealthyRunner().RunAllAsync();
        foreach (var c in results)
        {
            Assert.True(c.Status is CheckStatus.Passed or CheckStatus.Skipped, $"{c.Id}: {c.Status} {c.Summary}");
            Assert.Null(c.SuggestedRepairId);
        }
    }

    [Fact]
    public async Task Full_disk_flags_warning_and_suggests_cleanup()
    {
        var snapshot = TestData.Snapshot with
        {
            Disks = [new DiskSample { Name = "C:\\", VolumeLabel = "", FileSystem = "NTFS",
                TotalBytes = 100L * 1024 * 1024 * 1024, FreeBytes = 2L * 1024 * 1024 * 1024 }]
        };
        var runner = new DiagnosticsRunner(new FakeMetrics(snapshot), new FakeServices([]),
            new FakeStartup([]), new FakeEventLog([]), new FakeDisks([]));

        var results = await runner.RunAllAsync();
        var disk = results.Single(c => c.Id == "disk-space");
        Assert.True(disk.Status is CheckStatus.Warning or CheckStatus.Failed); // 2% free is critical
        Assert.Equal("temp-cleanup", disk.SuggestedRepairId);
    }

    [Fact]
    public async Task Stopped_critical_service_is_flagged()
    {
        var runner = new DiagnosticsRunner(new FakeMetrics(TestData.Snapshot),
            new FakeServices([new WindowsServiceInfo { Name = "WinDefend", DisplayName = "Defender", Status = "Stopped",
                StartMode = "Automatic", IsCritical = true, LooksWrong = true }]),
            new FakeStartup([]), new FakeEventLog([]), new FakeDisks([]));

        var results = await runner.RunAllAsync();
        var svc = results.Single(c => c.Id == "services");
        Assert.True(svc.Status is CheckStatus.Warning or CheckStatus.Failed);
    }

    [Fact]
    public async Task Event_log_errors_surface_with_counts()
    {
        var issues = new List<EventLogIssue>
        {
            new() { LogName = "Application", Source = "Application Error", Level = "Error", EventId = 1000, Count = 5, LastSeen = DateTimeOffset.Now }
        };
        var runner = new DiagnosticsRunner(new FakeMetrics(TestData.Snapshot), new FakeServices([]),
            new FakeStartup([]), new FakeEventLog(issues), new FakeDisks([]));

        var results = await runner.RunAllAsync();
        var el = results.Single(c => c.Id == "eventlog");
        Assert.NotEqual(CheckStatus.Passed, el.Status);
        Assert.Contains("5", el.Summary!);
    }

    [Fact]
    public async Task CheckUpdated_event_fires_for_each_check()
    {
        var runner = HealthyRunner();
        var fired = new List<string>();
        runner.CheckUpdated += c => fired.Add(c.Id + ":" + c.Status);

        await runner.RunAllAsync();
        Assert.True(fired.Count >= 6);
    }
}
