# ABOD FIX
### مساعد تشخيص وإصلاح ويندوز الاحترافي — Professional Windows Diagnostic & Repair Assistant

**العربية أولاً، English below.**

---

## العربية

### ما هو ABOD FIX؟
برنامج تشخيص وصيانة حقيقي لأجهزة Windows 10 وWindows 11. يقرأ بيانات جهازك الفعلية عبر أدوات ويندوز الرسمية (WMI، عدادات الأداء Performance Counters، سجل الأحداث) ويعرضها بواجهة Cyber Dark سوداء/حمراء باللغتين العربية (RTL) والإنجليزية.

**المبدأ الأساسي: لا أرقام وهمية أبداً.** إذا كان المستشعر غير مدعوم في جهازك، يخبرك البرنامج بذلك صراحة بدلاً من اختلاق قيمة.

### المرحلة الأولى (هذه النسخة) — ما الذي يعمل فعلاً
- **لوحة التحكم Dashboard:** اسم المعالج ونسبة استخدامه، الرام (المستخدم/المتاح/الإجمالي)، الأقراص والمساحة، اسم كارت الشاشة واستخدامه (عند دعم العدادات)، حرارة المعالج (عند دعم المستشعر فقط)، حالة الشبكة، مدة التشغيل، رسوم بيانية حية لآخر 60 ثانية.
- **إدارة العمليات:** قائمة كل العمليات مع PID واستهلاك الذاكرة والمعالج واسم الشركة، بحث وفلترة، وإنهاء العملية بعد تأكيدك — مع حماية صارمة لعمليات ويندوز الأساسية (لا يمكن إنهاء `svchost` أو `lsass` أو غيرها من داخل البرنامج).
- **صحة الأقراص:** الأقراص الفعلية (الموديل، الواجهة، الحجم) وحالة SMART عند إبلاغ الجهاز عنها. الحالة «غير معروف» تُعرض كما هي — لا ندّعي أن القرص سليم من مؤشر واحد.
- **التقارير:** تقرير مواصفات الجهاز بصيغ **PDF وTXT وJSON**، يحفظ في المكان الذي تختاره.
- **السجل:** كل نشاط (تقارير، إنهاء عمليات، أخطاء) يُحفظ في قاعدة بيانات SQLite محلية.
- **وضع القراءة فقط:** البرنامج لا يغيّر أي شيء في النظام إلا بعد موافقتك الصريحة (إنهاء عملية فقط في هذه المرحلة).

### حدود صادقة — اقرأها قبل الحكم
- البرنامج طُوّر وبُني على بيئة Linux عبر الاستهداف المتقاطع (EnableWindowsTargeting). **الكود يُترجم بنجاح وكل اختبارات المنطق تمر (27 اختباراً)، لكن الواجهة لم تُجرَّب بعد على جهاز Windows حقيقي.** أول تشغيل فعلي سيكون على جهازك.
- حرارة المعالج/كارت الشاشة: تُعرض فقط إذا وفّر جهازك مستشعراً تقرأه WMI. كثير من الأجهزة لا تفعل — هذا قرار الجهاز وليس عيباً في القراءة.
- قيمة VRAM من WMI مقيدة بحد أقصى 4GB في بعض الأنظمة (قيد معروف في Win32_VideoController).
- لا يوجد مثبّت Installer بعد: ملف EXE واحد يعمل مباشرة.

### المتطلبات والتشغيل
- Windows 10 أو 11 (64-bit).
- لا يحتاج تثبيت .NET — النسخة المنشورة Self-Contained.
- شغّل `ABOD FIX.exe`. لا يطلب صلاحيات مدير عند التشغيل.

### البناء من المصدر
```powershell
git clone <repo>
cd abod-fix
dotnet restore
dotnet test -c Release
dotnet publish src/AbodFix.App -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -o publish
```
أو عبر GitHub Actions: كل push يبني ويختبر وينشر EXE جاهزاً كـ artifact.

### بنية المشروع (Modular)
```
src/AbodFix.Core    منطق مستقل عن النظام: النماذج، العقود، التقارير، السجل، قواعد الأمان
src/AbodFix.App     تطبيق WPF: تنفيذات WMI/PerformanceCounter، الواجهة، الترجمة
tests/AbodFix.Tests اختبارات xunit لطبقة المنطق
```

### خارطة الطريق
- **المرحلة 2:** مركز الإصلاح الذكي (SFC / DISM بموافقتك، تنظيف الملفات المؤقتة بعد المعاينة، إدارة بدء التشغيل، فحص Event Log) — كل عملية تعرض الأوامر الفعلية قبل التنفيذ وتُسجَّل.
- **المرحلة 3:** محلل الأخطاء الذكي + مساعد AI Technician (مفتاح API يُحفظ مشفراً في جهازك، لا يوجد أبداً داخل ملفات البرنامج).
- **المرحلة 4:** فحص الشبكة المتقدم، معلومات التعريفات، تجهيز بنية تطبيق Android المرافق (Flutter).

### الأمان (إلزامي في كل المراحل)
- لا أمر إداري دون موافقة واضحة، والأوامر تُعرض قبل تنفيذها.
- لا حذف لملفات المستخدم تلقائياً، لا تعديل عشوائي للريجستري، لا إيقاف خدمات أساسية.
- كل عملية تُسجَّل في السجل المحلي.

---

## English

### What is ABOD FIX?
A real diagnostic and maintenance assistant for Windows 10/11. It reads your machine's actual data through official Windows interfaces (WMI, Performance Counters, Event Log) and presents it in a black/red Cyber Dark UI, in Arabic (RTL) and English.

**Core principle: never a fake number.** If your device does not expose a sensor, the app says so instead of inventing a value.

### Phase 1 (this build) - what actually works
- **Dashboard:** CPU name/usage, RAM (used/available/total), disks and free space, GPU name/usage (when counters exist), CPU temperature (only when a real sensor reports it), network status, uptime, live 60-second charts.
- **Process manager:** all processes with PID, memory, CPU, company; search/filter; terminate after your confirmation, with a hard protection list for critical Windows processes.
- **Disk health:** physical disks (model, interface, size) and SMART failure prediction when the device reports it. "Unknown" is shown honestly - a disk is never declared healthy from one missing indicator.
- **Reports:** system summary as **PDF, TXT or JSON**, saved where you choose.
- **History:** every action is stored in a local SQLite database.
- **Read-only mode:** nothing on your system is changed without explicit approval (process termination is the only write action in this phase).

### Honest limitations - read before judging
- Developed and cross-compiled on Linux (EnableWindowsTargeting). **The code compiles and all 27 logic tests pass, but the UI has not yet been run on a real Windows machine.** First real execution happens on your PC.
- CPU/GPU temperatures appear only if your hardware exposes a WMI-readable sensor. Many PCs do not.
- WMI-reported VRAM is capped at 4 GB on some systems (known Win32_VideoController limit).
- No installer yet: a single portable EXE.

### Requirements
- Windows 10/11 x64. No .NET install needed (self-contained). No admin rights at startup.

### Build from source
See the Arabic section commands - they are identical.

### Architecture
Modular: `AbodFix.Core` (OS-independent logic, reports, history, safety) + `AbodFix.App` (WPF UI + Windows services) + `AbodFix.Tests` (xunit). GitHub Actions builds, tests and publishes the EXE on every push.

### Roadmap
Phase 2: Smart Repair Center (SFC/DISM with confirmation, temp-file cleanup with preview, startup manager, Event Log scan). Phase 3: Smart Error Analyzer + AI Technician (API key stored encrypted on your device, never in app files). Phase 4: network diagnostics, driver info, Android companion groundwork (Flutter).

### Third-party licenses
- QuestPDF (PDF reports) - Community license, free for individuals and small businesses.
- Microsoft.Data.Sqlite, CommunityToolkit.Mvvm - MIT.
