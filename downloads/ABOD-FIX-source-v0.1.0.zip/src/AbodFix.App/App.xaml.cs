using System.IO;
using System.Windows;
using AbodFix.App.Services;
using AbodFix.App.ViewModels;
using AbodFix.Core.History;
using AbodFix.Core.Reports;

namespace AbodFix.App;

public partial class App : Application
{
    private WindowsMetricsSampler? _sampler;

    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);

        var dataDir = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "ABOD FIX");
        var history = new HistoryStore(Path.Combine(dataDir, "abodfix.db"));

        var app = new ShellContext
        {
            History = history,
            Confirm = new MessageBoxConfirmService(),
            FileDialog = new Win32FileDialogService(),
            AppVersion = "0.1.0"
        };

        var systemInfo = new WmiSystemInfoProvider();
        _sampler = new WindowsMetricsSampler();
        var processes = new WindowsProcessProvider();
        var disks = new WmiDiskHealthProvider();

        var builder = new ReportBuilder(systemInfo, _sampler, processes, disks, app.AppVersion);

        var historyVm = new HistoryViewModel(app);
        var settingsVm = new SettingsViewModel(app);
        var mainVm = new MainViewModel(
            new DashboardViewModel(systemInfo, _sampler),
            new ProcessesViewModel(processes, app),
            new DisksViewModel(disks, _sampler),
            new ReportsViewModel(builder, app, historyVm),
            historyVm,
            settingsVm);

        _ = settingsVm.LoadAsync();

        var window = new MainWindow { DataContext = mainVm };
        MainWindow = window;
        window.Show();
    }

    protected override void OnExit(ExitEventArgs e)
    {
        _sampler?.Dispose();
        base.OnExit(e);
    }
}

file sealed class MessageBoxConfirmService : IConfirmService
{
    public bool Confirm(string title, string message)
        => MessageBox.Show(message, title, MessageBoxButton.YesNo, MessageBoxImage.Warning) == MessageBoxResult.Yes;

    public void Info(string title, string message)
        => MessageBox.Show(message, title, MessageBoxButton.OK, MessageBoxImage.Information);
}

file sealed class Win32FileDialogService : IFileDialogService
{
    public string? AskSavePath(string defaultFileName, string extension, string filter)
    {
        var dlg = new Microsoft.Win32.SaveFileDialog
        {
            FileName = defaultFileName,
            DefaultExt = extension,
            Filter = filter,
            InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments)
        };
        return dlg.ShowDialog() == true ? dlg.FileName : null;
    }
}
