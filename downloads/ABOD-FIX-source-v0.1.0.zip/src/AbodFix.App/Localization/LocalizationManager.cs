using System.ComponentModel;
using System.Windows;

namespace AbodFix.App.Localization;

/// <summary>
/// Runtime EN/AR localization. Bind with {Binding [Key], Source={x:Static loc:Loc.Manager}}.
/// Switching language refreshes every binding and the window flow direction (Arabic = RTL).
/// </summary>
public sealed class LocalizationManager : INotifyPropertyChanged
{
    public static LocalizationManager Instance { get; } = new();

    public event PropertyChangedEventHandler? PropertyChanged;

    private string _language = "ar"; // user's product: Arabic first
    public string Language
    {
        get => _language;
        set
        {
            if (_language == value) return;
            _language = value;
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs("Item[]"));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(FlowDirection)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(IsArabic)));
        }
    }

    public bool IsArabic => Language == "ar";
    public FlowDirection FlowDirection => IsArabic ? System.Windows.FlowDirection.RightToLeft : System.Windows.FlowDirection.LeftToRight;

    public string this[string key] => Translate(Language, key);

    public static string Translate(string lang, string key)
        => (lang == "ar" ? Ar : En).TryGetValue(key, out var v) ? v : En.TryGetValue(key, out var e) ? e : key;

    private static readonly Dictionary<string, string> En = new()
    {
        ["App.Title"] = "ABOD FIX",
        ["App.Subtitle"] = "Windows Diagnostic & Repair Assistant",
        ["App.ReadOnly"] = "READ-ONLY MODE",
        ["Nav.Dashboard"] = "Dashboard",
        ["Nav.Processes"] = "Processes",
        ["Nav.Disks"] = "Disk Health",
        ["Nav.Reports"] = "Reports",
        ["Nav.History"] = "History",
        ["Nav.Settings"] = "Settings",

        ["Dash.Cpu"] = "CPU",
        ["Dash.Ram"] = "Memory (RAM)",
        ["Dash.Gpu"] = "GPU",
        ["Dash.Disks"] = "Storage",
        ["Dash.Uptime"] = "Uptime",
        ["Dash.Network"] = "Network",
        ["Dash.CpuTemp"] = "CPU temperature",
        ["Dash.GpuUsage"] = "GPU usage",
        ["Dash.Connected"] = "Connected",
        ["Dash.Disconnected"] = "Disconnected",
        ["Dash.NotSupported"] = "Not supported by this device",
        ["Dash.Loading"] = "Reading real system data...",
        ["Dash.UsageHistory"] = "Usage history (last 60 seconds)",
        ["Dash.Free"] = "free",
        ["Dash.Of"] = "of",
        ["Dash.OsInfo"] = "Operating system",

        ["Proc.Search"] = "Search processes...",
        ["Proc.Name"] = "Process",
        ["Proc.Pid"] = "PID",
        ["Proc.Cpu"] = "CPU %",
        ["Proc.Memory"] = "Memory",
        ["Proc.Company"] = "Company",
        ["Proc.Protected"] = "Windows system process - protected",
        ["Proc.Kill"] = "End process",
        ["Proc.KillConfirmTitle"] = "Confirm: end process",
        ["Proc.KillConfirm"] = "End process '{0}' (PID {1})?\n\nUnsaved work in this program will be lost.",
        ["Proc.Refresh"] = "Refresh",
        ["Proc.Count"] = "processes",

        ["Disk.Title"] = "Physical disks",
        ["Disk.Volumes"] = "Volumes",
        ["Disk.Model"] = "Model",
        ["Disk.Interface"] = "Interface",
        ["Disk.Size"] = "Size",
        ["Disk.Smart"] = "SMART status",
        ["Disk.SmartOk"] = "No failure predicted",
        ["Disk.SmartBad"] = "FAILURE PREDICTED - back up now",
        ["Disk.SmartUnknown"] = "Unknown - not reported by device",
        ["Disk.Note"] = "SMART is one indicator only. A 'no failure predicted' result does not guarantee the disk is healthy.",
        ["Disk.Used"] = "used",

        ["Rep.Title"] = "Generate a report",
        ["Rep.Subtitle"] = "Reports contain real measured data from this machine only.",
        ["Rep.System"] = "System summary report",
        ["Rep.Format"] = "Format",
        ["Rep.Generate"] = "Generate report",
        ["Rep.Generating"] = "Collecting data and generating report...",
        ["Rep.Done"] = "Report saved:",
        ["Rep.Failed"] = "Report generation failed:",

        ["Hist.Title"] = "Activity history",
        ["Hist.Empty"] = "No activity recorded yet.",
        ["Hist.Kind.Scan"] = "Scan",
        ["Hist.Kind.Repair"] = "Repair",
        ["Hist.Kind.Info"] = "Info",
        ["Hist.Kind.Warning"] = "Warning",
        ["Hist.Kind.Error"] = "Error",

        ["Set.Language"] = "Language",
        ["Set.Language.Ar"] = "العربية",
        ["Set.Language.En"] = "English",
        ["Set.Mode"] = "Safety mode",
        ["Set.Mode.ReadOnly"] = "Read-only (diagnosis only, nothing is changed on the system)",
        ["Set.Mode.Note"] = "Repair actions (phase 2) will always ask for your confirmation and show the exact commands before running.",
        ["Set.About"] = "About",
        ["Set.AboutText"] = "ABOD FIX reads real data from Windows (WMI, Performance Counters, Event Log). It never invents values. If a sensor is not supported by your device, the app says so instead of showing a fake number.",

        ["Common.Yes"] = "Yes",
        ["Common.No"] = "No",
        ["Common.Ok"] = "OK",
        ["Common.Cancel"] = "Cancel",
        ["Common.Error"] = "Error",
        ["Common.Save"] = "Save",
    };

    private static readonly Dictionary<string, string> Ar = new()
    {
        ["App.Title"] = "ABOD FIX",
        ["App.Subtitle"] = "مساعد تشخيص وإصلاح ويندوز الاحترافي",
        ["App.ReadOnly"] = "وضع القراءة فقط",
        ["Nav.Dashboard"] = "لوحة التحكم",
        ["Nav.Processes"] = "العمليات",
        ["Nav.Disks"] = "صحة الأقراص",
        ["Nav.Reports"] = "التقارير",
        ["Nav.History"] = "السجل",
        ["Nav.Settings"] = "الإعدادات",

        ["Dash.Cpu"] = "المعالج",
        ["Dash.Ram"] = "الذاكرة (RAM)",
        ["Dash.Gpu"] = "كارت الشاشة",
        ["Dash.Disks"] = "التخزين",
        ["Dash.Uptime"] = "مدة التشغيل",
        ["Dash.Network"] = "الشبكة",
        ["Dash.CpuTemp"] = "حرارة المعالج",
        ["Dash.GpuUsage"] = "استهلاك كارت الشاشة",
        ["Dash.Connected"] = "متصل",
        ["Dash.Disconnected"] = "غير متصل",
        ["Dash.NotSupported"] = "غير مدعوم من هذا الجهاز",
        ["Dash.Loading"] = "جاري قراءة بيانات الجهاز الحقيقية...",
        ["Dash.UsageHistory"] = "سجل الاستهلاك (آخر 60 ثانية)",
        ["Dash.Free"] = "متاح",
        ["Dash.Of"] = "من",
        ["Dash.OsInfo"] = "نظام التشغيل",

        ["Proc.Search"] = "ابحث في العمليات...",
        ["Proc.Name"] = "العملية",
        ["Proc.Pid"] = "PID",
        ["Proc.Cpu"] = "المعالج %",
        ["Proc.Memory"] = "الذاكرة",
        ["Proc.Company"] = "الشركة",
        ["Proc.Protected"] = "عملية نظام محمية",
        ["Proc.Kill"] = "إنهاء العملية",
        ["Proc.KillConfirmTitle"] = "تأكيد إنهاء العملية",
        ["Proc.KillConfirm"] = "هل تريد إنهاء العملية '{0}' (PID {1})؟\n\nأي عمل غير محفوظ في هذا البرنامج سيضيع.",
        ["Proc.Refresh"] = "تحديث",
        ["Proc.Count"] = "عملية",

        ["Disk.Title"] = "الأقراص الفعلية",
        ["Disk.Volumes"] = "وحدات التخزين",
        ["Disk.Model"] = "الموديل",
        ["Disk.Interface"] = "الواجهة",
        ["Disk.Size"] = "الحجم",
        ["Disk.Smart"] = "حالة SMART",
        ["Disk.SmartOk"] = "لا يوجد عطل متوقع",
        ["Disk.SmartBad"] = "عطل متوقع - انسخ بياناتك فوراً",
        ["Disk.SmartUnknown"] = "غير معروف - الجهاز لم يبلغ عن الحالة",
        ["Disk.Note"] = "SMART مؤشر واحد فقط. نتيجة 'لا يوجد عطل متوقع' لا تضمن أن القرص سليم تماماً.",
        ["Disk.Used"] = "مستخدم",

        ["Rep.Title"] = "إنشاء تقرير",
        ["Rep.Subtitle"] = "التقارير تحتوي على بيانات حقيقية مقاسة من هذا الجهاز فقط.",
        ["Rep.System"] = "تقرير مواصفات الجهاز",
        ["Rep.Format"] = "الصيغة",
        ["Rep.Generate"] = "إنشاء التقرير",
        ["Rep.Generating"] = "جاري جمع البيانات وإنشاء التقرير...",
        ["Rep.Done"] = "تم حفظ التقرير:",
        ["Rep.Failed"] = "فشل إنشاء التقرير:",

        ["Hist.Title"] = "سجل النشاط",
        ["Hist.Empty"] = "لا يوجد نشاط مسجل بعد.",
        ["Hist.Kind.Scan"] = "فحص",
        ["Hist.Kind.Repair"] = "إصلاح",
        ["Hist.Kind.Info"] = "معلومة",
        ["Hist.Kind.Warning"] = "تحذير",
        ["Hist.Kind.Error"] = "خطأ",

        ["Set.Language"] = "اللغة",
        ["Set.Language.Ar"] = "العربية",
        ["Set.Language.En"] = "English",
        ["Set.Mode"] = "وضع الأمان",
        ["Set.Mode.ReadOnly"] = "قراءة فقط (تشخيص فقط، لا يتم تغيير أي شيء في النظام)",
        ["Set.Mode.Note"] = "عمليات الإصلاح (المرحلة الثانية) ستطلب موافقتك دائماً وستعرض الأوامر الفعلية قبل تشغيلها.",
        ["Set.About"] = "حول البرنامج",
        ["Set.AboutText"] = "ABOD FIX يقرأ بيانات حقيقية من ويندوز (WMI وعدادات الأداء وسجل الأحداث). لا يعرض أرقاماً وهمية أبداً. إذا كان المستشعر غير مدعوم في جهازك، يوضح البرنامج ذلك بدلاً من عرض رقم مزيف.",

        ["Common.Yes"] = "نعم",
        ["Common.No"] = "لا",
        ["Common.Ok"] = "حسناً",
        ["Common.Cancel"] = "إلغاء",
        ["Common.Error"] = "خطأ",
        ["Common.Save"] = "حفظ",
    };
}

/// <summary>Shortcut for XAML: Source={x:Static loc:Loc.Manager}</summary>
public static class Loc
{
    public static LocalizationManager Manager => LocalizationManager.Instance;
}
