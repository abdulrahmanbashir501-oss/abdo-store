using System.Globalization;
using System.Windows;
using System.Windows.Data;
using AbodFix.Core.Models;
using AbodFix.Core.Reports;

namespace AbodFix.App;

public sealed class ByteSizeConverter : IValueConverter
{
    public static ByteSizeConverter Instance { get; } = new();
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        => value is long b ? TxtReportExporter.FormatBytes(b) : "--";
    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        => Binding.DoNothing;
}

public sealed class SmartStatusTextConverter : IValueConverter
{
    public static SmartStatusTextConverter Instance { get; } = new();
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
    {
        var loc = Localization.LocalizationManager.Instance;
        return value is SmartStatus s ? s switch
        {
            SmartStatus.NoFailurePredicted => loc["Disk.SmartOk"],
            SmartStatus.FailurePredicted => loc["Disk.SmartBad"],
            _ => loc["Disk.SmartUnknown"]
        } : "--";
    }
    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        => Binding.DoNothing;
}

public sealed class SmartStatusBrushConverter : IValueConverter
{
    public static SmartStatusBrushConverter Instance { get; } = new();
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
    {
        var app = Application.Current;
        return value is SmartStatus s ? s switch
        {
            SmartStatus.NoFailurePredicted => new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(0x2E, 0xC2, 0x7D)),
            SmartStatus.FailurePredicted => app.Resources["AccentBrush"],
            _ => app.Resources["TextDimBrush"]
        } : app.Resources["TextDimBrush"];
    }
    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        => Binding.DoNothing;
}

public sealed class InvertBoolConverter : IValueConverter
{
    public static InvertBoolConverter Instance { get; } = new();
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        => value is bool b ? !b : true;
    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        => Binding.DoNothing;
}

public sealed class ProtectedTooltipConverter : IValueConverter
{
    public static ProtectedTooltipConverter Instance { get; } = new();
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        => value is bool b && b
            ? Localization.LocalizationManager.Instance["Proc.Protected"]
            : Localization.LocalizationManager.Instance["Proc.Kill"];
    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        => Binding.DoNothing;
}

public sealed class StatusBrushConverter : IValueConverter
{
    public static StatusBrushConverter Instance { get; } = new();
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        => value is bool b && b
            ? Application.Current.Resources["AccentBrush"]
            : new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(0x2E, 0xC2, 0x7D));
    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        => Binding.DoNothing;
}
