@echo off
REM DANGER CITY (ABDO X) - Windows launcher
REM The game loads 3D models, so it needs a browser that allows local file access.
cd /d "%~dp0"
set "PAGE=%~dp0index.html"
where msedge >nul 2>nul && (start "" msedge --allow-file-access-from-files "%PAGE%" & exit /b)
if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" (start "" "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" --allow-file-access-from-files "%PAGE%" & exit /b)
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" (start "" "%ProgramFiles%\Google\Chrome\Application\chrome.exe" --allow-file-access-from-files "%PAGE%" & exit /b)
if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" (start "" "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" --allow-file-access-from-files "%PAGE%" & exit /b)
echo Could not find Edge or Chrome. Open index.html in any modern browser. & pause
