#!/usr/bin/env python3
# LINK X - الجسر الرقمي
# تشغيل:  python linkx.py
# اختياري للتحكم في الماوس/الكيبورد:  pip install pyautogui pyperclip
import json, os, secrets, socket, ssl, subprocess, sys, threading, time, urllib.parse, webbrowser
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

try:
    import pyautogui
    pyautogui.FAILSAFE = False
    pyautogui.PAUSE = 0
except Exception:
    pyautogui = None

PORT = 8080
FOLDER = os.path.join(os.path.expanduser("~"), "LinkX_Files")
os.makedirs(FOLDER, exist_ok=True)
devices, feed, lock = {}, [], threading.Lock()
PIN = "".join(secrets.choice("0123456789") for _ in range(6))
STATE = os.path.join(os.path.expanduser("~"), ".linkx_devices.json")
S = {"sync": False, "last": None}  # مزامنة حافظة الكمبيوتر
FAILS = {}


def save():
    try:
        with open(STATE, "w", encoding="utf-8") as f:
            json.dump(devices, f)
    except Exception:
        pass


def load():
    try:
        with open(STATE, encoding="utf-8") as f:
            devices.update(json.load(f))
    except Exception:
        pass


KEYS = {"enter", "backspace", "tab", "esc", "up", "down", "left", "right", "delete", "space", "home", "end",
        "pageup", "pagedown", "f5", "volumeup", "volumedown", "volumemute", "playpause", "nexttrack", "prevtrack"}
MOD = "command" if sys.platform == "darwin" else "ctrl"
HOT = {"copy": (MOD, "c"), "paste": (MOD, "v"), "cut": (MOD, "x"), "undo": (MOD, "z"), "all": (MOD, "a"),
       "alttab": ("alt", "tab"), "win": ("win",)}


def unique(path):
    b, e = os.path.splitext(path)
    i = 1
    while os.path.exists(path):
        path = f"{b} ({i}){e}"
        i += 1
    return path


def control(m):
    """يرجع نص الخطأ لو فشل، أو None لو نجح"""
    if not pyautogui:
        return "على الكمبيوتر نفّذ: pip install pyautogui"
    t = m.get("t")
    if t == "move":
        pyautogui.moveRel(int(m["dx"]), int(m["dy"]))
    elif t == "click":
        pyautogui.click(button="right" if m.get("b") == "right" else "left")
    elif t == "dbl":
        pyautogui.doubleClick()
    elif t == "scroll":
        pyautogui.scroll(int(m["dy"]))
    elif t == "key" and m.get("k") in KEYS:
        pyautogui.press(m["k"])
    elif t == "hot" and m.get("k") in HOT:
        pyautogui.hotkey(*HOT[m["k"]])
    elif t == "type":
        txt = str(m.get("text", ""))[:500]
        if txt.isascii():
            pyautogui.write(txt, interval=0)
        else:
            try:
                import pyperclip
                pyperclip.copy(txt)
                pyautogui.hotkey("command" if sys.platform == "darwin" else "ctrl", "v")
            except Exception:
                return "للكتابة بالعربي نفّذ: pip install pyperclip"
    return None


def clip_watch():
    try:
        import pyperclip
    except Exception:
        return
    try:
        S["last"] = pyperclip.paste()
    except Exception:
        pass
    while True:
        time.sleep(1)
        if not S["sync"]:
            continue
        try:
            c = pyperclip.paste()
        except Exception:
            continue
        if c and c != S["last"]:
            S["last"] = c
            with lock:
                feed.append({"from": "📋 الكمبيوتر", "text": c[:5000], "t": time.strftime("%H:%M")})
                del feed[:-100]


MANIFEST = {"name": "LINK X", "short_name": "LINK X", "start_url": "/", "display": "standalone", "dir": "rtl",
            "lang": "ar", "background_color": "#0d1117", "theme_color": "#0d1117",
            "icons": [{"src": "/icon.svg", "sizes": "any", "type": "image/svg+xml"}]}
ICON = ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><rect width="512" height="512" rx="96" fill="#0d1117"/>'
        '<text x="256" y="330" font-size="260" font-weight="800" text-anchor="middle" fill="#2f81f7" font-family="Arial">X</text></svg>')


class H(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def local(self):
        return self.client_address[0] in ("127.0.0.1", "::1")

    def send(self, code, body, ctype="application/json", headers=None):
        if isinstance(body, (dict, list)):
            body = json.dumps(body, ensure_ascii=False)
        if isinstance(body, str):
            body = body.encode()
        self.send_response(code)
        self.send_header("Content-Type", ctype + "; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        for k, v in (headers or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(body)

    def dev(self):
        c = SimpleCookie(self.headers.get("Cookie", ""))
        tok = c["lx"].value if "lx" in c else None
        d = devices.get(tok)
        if d:
            d["last"], d["ip"] = time.time(), self.client_address[0]
        return tok, d

    def new_dev(self, name, local=False):
        tok = secrets.token_urlsafe(24)
        devices[tok] = {"id": secrets.token_hex(3), "name": name[:30] or "جهاز", "ip": self.client_address[0],
                        "status": "allowed" if local else "pending", "control": local, "last": time.time()}
        save()
        sec = "; Secure" if getattr(self.server, "https", False) else ""
        return tok, {"Set-Cookie": f"lx={tok}; Path=/; Max-Age=31536000; HttpOnly; SameSite=Lax{sec}"}

    def json_body(self):
        n = int(self.headers.get("Content-Length", 0))
        return json.loads(self.rfile.read(n) or b"{}") if n else {}

    def do_GET(self):
        p = urllib.parse.urlparse(self.path).path
        if p == "/":
            return self.send(200, PAGE, "text/html")
        if p == "/manifest.json":
            return self.send(200, MANIFEST)
        if p == "/icon.svg":
            return self.send(200, ICON, "image/svg+xml")
        tok, d = self.dev()
        if p == "/api/me":
            hdr = None
            if not d and self.local():
                tok, hdr = self.new_dev("هذا الكمبيوتر", True)
                d = devices[tok]
            return self.send(200, {"joined": bool(d), "status": d and d["status"], "name": d and d["name"],
                                   "control": bool(d and d["control"]), "admin": self.local(),
                                   "pad": bool(pyautogui), "sync": S["sync"], "pin": PIN if self.local() else None}, headers=hdr)
        if p == "/api/devices" and self.local():
            return self.send(200, [dict(v, online=time.time() - v["last"] < 10) for v in devices.values()])
        if not d or d["status"] != "allowed":
            return self.send(403, {"err": "غير مسموح"})
        if p == "/api/feed":
            return self.send(200, feed[-100:][::-1])
        if p == "/api/files":
            fl = [(f, os.path.getsize(os.path.join(FOLDER, f)), os.path.getmtime(os.path.join(FOLDER, f)))
                  for f in os.listdir(FOLDER) if os.path.isfile(os.path.join(FOLDER, f))]
            return self.send(200, [{"name": f, "size": s} for f, s, _ in sorted(fl, key=lambda x: -x[2])])
        if p.startswith("/files/"):
            name = os.path.basename(urllib.parse.unquote(p[7:]))
            path = os.path.join(FOLDER, name)
            if not os.path.isfile(path):
                return self.send(404, {})
            self.send_response(200)
            self.send_header("Content-Type", "application/octet-stream")
            self.send_header("Content-Length", str(os.path.getsize(path)))
            self.send_header("Content-Disposition", "attachment; filename*=UTF-8''" + urllib.parse.quote(name))
            self.end_headers()
            with open(path, "rb") as f:
                while True:
                    b = f.read(1 << 20)
                    if not b:
                        break
                    self.wfile.write(b)
            return
        self.send(404, {})

    def do_POST(self):
        try:
            u = urllib.parse.urlparse(self.path)
            p = u.path
            tok, d = self.dev()
            if p == "/api/join":
                m = self.json_body()
                name = str(m.get("name", "")).strip()
                ip = self.client_address[0]
                if not d and not self.local():
                    if FAILS.get(ip, (0, 0))[0] >= 5 and time.time() - FAILS[ip][1] < 60:
                        return self.send(429, {"err": "محاولات كتير، استنى دقيقة"})
                    if str(m.get("pin", "")).strip() != PIN:
                        FAILS[ip] = (FAILS.get(ip, (0, 0))[0] + 1, time.time())
                        return self.send(403, {"err": "الـ PIN غلط"})
                    FAILS.pop(ip, None)
                if d:
                    return self.send(200, {"ok": True})
                _, hdr = self.new_dev(name, self.local())
                return self.send(200, {"ok": True}, headers=hdr)
            if p == "/api/device" and self.local():
                m = self.json_body()
                for t, v in list(devices.items()):
                    if v["id"] == m.get("id"):
                        a = m.get("a")
                        if a == "allow": v["status"] = "allowed"
                        elif a == "block": v["status"], v["control"] = "blocked", False
                        elif a == "ctl_on": v["control"] = True
                        elif a == "ctl_off": v["control"] = False
                        elif a == "remove": del devices[t]
                save()
                return self.send(200, {"ok": True})
            if p == "/api/sync" and self.local():
                S["sync"] = bool(self.json_body().get("on"))
                return self.send(200, {"ok": True})
            if not d or d["status"] != "allowed":
                return self.send(403, {"err": "غير مسموح"})
            if p == "/api/share":
                txt = str(self.json_body().get("text", "")).strip()[:5000]
                if txt:
                    with lock:
                        feed.append({"from": d["name"], "text": txt, "t": time.strftime("%H:%M")})
                        del feed[:-100]
                return self.send(200, {"ok": True})
            if p == "/api/upload":
                name = os.path.basename(urllib.parse.parse_qs(u.query).get("name", ["file"])[0]) or "file"
                left = int(self.headers.get("Content-Length", 0))
                with open(unique(os.path.join(FOLDER, name)), "wb") as f:
                    while left > 0:
                        b = self.rfile.read(min(1 << 20, left))
                        if not b:
                            break
                        f.write(b)
                        left -= len(b)
                return self.send(200, {"ok": True})
            if p == "/api/clip":
                if not d["control"]:
                    return self.send(403, {"err": "التحكم غير مسموح لهذا الجهاز"})
                try:
                    import pyperclip
                    txt = str(self.json_body().get("text", ""))[:5000]
                    S["last"] = txt
                    pyperclip.copy(txt)
                    return self.send(200, {"ok": True})
                except Exception:
                    return self.send(200, {"err": "على الكمبيوتر نفّذ: pip install pyperclip"})
            if p == "/api/ctl":
                if not d["control"]:
                    return self.send(403, {"err": "التحكم غير مسموح لهذا الجهاز — اسمح له من شاشة الأجهزة على الكمبيوتر"})
                err = control(self.json_body())
                return self.send(200, {"err": err} if err else {"ok": True})
            self.send(404, {})
        except Exception as e:
            self.send(400, {"err": str(e)})


PAGE = r'''<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=no"><title>LINK X</title><link rel="manifest" href="/manifest.json"><meta name="theme-color" content="#0d1117">
<style>
:root{--bg:#0d1117;--card:#161b22;--line:#30363d;--fg:#e6edf3;--mut:#8b949e;--acc:#2f81f7;--ok:#3fb950;--bad:#f85149}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--fg);font-family:system-ui,"Segoe UI",Tahoma,sans-serif;max-width:640px;margin:auto}
header{padding:14px 16px;font-weight:800;font-size:22px;border-bottom:1px solid var(--line)}header span{color:var(--acc)}
header small{font-weight:400;font-size:13px;color:var(--mut);margin-inline-start:8px}
nav{display:flex;gap:6px;padding:10px}nav button{flex:1;padding:10px 4px;border:1px solid var(--line);background:var(--card);color:var(--mut);border-radius:10px;font-size:14px}
nav button.on{color:#fff;background:var(--acc);border-color:var(--acc)}
.card,section{padding:12px 14px}.card{margin:12px;background:var(--card);border:1px solid var(--line);border-radius:12px}
input,textarea{width:100%;padding:12px;border-radius:10px;border:1px solid var(--line);background:var(--bg);color:var(--fg);font-size:16px;font-family:inherit}
button{font-family:inherit;font-size:15px;cursor:pointer}.pri{width:100%;margin-top:8px;padding:12px;border:0;border-radius:10px;background:var(--acc);color:#fff;font-weight:700}
.row{display:flex;gap:8px;margin-top:8px}.row button{flex:1;padding:12px 4px;border:1px solid var(--line);background:var(--card);color:var(--fg);border-radius:10px}
.item{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:10px;margin-top:8px;word-break:break-word}
.item small{color:var(--mut);display:block;margin-bottom:4px}.item a{color:var(--acc)}.item button{margin-top:6px;padding:4px 10px;border-radius:8px;border:1px solid var(--line);background:none;color:var(--mut)}
#pad{height:230px;border-radius:14px;border:2px dashed var(--line);background:var(--card);display:flex;align-items:center;justify-content:center;color:var(--mut);touch-action:none;user-select:none;text-align:center}
.b{display:inline-block;padding:2px 8px;border-radius:99px;font-size:12px;margin-inline-start:6px}.pending{background:#9e6a03}.allowed{background:#238636}.blocked{background:#b62324}
.hide{display:none}.err{color:var(--bad);font-size:14px;margin-top:6px}
</style></head><body>
<header>LINK <span>X</span><small id="who"></small></header>
<div id="join" class="card hide"><h3 style="margin-top:0">ربط هذا الجهاز</h3><input id="nm" placeholder="اسم الجهاز (مثلاً: موبايل أحمد)"><input id="pin" inputmode="numeric" placeholder="PIN الظاهر على شاشة الكمبيوتر" style="margin-top:8px"><div id="jerr" class="err"></div><button class="pri" onclick="join()">اطلب الانضمام</button></div>
<div id="wait" class="card hide"></div>
<div id="app" class="hide"><nav id="tabs"></nav>
<section id="s-share"><textarea id="tx" rows="3" placeholder="اكتب نص أو الصق رابط…"></textarea><div class="row"><button onclick="pasteIt()">📥 لصق من الحافظة</button><button onclick="share()" style="background:var(--acc);color:#fff;border:0">مشاركة مع كل الأجهزة</button></div><div id="feed"></div></section>
<section id="s-files" class="hide"><input type="file" id="fi" multiple onchange="up(this.files)"><div id="pg" class="err" style="color:var(--ok)"></div><div id="fl"></div></section>
<section id="s-ctl" class="hide"><div id="pad">لوحة لمس<br>حرّك بإصبع = ماوس · لمسة = كليك · إصبعين = سكرول</div>
<div class="row"><button onclick="ctl({t:'click'})">كليك</button><button onclick="ctl({t:'dbl'})">دبل كليك</button><button onclick="ctl({t:'click',b:'right'})">يمين</button></div>
<div class="row"><input id="kt" placeholder="اكتب هنا ليُكتب على الكمبيوتر"><button style="flex:0 0 70px" onclick="typeIt()">إرسال</button></div>
<div class="row"><button onclick="ctl({t:'key',k:'backspace'})">⌫</button><button onclick="ctl({t:'key',k:'enter'})">Enter</button><button onclick="ctl({t:'key',k:'tab'})">Tab</button><button onclick="ctl({t:'key',k:'esc'})">Esc</button></div>
<div class="row"><button onclick="ctl({t:'key',k:'left'})">←</button><button onclick="ctl({t:'key',k:'up'})">↑</button><button onclick="ctl({t:'key',k:'down'})">↓</button><button onclick="ctl({t:'key',k:'right'})">→</button></div>
<div class="row"><button onclick="ctl({t:'hot',k:'copy'})">نسخ</button><button onclick="ctl({t:'hot',k:'paste'})">لصق</button><button onclick="ctl({t:'hot',k:'undo'})">تراجع</button><button onclick="ctl({t:'hot',k:'alttab'})">Alt+Tab</button></div>
<div class="row"><button onclick="ctl({t:'key',k:'volumedown'})">🔉</button><button onclick="ctl({t:'key',k:'volumemute'})">🔇</button><button onclick="ctl({t:'key',k:'volumeup'})">🔊</button><button onclick="ctl({t:'key',k:'playpause'})">⏯</button></div>
<div class="row"><button onclick="ctl({t:'key',k:'pageup'})">السلايد السابق</button><button onclick="ctl({t:'key',k:'f5'})">F5</button><button onclick="ctl({t:'key',k:'pagedown'})">السلايد التالي</button></div>
<div id="ctlmsg" class="err"></div></section>
<section id="s-devs" class="hide"><div id="dl"></div></section></div>
<script>
const $=s=>document.querySelector(s);let me={},tab='share',FEED=[],pend=0;
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const api=(p,o)=>fetch(p,o).then(r=>r.json()).catch(()=>({}));
const post=(p,b)=>api(p,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(b)});
async function boot(){me=await api('/api/me');draw()}
function join(){post('/api/join',{name:$('#nm').value||'جهاز',pin:$('#pin').value}).then(j=>{if(j.err)$('#jerr').textContent=j.err;else boot()})}
function draw(){
 $('#who').textContent=me.name||'';
 $('#join').classList.toggle('hide',!!me.joined);
 const w=$('#wait');w.classList.toggle('hide',!(me.joined&&me.status!=='allowed'));
 w.textContent=me.status==='blocked'?'تم حظر هذا الجهاز.':'في انتظار موافقة الكمبيوتر… افتح http://localhost على الكمبيوتر ووافق على الجهاز.';
 const ok=me.joined&&me.status==='allowed';$('#app').classList.toggle('hide',!ok);
 if(!ok)return;
 const T=[['share','نصوص وروابط'],['files','ملفات'],['ctl','تحكم']];if(me.admin)T.push(['devs','الأجهزة'+(pend?' ('+pend+')':'')]);
 $('#tabs').innerHTML=T.map(t=>`<button class="${t[0]===tab?'on':''}" onclick="go('${t[0]}')">${t[1]}</button>`).join('');
 for(const t of['share','files','ctl','devs'])$('#s-'+t).classList.toggle('hide',t!==tab);
 if(tab==='ctl'&&!me.control)$('#ctlmsg').textContent='التحكم غير مسموح لهذا الجهاز بعد.';
 else if(tab==='ctl'&&!me.pad)$('#ctlmsg').textContent='على الكمبيوتر نفّذ: pip install pyautogui';
}
function go(t){tab=t;draw();tick()}
function share(){const t=$('#tx').value.trim();if(!t)return;post('/api/share',{text:t}).then(()=>{$('#tx').value='';loadFeed()})}
async function loadFeed(){FEED=await api('/api/feed');if(!Array.isArray(FEED))return;
 $('#feed').innerHTML=FEED.map((m,i)=>`<div class="item"><small>${esc(m.from)} · ${m.t}</small>${esc(m.text).replace(/(https?:\/\/[^\s]+)/g,'<a href="$1" target="_blank">$1</a>')}<br><button onclick="cp(${i})">نسخ</button>${me.control?`<button onclick="toPC(${i})" style="margin-inline-start:6px">للحافظة على الكمبيوتر</button>`:''}</div>`).join('')}
function cp(i){const t=document.createElement('textarea');t.value=FEED[i].text;document.body.appendChild(t);t.select();document.execCommand('copy');t.remove()}
function toPC(i){post('/api/clip',{text:FEED[i].text}).then(j=>{if(j.err)alert(j.err)})}
function pasteIt(){if(navigator.clipboard&&navigator.clipboard.readText)navigator.clipboard.readText().then(t=>{$('#tx').value=t}).catch(()=>alert('اسمح بالوصول للحافظة'));else alert('اللصق التلقائي يحتاج https — افتح العنوان اللي بيبدأ بـ https')}
function sy(){post('/api/sync',{on:!me.sync}).then(boot)}
const sz=n=>n>1e9?(n/1e9).toFixed(2)+' GB':n>1e6?(n/1e6).toFixed(1)+' MB':Math.ceil(n/1e3)+' KB';
async function loadFiles(){const f=await api('/api/files');if(!Array.isArray(f))return;
 $('#fl').innerHTML=f.map(x=>`<div class="item"><a href="/files/${encodeURIComponent(x.name)}" download>${esc(x.name)}</a> <small style="display:inline">${sz(x.size)}</small></div>`).join('')||'<div class="item">لا توجد ملفات</div>'}
function up(files){const L=[...files];(function next(){const f=L.shift();if(!f){$('#fi').value='';loadFiles();return}
 const x=new XMLHttpRequest();x.open('POST','/api/upload?name='+encodeURIComponent(f.name));
 x.upload.onprogress=e=>{$('#pg').textContent=f.name+' '+Math.round(e.loaded/e.total*100)+'%'};
 x.onload=()=>{$('#pg').textContent='تم رفع '+f.name;next()};x.onerror=()=>{$('#pg').textContent='فشل الرفع'};x.send(f)})()}
async function loadDevs(){const d=await api('/api/devices');if(!Array.isArray(d))return;pend=d.filter(x=>x.status==='pending').length;
 const B=(id,a,t)=>`<button onclick="dv('${id}','${a}')">${t}</button>`;
 $('#dl').innerHTML=`<div class="item">PIN الانضمام: <b style="font-size:22px;letter-spacing:3px">${me.pin||''}</b><br><button onclick="sy()">${me.sync?'إيقاف':'تشغيل'} مزامنة حافظة الكمبيوتر تلقائياً</button></div>`+d.map(x=>`<div class="item"><b>${esc(x.name)}</b><span class="b ${x.status}">${{pending:'بانتظار الموافقة',allowed:'مسموح',blocked:'محظور'}[x.status]}</span>${x.online?' 🟢':''}<small>${esc(x.ip)} · التحكم: ${x.control?'مفعّل':'مقفول'}</small>`+
 (x.status==='pending'?B(x.id,'allow','قبول')+B(x.id,'block','رفض'):x.status==='allowed'?(x.control?B(x.id,'ctl_off','إيقاف التحكم'):B(x.id,'ctl_on','السماح بالتحكم'))+B(x.id,'block','حظر'):B(x.id,'allow','سماح')+B(x.id,'remove','حذف'))+'</div>').join('')}
function dv(id,a){post('/api/device',{id,a}).then(loadDevs)}
function ctl(m){fetch('/api/ctl',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(m)}).then(r=>r.json()).then(j=>{$('#ctlmsg').textContent=j.err||''}).catch(()=>{})}
function typeIt(){const v=$('#kt').value;if(v){ctl({t:'type',text:v});$('#kt').value=''}}
let last=null,mv={x:0,y:0},sc=0,moved=0,t0=0;const pad=$('#pad');
const avg=t=>{let x=0,y=0;for(const p of t){x+=p.clientX;y+=p.clientY}return{x:x/t.length,y:y/t.length}};
pad.addEventListener('touchstart',e=>{e.preventDefault();last=avg(e.touches);moved=0;t0=Date.now()},{passive:false});
pad.addEventListener('touchmove',e=>{e.preventDefault();const c=avg(e.touches),dx=c.x-last.x,dy=c.y-last.y;last=c;moved+=Math.abs(dx)+Math.abs(dy);
 if(e.touches.length>1)sc+=dy*0.1;else{mv.x+=dx*1.6;mv.y+=dy*1.6}},{passive:false});
pad.addEventListener('touchend',()=>{if(moved<6&&Date.now()-t0<250)ctl({t:'click'})});
setInterval(()=>{if(Math.abs(mv.x)>=1||Math.abs(mv.y)>=1){ctl({t:'move',dx:Math.round(mv.x),dy:Math.round(mv.y)});mv={x:0,y:0}}
 if(Math.abs(sc)>=1){const s=Math.trunc(sc);ctl({t:'scroll',dy:s});sc-=s}},40);
async function tick(){if(!me.joined||me.status!=='allowed'){const o=me.status;me=await api('/api/me');if(o!==me.status||!me.joined)draw();return}
 const m=await api('/api/me');if(m.status!==me.status||m.control!==me.control){me=m;draw()}
 if(me.admin)loadDevs().then(()=>{});
 if(tab==='share')loadFeed();else if(tab==='files')loadFiles();else if(tab==='devs')loadDevs()}
boot();setInterval(tick,2000);
</script></body></html>'''


def lan_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("10.255.255.255", 1))
        return s.getsockname()[0]
    except Exception:
        return socket.gethostbyname(socket.gethostname())
    finally:
        s.close()


def make_ssl():
    d = os.path.join(os.path.expanduser("~"), ".linkx")
    os.makedirs(d, exist_ok=True)
    c, k = os.path.join(d, "cert.pem"), os.path.join(d, "key.pem")
    if not os.path.exists(c):
        try:
            subprocess.run(["openssl", "req", "-x509", "-newkey", "rsa:2048", "-nodes", "-keyout", k, "-out", c,
                            "-days", "3650", "-subj", "/CN=LinkX"], check=True,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception:
            import datetime
            from cryptography import x509
            from cryptography.hazmat.primitives import hashes, serialization
            from cryptography.hazmat.primitives.asymmetric import rsa
            from cryptography.x509.oid import NameOID
            key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
            nm = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "LinkX")])
            now = datetime.datetime.utcnow()
            cert = (x509.CertificateBuilder().subject_name(nm).issuer_name(nm).public_key(key.public_key())
                    .serial_number(x509.random_serial_number()).not_valid_before(now)
                    .not_valid_after(now + datetime.timedelta(days=3650)).sign(key, hashes.SHA256()))
            open(c, "wb").write(cert.public_bytes(serialization.Encoding.PEM))
            open(k, "wb").write(key.private_bytes(serialization.Encoding.PEM,
                                                   serialization.PrivateFormat.TraditionalOpenSSL,
                                                   serialization.NoEncryption()))
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ctx.load_cert_chain(c, k)
    return ctx


if __name__ == "__main__":
    load()
    ip = lan_ip()
    srv = ThreadingHTTPServer(("0.0.0.0", PORT), H)
    url = f"http://{ip}:{PORT}"
    print("\n  LINK X شغّال ✅")
    print(f"  PIN الانضمام:  {PIN}")
    print(f"  من الموبايل (نفس الواي فاي):  {url}")
    try:
        ctx = make_ssl()
        s2 = ThreadingHTTPServer(("0.0.0.0", PORT + 363), H)  # 8443
        s2.socket = ctx.wrap_socket(s2.socket, server_side=True)
        s2.https = True
        threading.Thread(target=s2.serve_forever, daemon=True).start()
        url = f"https://{ip}:{PORT + 363}"
        print(f"  نسخة مشفّرة HTTPS:           {url}  (اضغط متابعة/Advanced عند التحذير)")
    except Exception:
        print("  (HTTPS غير متاح: محتاج openssl أو pip install cryptography)")
    try:
        import qrcode
        q = qrcode.QRCode()
        q.add_data(url)
        q.print_ascii(invert=True)
    except Exception:
        pass
    print(f"  على هذا الكمبيوتر:  http://localhost:{PORT}")
    print(f"  الملفات المستلمة في: {FOLDER}")
    if not pyautogui:
        print("  (للتحكم في الماوس/الكيبورد: pip install pyautogui pyperclip)")
    threading.Thread(target=clip_watch, daemon=True).start()
    try:
        webbrowser.open(f"http://localhost:{PORT}")
    except Exception:
        pass
    srv.serve_forever()
