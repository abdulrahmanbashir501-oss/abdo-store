LINK X for Windows (no install needed)
1) Extract the whole folder anywhere.
2) Double-click LinkX.bat.
3) If Windows Firewall asks, click Allow (Private networks), otherwise the phone cannot connect.
4) Type the address shown in the window (or scan the QR) on your phone, or open the LinkX Android app and enter it.
Received files: C:\Users\<you>\LinkX_Files
