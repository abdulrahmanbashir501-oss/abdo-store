@echo off
chcp 65001 >nul
set PYTHONUTF8=1
title LINK X
cd /d "%~dp0"
python\python.exe linkx.py
pause
